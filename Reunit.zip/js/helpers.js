var ERC20_ABI 				=	[{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"}]
var ERC20_FULL_ABI			=	[ { "constant": true, "inputs": [], "name": "name", "outputs": [ { "name": "", "type": "string" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [ { "name": "_spender", "type": "address" }, { "name": "_value", "type": "uint256" } ], "name": "approve", "outputs": [ { "name": "", "type": "bool" } ], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "totalSupply", "outputs": [ { "name": "", "type": "uint256" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [ { "name": "_from", "type": "address" }, { "name": "_to", "type": "address" }, { "name": "_value", "type": "uint256" } ], "name": "transferFrom", "outputs": [ { "name": "", "type": "bool" } ], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "decimals", "outputs": [ { "name": "", "type": "uint8" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "_owner", "type": "address" } ], "name": "balanceOf", "outputs": [ { "name": "balance", "type": "uint256" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "symbol", "outputs": [ { "name": "", "type": "string" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [ { "name": "_to", "type": "address" }, { "name": "_value", "type": "uint256" } ], "name": "transfer", "outputs": [ { "name": "", "type": "bool" } ], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [ { "name": "_owner", "type": "address" }, { "name": "_spender", "type": "address" } ], "name": "allowance", "outputs": [ { "name": "", "type": "uint256" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "payable": true, "stateMutability": "payable", "type": "fallback" }, { "anonymous": false, "inputs": [ { "indexed": true, "name": "owner", "type": "address" }, { "indexed": true, "name": "spender", "type": "address" }, { "indexed": false, "name": "value", "type": "uint256" } ], "name": "Approval", "type": "event" }, { "anonymous": false, "inputs": [ { "indexed": true, "name": "from", "type": "address" }, { "indexed": true, "name": "to", "type": "address" }, { "indexed": false, "name": "value", "type": "uint256" } ], "name": "Transfer", "type": "event" } ];
var STG_QUOTE_ABI			=	[{"inputs":[{"internalType":"uint16","name":"_dstChainId","type":"uint16"},{"internalType":"uint8","name":"_functionType","type":"uint8"},{"internalType":"bytes","name":"_toAddress","type":"bytes"},{"internalType":"bytes","name":"_transferAndCallPayload","type":"bytes"},{"components":[{"internalType":"uint256","name":"dstGasForCall","type":"uint256"},{"internalType":"uint256","name":"dstNativeAmount","type":"uint256"},{"internalType":"bytes","name":"dstNativeAddr","type":"bytes"}],"internalType":"struct IStargateRouter.lzTxObj","name":"_lzTxParams","type":"tuple"}],"name":"quoteLayerZeroFee","outputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"}];
var ERC20_TRANSFER_ABI		=	{"inputs":[{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"};
var STG_SWAP_ABI			=	{ "inputs": [ { "internalType": "uint16", "name": "_dstChainId", "type": "uint16" }, { "internalType": "uint256", "name": "_srcPoolId", "type": "uint256" }, { "internalType": "uint256", "name": "_dstPoolId", "type": "uint256" }, { "internalType": "address payable", "name": "_refundAddress", "type": "address" }, { "internalType": "uint256", "name": "_amountLD", "type": "uint256" }, { "internalType": "uint256", "name": "_minAmountLD", "type": "uint256" }, { "components": [ { "internalType": "uint256", "name": "dstGasForCall", "type": "uint256" }, { "internalType": "uint256", "name": "dstNativeAmount", "type": "uint256" }, { "internalType": "bytes", "name": "dstNativeAddr", "type": "bytes" } ], "internalType": "struct IStargateRouter.lzTxObj", "name": "_lzTxParams", "type": "tuple" }, { "internalType": "bytes", "name": "_to", "type": "bytes" }, { "internalType": "bytes", "name": "_payload", "type": "bytes" } ], "name": "swap", "outputs": [], "stateMutability": "payable", "type": "function" };
var ERC20_APPROVE_ABI		=	{ "inputs": [ { "internalType": "address", "name": "spender", "type": "address" }, { "internalType": "uint256", "name": "amount", "type": "uint256" } ], "name": "approve", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "stateMutability": "nonpayable", "type": "function" };
var ONCHAIN_ORACLE 			= 	[{"inputs":[{"internalType":"contract MultiWrapper","name":"_multiWrapper","type":"address"},{"internalType":"contract IOracle[]","name":"existingOracles","type":"address[]"},{"internalType":"enum OffchainOracle.OracleType[]","name":"oracleTypes","type":"uint8[]"},{"internalType":"contract IERC20[]","name":"existingConnectors","type":"address[]"},{"internalType":"contract IERC20","name":"wBase","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"contract IERC20","name":"connector","type":"address"}],"name":"ConnectorAdded","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"contract IERC20","name":"connector","type":"address"}],"name":"ConnectorRemoved","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"contract MultiWrapper","name":"multiWrapper","type":"address"}],"name":"MultiWrapperUpdated","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"contract IOracle","name":"oracle","type":"address"},{"indexed":false,"internalType":"enum OffchainOracle.OracleType","name":"oracleType","type":"uint8"}],"name":"OracleAdded","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"contract IOracle","name":"oracle","type":"address"},{"indexed":false,"internalType":"enum OffchainOracle.OracleType","name":"oracleType","type":"uint8"}],"name":"OracleRemoved","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"inputs":[{"internalType":"contract IERC20","name":"connector","type":"address"}],"name":"addConnector","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IOracle","name":"oracle","type":"address"},{"internalType":"enum OffchainOracle.OracleType","name":"oracleKind","type":"uint8"}],"name":"addOracle","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"connectors","outputs":[{"internalType":"contract IERC20[]","name":"allConnectors","type":"address[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"srcToken","type":"address"},{"internalType":"contract IERC20","name":"dstToken","type":"address"},{"internalType":"bool","name":"useWrappers","type":"bool"}],"name":"getRate","outputs":[{"internalType":"uint256","name":"weightedRate","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"srcToken","type":"address"},{"internalType":"bool","name":"useSrcWrappers","type":"bool"}],"name":"getRateToEth","outputs":[{"internalType":"uint256","name":"weightedRate","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"multiWrapper","outputs":[{"internalType":"contract MultiWrapper","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"oracles","outputs":[{"internalType":"contract IOracle[]","name":"allOracles","type":"address[]"},{"internalType":"enum OffchainOracle.OracleType[]","name":"oracleTypes","type":"uint8[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"connector","type":"address"}],"name":"removeConnector","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IOracle","name":"oracle","type":"address"},{"internalType":"enum OffchainOracle.OracleType","name":"oracleKind","type":"uint8"}],"name":"removeOracle","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract MultiWrapper","name":"_multiWrapper","type":"address"}],"name":"setMultiWrapper","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"}];

var REUNIT_API_URL			=	"https://tfdvvh5daj5jsxj7y4fjfnfjty0uqipu.lambda-url.eu-west-2.on.aws/";

function chainsData(chainID) {
	switch(chainID) {
		// Ethereum
		case 1:
		case 101:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=1", 
							"usdc": {"description": "USDC is a fully collateralized US dollar stablecoin, an Ethereum powered coin and is the brainchild of CENTRE, an open source project bootstrapped by contributions from Circle and Coinbase.","link": "https://circle.com/","address": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48","decimals": 1e6, "decimalNumber": 6, "poolID": 1},
							"usdt": {"description": "Tether (USDT) is a cryptocurrency with a value meant to mirror the value of the U.S. dollar.","link": "https://tether.to/","address": "0xdAC17F958D2ee523a2206206994597C13D831ec7","decimals": 1e6, "decimalNumber": 6, "poolID": 2},
							"dai": {"description": "Dai is a stable cryptocurrency supported by Maker (MKR). To ensure price stability, Dai minimizes the price volatility against the US dollar, through an incentive structure for its participants.", "link": "https://makerdao.com", "address": "0x6B175474E89094C44Da98b954EedeAC495271d0F", "decimals": 1e18, "decimalNumber": 18, "poolID": 3},
							"oracle": "0x07D91f5fb9Bf7798734C3f606dB065549F6893bb",
							"stargateChainID":	101,
							"stargateRelayer": "0x8731d54E9D02c286767d56ac03e8037C07e01e98",
							"realChainID": 1,
							"explorer": "https://etherscan.io/",
							"name": "Ethereum",
							"nativeToken": "ETH",
							"ticker": "ETHUSDT",
							"testnet": false
							} 
			break;
		
		
		// BSC
		case 102:
		case 56:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=56", 
							"busd": {"description": "BUSD is a stablecoin issued by Paxos in partnership with Binance.","link": "https://paxos.com/busd/","address": "0xe9e7cea3dedca5984780bafc599bd69add087d56","decimals": 1e18, "decimalNumber": 18, "poolID": 5},
							"usdt": {"description": "Tether (USDT) is a cryptocurrency with a value meant to mirror the value of the U.S. dollar.","link": "https://tether.to/","address": "0x55d398326f99059fF775485246999027B3197955","decimals": 1e18, "decimalNumber": 18, "poolID": 2},
							"oracle": "0xfbD61B037C325b959c0F6A7e69D8f37770C2c550",
							"stargateChainID":	102,
							"stargateRelayer": "0x4a364f8c717cAAD9A442737Eb7b8A55cc6cf18D8",
							"realChainID": 56,
							"explorer": "https://bscscan.com/",
							"name": "BSC",
							"nativeToken": "BNB",
							"ticker":"BNBUSDT",
							"testnet": false
							} 
			break;
			
			
		// Avalanche
		case 43114:
		case 106:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=43114", 
							"usdc": {"description": "USDC is a fully collateralized US dollar stablecoin, an Ethereum powered coin and is the brainchild of CENTRE, an open source project bootstrapped by contributions from Circle and Coinbase.","link": "https://circle.com/","address": "0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E","decimals": 1e6, "decimalNumber": 6, "poolID": 1},
							"usdt": {"description": "Tether (USDT) is a cryptocurrency with a value meant to mirror the value of the U.S. dollar.","link": "https://tether.to/","address": "0x9702230A8Ea53601f5cD2dc00fDBc13d4dF4A8c7","decimals": 1e6, "decimalNumber": 6, "poolID": 2},
							"oracle": "0xBd0c7AaF0bF082712EbE919a9dD94b2d978f79A9",
							"stargateChainID":	106,
							"stargateRelayer": "0x45A01E4e04F14f7A4a6702c74187c5F6222033cd",
							"realChainID": 43114,
							"explorer": "https://snowtrace.io/",
							"name": "Avalanche",
							"nativeToken": "AVAX",
							"ticker":"AVAXUSDT",
							"testnet": false
							} 
			break;

			
		// Polygon
		case 137:
		case 109:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=137", 
							"usdc": {"description": "USDC is a fully collateralized US dollar stablecoin, an Ethereum powered coin and is the brainchild of CENTRE, an open source project bootstrapped by contributions from Circle and Coinbase.","link": "https://circle.com/","address": "0x2791bca1f2de4661ed88a30c99a7a9449aa84174","decimals": 1e6, "decimalNumber": 6, "poolID": 1},
							"usdt": {"description": "Tether (USDT) is a cryptocurrency with a value meant to mirror the value of the U.S. dollar.","link": "https://tether.to/","address": "0xc2132d05d31c914a87c6611c10748aeb04b58e8f","decimals": 1e6, "decimalNumber": 6, "poolID": 2},
							"dai": {"description": "Dai is a stable cryptocurrency supported by Maker (MKR). To ensure price stability, Dai minimizes the price volatility against the US dollar, through an incentive structure for its participants.", "link": "https://makerdao.com", "address": "0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063", "decimals": 1e18, "decimalNumber": 18, "poolID": 3},
							"oracle": "0x7F069df72b7A39bCE9806e3AfaF579E54D8CF2b9",
							"stargateChainID":	109,
							"stargateRelayer": "0x45A01E4e04F14f7A4a6702c74187c5F6222033cd",
							"realChainID": 137,
							"explorer": "https://polygonscan.com/",
							"name": "Polygon",
							"nativeToken": "MATIC",
							"ticker": "MATICUSDT",
							"testnet": false
							} 
			break;
			
			
		// Arbitrum
		case 42161:
		case 110:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=42161", 
							"usdc": {"description": "USDC is a fully collateralized US dollar stablecoin, an Ethereum powered coin and is the brainchild of CENTRE, an open source project bootstrapped by contributions from Circle and Coinbase.","link": "https://circle.com/","address": "0xff970a61a04b1ca14834a43f5de4533ebddb5cc8","decimals": 1e6, "decimalNumber": 6, "poolID": 1},
							"usdt": {"description": "Tether (USDT) is a cryptocurrency with a value meant to mirror the value of the U.S. dollar.","link": "https://tether.to/","address": "0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9","decimals": 1e6, "decimalNumber": 6, "poolID": 2},
							"oracle": "0x735247fb0a604c0adC6cab38ACE16D0DbA31295F",
							"stargateChainID":	110,
							"stargateRelayer": "0x53Bf833A5d6c4ddA888F69c22C88C9f356a41614",
							"realChainID": 42161,
							"explorer": "https://arbiscan.io/",
							"name": "Arbitrum",
							"nativeToken": "ETH",
							"ticker": "ETHUSDT",
							"testnet": false
							} 
			break;
			
			
		// Optimism
		case 10:
		case 111:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=10", 
							"usdc": {"description": "USDC is a fully collateralized US dollar stablecoin, an Ethereum powered coin and is the brainchild of CENTRE, an open source project bootstrapped by contributions from Circle and Coinbase.","link": "https://circle.com/","address": "0x7f5c764cbc14f9669b88837ca1490cca17c31607","decimals": 1e6, "decimalNumber": 6, "poolID": 1},
							"dai": {"description": "Dai is a stable cryptocurrency supported by Maker (MKR). To ensure price stability, Dai minimizes the price volatility against the US dollar, through an incentive structure for its participants.", "link": "https://makerdao.com", "address": "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1", "decimals": 1e18, "decimalNumber": 18, "poolID": 3},
							"oracle": "0x11DEE30E710B8d4a8630392781Cc3c0046365d4c",
							
							"stargateChainID":	111,
							"stargateRelayer": "0xB0D502E938ed5f4df2E681fE6E419ff29631d62b",
							"realChainID": 10,
							"explorer": "https://optimistic.etherscan.io/",
							"name": "Optimism",
							"nativeToken": "ETH",
							"ticker": "ETHUSDT",
							"testnet": false,
							} 
			break;
			
			
		// Fantom
		case 250:
		case 112:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=250", 
							"usdc": {"description": "USDC is a fully collateralized US dollar stablecoin, an Ethereum powered coin and is the brainchild of CENTRE, an open source project bootstrapped by contributions from Circle and Coinbase.","link": "https://circle.com/","address": "0x04068da6c83afcfa0e13ba15a6696662335d5b75","decimals": 1e6, "decimalNumber": 6, "poolID": 1},
							"oracle": "0xE8E598A1041b6fDB13999D275a202847D9b654ca",
							"stargateChainID":	112,
							"stargateRelayer": "0xAf5191B0De278C7286d6C7CC6ab6BB8A73bA2Cd6",
							"realChainID": 250,
							"explorer": "https://ftmscan.com/",
							"name": "Fantom",
							"nativeToken": "FTM",
							"ticker":"FTMUSDT",
							"testnet": false
							} 
			break;
			
			
			
		/**
			--
			--
			--	TESTNET	------------------------------------------------------------------
			--
			--
		**/
		
		
		// ETH Testnet
		case 5:
		case 10101:
		case 10121:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=5",
							"usdt": {"description": "Tether (USDT) is a cryptocurrency with a value meant to mirror the value of the U.S. dollar.","link": "https://tether.to/", "address": "0x5BCc22abEC37337630C0E0dd41D64fd86CaeE951","decimals": 1e18, "decimalNumber": 18, "poolID": 2},
							"usdc": {"description": "USDC is a fully collateralized US dollar stablecoin, an Ethereum powered coin and is the brainchild of CENTRE, an open source project bootstrapped by contributions from Circle and Coinbase.","link": "https://circle.com", "address": "0xDf0360Ad8C5ccf25095Aa97ee5F2785c8d848620","decimals": 1e6, "decimalNumber": 6, "poolID": 1}, 
							"stargateChainID":	10121,
							"stargateRelayer": "0x7612aE2a34E5A363E137De748801FB4c86499152",
							"realChainID": 5,
							"explorer": "https://goerli.etherscan.io/",
							"name": "Ethereum",
							"nativeToken": "ETH",
							"ticker":"ETHUSDT",
							"testnet": true
							} 
			break;
			
		// BSC Testnet
		case 10102:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=97",	// https://data-seed-prebsc-1-s1.binance.org:8545/ 
							"usdt": {"description": "Tether (USDT) is a cryptocurrency with a value meant to mirror the value of the U.S. dollar.","link": "https://tether.to/","address": "0xF49E250aEB5abDf660d643583AdFd0be41464EfD","decimals": 1e18, "decimalNumber": 18, "poolID": 5},
							"stargateChainID":	10102,
							"stargateRelayer": "0xbB0f1be1E9CE9cB27EA5b0c3a85B7cc3381d8176",
							"realChainID": 97,
							"explorer": "https://testnet.bscscan.com/",
							"name": "BSC",
							"nativeToken": "BNB",
							"ticker":"BNBUSDT",
							"testnet": true
							} 
			break;
			
			
		// Avalanche FUJI
		case 10106:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=43113", // https://api.avax-test.network/ext/bc/C/rpc
							"usdc": {"description": "USDC is a fully collateralized US dollar stablecoin, an Ethereum powered coin and is the brainchild of CENTRE, an open source project bootstrapped by contributions from Circle and Coinbase.","link": "https://circle.com/","address": "0x4A0D1092E9df255cf95D72834Ea9255132782318","decimals": 1e6, "decimalNumber": 6, "poolID": 1},
							"stargateChainID":	10106,
							"realChainID": 43113,
							"stargateRelayer": "0x13093E05Eb890dfA6DacecBdE51d24DabAb2Faa1",
							"explorer": "https://testnet.snowtrace.io/",
							"name": "Avalanche",
							"nativeToken": "AVAX",
							"ticker":"AVAXUSDT",
							"testnet":true
							} 
			break;
			
			
		// Polygon MUMBAI
		case 10109:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=80001", // https://matic-mumbai.chainstacklabs.com
							"usdc": {"description": "USDC is a fully collateralized US dollar stablecoin, an Ethereum powered coin and is the brainchild of CENTRE, an open source project bootstrapped by contributions from Circle and Coinbase.","link": "https://circle.com/","address": "0x742DfA5Aa70a8212857966D491D67B09Ce7D6ec7","decimals": 1e6, "decimalNumber": 6, "poolID": 1},
							"stargateChainID":	10109,
							"realChainID": 80001,
							"stargateRelayer": "0x817436a076060D158204d955E5403b6Ed0A5fac0",
							"explorer": "https://mumbai.polygonscan.com/",
							"name": "Polygon",
							"nativeToken": "MATIC",
							"ticker":"MATICUSDT",
							"testnet": true
							} 
			break;
						
		// Fantom testnet
		case 10112:
			var data	= { "node": ""+REUNIT_API_URL+"?chainID=4002", // https://rpc.testnet.fantom.network/ 
							"usdc": {"description": "USDC is a fully collateralized US dollar stablecoin, an Ethereum powered coin and is the brainchild of CENTRE, an open source project bootstrapped by contributions from Circle and Coinbase.","link": "https://circle.com/","address": "0x076488D244A73DA4Fa843f5A8Cd91F655CA81a1e","decimals": 1e6, "decimalNumber": 6, "poolID": 1},
							"stargateChainID":	10112,
							"stargateRelayer": "0xa73b0a56B29aD790595763e71505FCa2c1abb77f",
							"realChainID": 4002,
							"explorer": "https://testnet.ftmscan.com/",
							"name": "Fantom",
							"nativeToken": "FTM",
							"ticker":"FTMUSDT",
							"testnet": true
							} 
			break;
	}
	return data;
}


function tokenName(chainID,poolID) {
	var tokenName;
	switch(chainID) {
		case 1:
			switch(poolID) {
				case 1:
					tokenName = "USDC";
					break;
				case 2:
					tokenName = "USDT";
					break;
			}
			break;
		case 2:
			switch(poolID) {
				case 2:
					tokenName = "USDT";
					break;
				case 5:
					tokenName = "BUSD";
					break;
			}
			break;
		case 6:
			switch(poolID) {
				case 1:
					tokenName = "USDC";
					break;
				case 2:
					tokenName = "USDT";
					break;
			}
			break;
		case 9:
			switch(poolID) {
				case 1:
					tokenName = "USDC";
					break;
				case 2:
					tokenName = "USDT";
					break;
			}
			break;
		case 10:
			switch(poolID) {
				case 1:
					tokenName = "USDC";
					break;
				case 2:
					tokenName = "USDT";
					break;
			}
			break;
		case 11:
			switch(poolID) {
				case 1:
					tokenName = "USDC";
					break;
			}
			break;
		case 12:
			switch(poolID) {
				case 1:
					tokenName = "USDC";
					break;
			}
			break;
	
	}
	
	return tokenName;
}

function getTimeDiff(previous) {
    
  var seconds = Math.floor((Date.now()/1000 - previous));

  var interval = seconds / 31536000;

  if (interval > 1) {
    return Math.floor(interval) + " years ago";
  }
  interval = seconds / 2592000;
  if (interval > 1) {
    return Math.floor(interval) + " months ago";
  }
  interval = seconds / 86400;
  if (interval > 1) {
    return Math.floor(interval) + " days ago";
  }
  interval = seconds / 3600;
  if (interval > 1) {
    return Math.floor(interval) + " hours ago";
  }
  interval = seconds / 60;
  if (interval > 1) {
    return Math.floor(interval) + " minutes ago";
  }
  return Math.floor(seconds) + " seconds ago";
}

function checkAddress(addr) {
	try {
	let address = addr.toLowerCase();
    if (!/^(0x)?[0-9a-f]{40}$/i.test(address)) {
        return false;
    } else if (/^(0x)?[0-9a-f]{40}$/.test(address) || /^(0x)?[0-9A-F]{40}$/.test(address)) {
        return true;
    } else {
        return false;
    }
    } catch {
    	return false;
    }
}

function checkPrivAddress(addr) {
	try {
	let address = addr.toLowerCase();
    if (!/^(0x)?[0-9a-f]{64}$/i.test(address)) {
        return false;
    } else if (/^(0x)?[0-9a-f]{64}$/.test(address) || /^(0x)?[0-9A-F]{64}$/.test(address)) {
        return true;
    } else {
        return false;
    }
    } catch {
    	return false;
    }
}

function checkTxHash(hash) {
  return /^0x([A-Fa-f0-9]{64})$/.test(hash);
}

function sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
}

function generateUniq(random = false) {
    const sec = Date.now()/Math.random() * 1000 + Math.random() * 1000;
    const id = sec.toString(16).replace(/\./g, "").padEnd(14, "0");
    return `${id}${random ? `.${Math.trunc(Math.random() * 100000000)}`:""}`;
};


function sortJsonDescending(json) {
  var sorted = {};
  var keys = Object.keys(json);
  keys.sort(function(a, b) {
    return b - a;
  });
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    sorted[key] = json[key];
  }
  return sorted;
}

function decimalToWeiName(decimals) {
	the_decimal = parseInt(decimals);
	switch(the_decimal) {
		case 0:
			weiName = "noether";
			break;
		case 1:
			weiName = "wei";
			break;
		case 2:
			weiName	= "two"; // Added to web3.js
			break;
		case 3:
			weiName = "kwei";
			break;
		case 4:
			weiName	= "four"; // Added to web3.js
			break;
		case 5:
			weiName	= "five";
			break;
		case 6:
			weiName = "mwei";
			break;
		case 7:
			weiName	= "seven"; // Added to web3.js
			break;
		case 8:
			weiName = "eight"; // Added to web3.js
			break;
		case 9:
			weiName = "gwei";
			break;
		case 10:
			weiName = "ten"; // Added to web3.js
			break;
		case 11:
			weiName = "eleven"; // Added to web3.js
			break;
		case 12:
			weiName = "microether";
			break;
		case 15:
			weiName = "milliether";
			break;
		case 18:
			weiName = "ether";
			break;
		case 21:
			weiName = "kether";
			break;
		case 24:
			weiName = "mether";
			break;
		case 27:
			weiName = "gether";
			break;
		case 30:
			weiName = "tether";
			break;
		default:
			weiName = "ether";
	}
	return weiName;
}


async function getBinancePrice(ticker) {
	let binance	=	"https://www.binance.com/api/v3/avgPrice?symbol="+ticker;
	let price	=	0;
	
	await $.get(binance).then( function(data) {
		price	=	data.price;
	});
	
	return Number(price);
}


async function initForex() {

	FOREX_PRICE	=	{"USD": new Big(1), "EUR_USD": new Big(1), "GBP_USD": new Big(1), "CNY_USD": new Big(1)};

	try {
	await $.get("https://www.binance.com/bapi/asset/v1/public/asset-service/product/currency").then( function(forex) {
		for(p in forex.data) {
			FOREX_PRICE[forex.data[p].pair]	=	new Big(forex.data[p].rate);
		}
	});
	} catch(e) {
		console.log('%c[initForex] Error', 'background-color:red');
	}
}


var SUPPORTED_STARGATE_TOKEN = ["0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
 "0xdAC17F958D2ee523a2206206994597C13D831ec7",
 "0x6B175474E89094C44Da98b954EedeAC495271d0F",
 "0xe9e7cea3dedca5984780bafc599bd69add087d56",
 "0x55d398326f99059fF775485246999027B3197955",
 "0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E",
 "0x9702230A8Ea53601f5cD2dc00fDBc13d4dF4A8c7",
 "0x2791bca1f2de4661ed88a30c99a7a9449aa84174",
 "0xc2132d05d31c914a87c6611c10748aeb04b58e8f",
 "0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063",
 "0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9",
 "0xff970a61a04b1ca14834a43f5de4533ebddb5cc8",
 "0x7f5c764cbc14f9669b88837ca1490cca17c31607",
 "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1",
 "0x04068da6c83afcfa0e13ba15a6696662335d5b75",
 "0x5BCc22abEC37337630C0E0dd41D64fd86CaeE951",
 "0xDf0360Ad8C5ccf25095Aa97ee5F2785c8d848620",
 "0xF49E250aEB5abDf660d643583AdFd0be41464EfD",
 "0x4A0D1092E9df255cf95D72834Ea9255132782318",
 "0x742DfA5Aa70a8212857966D491D67B09Ce7D6ec7",
 "0x076488D244A73DA4Fa843f5A8Cd91F655CA81a1e"];