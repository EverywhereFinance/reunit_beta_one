var wss_socket	= 	0;
var iv			=	window.crypto.randomUUID().replaceAll('-', '');
var TYPE_WCC	=	0;
var SENT_WCC	=	[];
var RECE_WCC	=	[];
var NEXT_WCC	=	0;
var dApps		=	0;
/**
	---------------------------------------------------------------------------------------------
	description		Utils
	---------------------------------------------------------------------------------------------
**/
function hexToBytes(hex) { 
	for (var bytes = [], c = 0; c < hex.length; c += 2) {
  		bytes.push(parseInt(hex.substr(c, 2), 16));
  	}
	return bytes; 
}

function bytesToHex(bytes) {
    for (var hex = [], i = 0; i < bytes.length; i++) {
        var current = bytes[i] < 0 ? bytes[i] + 256 : bytes[i];
        hex.push((current >>> 4).toString(16));
        hex.push((current & 0xF).toString(16));
    }
    return hex.join("");
}

function generateUUID() {
    const result = ((a, b) => {
        for (b = a = ""; a++ < 36; b += (a * 51) & 52 ? (a ^ 15 ? 8 ^ (Math.random() * (a ^ 20 ? 16 : 4)) : 4).toString(16) : "-") {
        }
        return b;
    })();
    return result;
}

function generatePayloadID() {
    const date = Date.now() * Math.pow(10, 3);
    const extra = Math.floor(Math.random() * Math.pow(10, 3));
    return date + extra;
}


async function encodePayload(key, iv, payload) {
	var enc_key		=	new Uint8Array(hexToBytes(key));
	var enc_iv		=	new Uint8Array(hexToBytes(iv));
	var enc_payload	=	buffer.Buffer.from(JSON.stringify(payload));
	
	var cryptokey	=	await window.crypto.subtle.importKey("raw", enc_key, { name: "AES-CBC" }, true, ["encrypt", "decrypt"]);
	
	var hex_payload	=	await window.crypto.subtle.encrypt({name: "AES-CBC", iv: enc_iv}, cryptokey,  enc_payload);
	
	var hmac				=	await window.crypto.subtle.importKey("raw", enc_key, { name: "HMAC", hash: "SHA-256" }, true, ["sign"]);
	var hexadecimal_payload	=	bytesToHex(new Uint8Array(hex_payload));
	var unsigned			=	new Uint8Array(hexToBytes(""+hexadecimal_payload+""+iv));
	var hmac_signature		=	await window.crypto.subtle.sign( "HMAC", hmac, unsigned );
	var hex_hmac_sign		=	bytesToHex(new Uint8Array(hmac_signature));
	var json				=	{ "data": hexadecimal_payload, "hmac": hex_hmac_sign, "iv": iv};
	var json_text			=	'{"data": "'+hexadecimal_payload+'", "hmac": "'+hex_hmac_sign+'", "iv": "'+iv+'"}';
	return [json,json_text];
}


async function decodePayload(key, iv, payload) {
	var enc_key		=	new Uint8Array(hexToBytes(key));
	var enc_iv		=	new Uint8Array(hexToBytes(iv));
	var enc_payload	=	new Uint8Array(hexToBytes(payload));
	
	var cryptokey 	= 	await window.crypto.subtle.importKey("raw", enc_key, { name: "AES-CBC" }, true, ["encrypt", "decrypt"]);
	
	var txt_payload	=	await window.crypto.subtle.decrypt({ name: "AES-CBC", iv: enc_iv }, cryptokey, enc_payload);
	
	return new TextDecoder().decode(txt_payload);
}

function hextotext(str1) {
	var hex  = str1.toString();
	var str = '';
	for (var n = 0; n < hex.length; n += 2) {
		str += String.fromCharCode(parseInt(hex.substr(n, 2), 16));
	}
	return str;
}


/**
	description		decode Qrcode
**/
function decodeQRCode(qrcode) {
	var url		=	qrcode;
	var tab		=	url.split(":");
	var topic	=	tab[1].split("@")[0];
	var bridge	=	url.split('bridge=')[1].split("&")[0].replace("https%3A%2F%2F", "");
	var key		=	url.split('key=')[1];
	var json	=	{ "topic": topic, "bridge": bridge, "key": key };
	return json;
}