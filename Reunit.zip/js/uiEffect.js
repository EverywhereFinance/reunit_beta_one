/**
	description		copy the public key
**/
$('#copyMyKey').click(function() { try { navigator.clipboard.writeText(REUNIT_PUBKEY); tinyNotif(LANG_HOME.LG43); } catch(e) { } });


/**
	description		Home Buton
**/
function goHome() {
	
	let old_page	=	CURRENT_PAGE;
	CURRENT_PAGE	=	"PAGE_HOME";
	
	$('body').animate({'background-color':'rgb(12,13,19)','background': 'rgb(12,13,19)'}, 100);
	
	switch(old_page) {
		case "PAGE_SEND_ERC20_CONFIRMED":	old_page = "PAGE_SEND_CUSTOM_TOKEN";	break;
	
	}
	
	$("#"+old_page+"").fadeOut(100, function() {
		
		$('#topHeader').animate({'height': '110px', 'background': 'linear-gradient(rgb(13, 29, 49) 0%, rgb(12, 13, 19) 100%)'});
		$('#topHeader').css('background', 'linear-gradient(rgb(13, 29, 49) 0%, rgb(12, 13, 19) 100%)');
		$('#topHeader').css('border-bottom', '0px');
		$('#topHeader_total').fadeIn();
		
	
	
	
	
	// Re-init
	REUNIT_TRANSFER_CHAIN = {}
	initBalance();
	loadBalanceTokensList();
	loadNativeBalance("VIEW_HOME");

	$('.divHomeHistory').html('');
	$('.divHomeHistory').css('height', '1px').css('background', 'linear-gradient(0deg, white, #007bff0d)').css('border-top', '0px');
	$('#DIV_SWAP').hide();
	$('#PAGE_SEND_CONFIRMED').hide();
	$('#PAGE_SEND_TOKEN').hide();
	$('#PSCT_TOP_SEND_CONFIRMATION').hide();
	$('#PAGE_SEND_CUSTOM_TOKEN').hide();
	
	// $('body').animate({'background':'white', 'background-color': 'white'}, 250);
	$('#PAGE_HOME').show('slide', {"direction": "down"}, 500);
	
	$('#PAGE_SEND_DESTINATION_CHAINID').html('<option value="0">Destination</option>');
	$('#PAGE_CONFIRMED_SUMMARY').html('');
	
	$('#WHITE_BACKGROUND').hide();
	$('#QR_CODE').hide();
	
	$('.PST_LOAD_CIRCLE').remove();
	
		
	});
}

$('#iconHomeTop').click(function() { goHome(); });
$('#goHomeFromPSCTERC20').click(function() { goHome(); });
$('#goHomeFromConfirmed').click(function() { goHome(); });
$('#goHomeFromCustomSend').click(function() { goHome(); });

/**
	description		Full reset
					Keep contacts list
**/
$('#RESET_MY_WALLET').click(function() { 
	//chrome.storage.local.clear();
	chrome.storage.session.remove(["REUNIT_PUBKEY"]);
	chrome.storage.local.remove(["REUNIT_WALLET"]);
	chrome.storage.local.remove(["REUNIT_SETTINGS"]);
	chrome.storage.local.remove(["CUSTOM_TOKEN_LIST"]);
	
	REUNIT_PUBKEY			=	"";
	REUNIT_PRIVKEY			=	"";
	REUNIT_BALANCE			=	{"unified_balance": new Big(0)};
	REUNIT_TRANSFER_CHAIN	= 	{}
	
	// UI restart
	$('body').animate({"opacity": 0.1}, { complete: function () { location.reload(); } }, 1000);
	
});

/**
	description		Fast logout
					Keep contacts list
**/
$('.iconLogoutTop').click(function() { 
	chrome.storage.session.remove(["REUNIT_PUBKEY"]);
	$('body').animate({"opacity": 0.03}, { complete: function () { location.reload(); } }, 250);
});

/**
	description		Resize the popup
**/
function popupResize() {
	var topHeader		=	$('#topHeader').height();
	
	switch(CURRENT_PAGE) {
		case "PAGE_WELCOME":
			$('body').css('background-color', '#0d1d2f');
			var toAdd	=	$('#PAGE_WELCOME').height()-30;
			break;
		case "PAGE_LOCKED":
		case "PAGE_HOME":
			var toAdd	=	topHeader+$('#PAGE_HOME').height();
			break;
		case "PAGE_SEND_TOKEN":
			var toAdd	=	topHeader+$('#PAGE_SEND_TOKEN').height()-10;
			break;
		case "POPUP_WALLET_ACCEPT":
			$('#topHeader').show();
			$('#topHeader_total').hide();
			var toAdd	=	topHeader+$('#POPUP_WALLETCONNECT').height()-10;
			break;
		case "PAGE_SEND_ERC20_CONFIRMED":
			var toAdd	=	topHeader+$('#PSCT_TOP_SEND_CONFIRMATION').height();
			break;
		case "PAGE_SEND_CONFIRMED":
			var toAdd	=	topHeader+$('#PAGE_SEND_CONFIRMED').height();
			break;
		case "PAGE_SEND_CUSTOM_TOKEN":
			var toAdd	=	topHeader+$('#PAGE_SEND_CUSTOM_TOKEN').height()-6;
			break;
	}
	
	$('body').css('height', ''+(toAdd+30)+'px');
	$('html').css('background', 'radial-gradient(rgb(13, 29, 49) 0%, rgb(12, 13, 19) 83%)');
	$('html').css('height', ''+(toAdd+30)+'px');
	$('#POPUP_DIV_CONTACT_LIST').css('height', ''+(toAdd-150)+'px');
}

setInterval(function() { popupResize(); },5);


/**
	description		Show current wallet
**/
function showCurrentWallet() {
	$('#TOP_CURRENT_WALLET').html('<span class="topColor">'+REUNIT_PUBKEY.substring(0,6)+'</span>'+REUNIT_PUBKEY.substring(6,9)+'....'+REUNIT_PUBKEY.substring(REUNIT_PUBKEY.length-8,REUNIT_PUBKEY.length-5)+'<span class="topColor">'+REUNIT_PUBKEY.substring(REUNIT_PUBKEY.length-4,REUNIT_PUBKEY.length)+'</span>');
}

/**
	description		Show add token menu
**/
$('#menu_ADDToken').click(function() {
	$('#resultListToken').html('');
	$('#resultListToken').append('<tr> <td> <center> <br/><br/> <br/> <span style="font-family:\'Arial\',sans-serif;">'+LANG_HOME.LG52+' : </span> <br/><br/> <img src="./img/1.svg" style="width:20px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/2.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/6.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/9.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/10.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/42161.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/12.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" />  </center> </td> </tr>');
	$('.addlistIco').css('opacity', '0.1');
	$('.popupHome').hide();
	$('#bgPopup').css('background-color', 'rgb(0 0 0 / 56%)').css('backdrop-filter', 'blur(6px)');
	$('#bgPopup').show("puff", {
		complete: function() { 
			$('#POPUP_MANAGE_CONTACT').hide();
			$('#POPUP_SETTINGS').hide();
			$('#POPUP_ADD_TOKEN').fadeIn(function () {
				$('#searchTokenInput').focus();
				$('.addlistIco1').animate({'opacity': 1},300);
				$('.addlistIco2').animate({'opacity': 1},400);
				$('.addlistIco3').animate({'opacity': 1},500);
				$('.addlistIco4').animate({'opacity': 1},600);
				$('.addlistIco5').animate({'opacity': 1},700);
				$('.addlistIco6').animate({'opacity': 1},800);
				$('.addlistIco7').animate({'opacity': 1},900);
			});
			
			
		} 
	}); 
	
	$('#ADDCUSTOMTOKEN_SEARCH').text(LANG_HOME.LG58);
	$('#POPUP_ADD_TOKEN_CUSTOM').hide();
	$('#POPUP_ADD_TOKEN_CLASSIC').show();
	$('#ADD_CUSTOM_TOKEN_BTN').text(LANG_HOME.LG54);
	$('#ADD_CUSTOM_TOKEN_BTN').unbind();
	$('#ADD_CUSTOM_TOKEN_BTN').click(function() { viewSearchList(1); });
});


/**
	description		Get custom token
**/
function viewSearchList(v) {
	if(v == 1) {
		$('#POPUP_ADD_TOKEN_CLASSIC').hide('slide', {direction: "up"}, 250, function() {
			$('#POPUP_ADD_TOKEN_CUSTOM').show('slide', {direction: "down"}, 250, function() {
				$('#ADD_CUSTOM_TOKEN_BTN').text('Back to search');
				$('#ADDCUSTOMTOKEN_NAME').val('');
				$('#ADDCUSTOMTOKEN_ADDRESS').val('');
				$('#ADD_CUSTOM_TOKEN_BTN').unbind();
				$('#ADD_CUSTOM_TOKEN_BTN').click(function() { viewSearchList(2); });
				$('#ADDCUSTOMTOKEN_RESULT_SEARCH').hide();
				$('#ADDCUSTOMTOKEN_SEARCH').unbind();
				$('#ADDCUSTOMTOKEN_SEARCH').click(function() { searchCustomToken(); });
			});
		});
	} else {
		$('#POPUP_ADD_TOKEN_CUSTOM').fadeOut(250, function() {
			$('#POPUP_ADD_TOKEN_CLASSIC').fadeIn(250, function() {
				$('#ADD_CUSTOM_TOKEN_BTN').text(LANG_HOME.LG54);
				$('#ADD_CUSTOM_TOKEN_BTN').unbind();
				$('#ADD_CUSTOM_TOKEN_BTN').click(function() { viewSearchList(1); });
				
				$('#ADDCUSTOMTOKEN_SEARCH').text(LANG_HOME.LG58);
				$('#ADDCUSTOMTOKEN_RESULT_SEARCH').hide();
				$('#ADDCUSTOMTOKEN_ADDRESS').val('');
				$('#POPUP_ADD_TOKEN_CUSTOM').hide();
				
				$('#ADDCUSTOMTOKEN_SEARCH').unbind();
				$('#ADDCUSTOMTOKEN_SEARCH').click(function() { searchCustomToken(); });
			});
		});
	}
}

$('#ADDCUSTOMTOKEN_ADDRESS').keyup(function() { 
	$('#ADDCUSTOMTOKEN_SEARCH').text(LANG_HOME.LG58);
	$('#ADDCUSTOMTOKEN_RESULT_SEARCH').fadeOut();
	$('#ADDCUSTOMTOKEN_SEARCH').unbind();
	$('#ADDCUSTOMTOKEN_SEARCH').click(function() { searchCustomToken(); });
});

$('#ADDCUSTOMTOKEN_CHAIN').change(function() { 
	$('#ADDCUSTOMTOKEN_CHAIN_LOGO').attr('src', './img/'+$(this).val()+'.svg');
	$('#ADDCUSTOMTOKEN_SEARCH').text(LANG_HOME.LG58);
	$('#ADDCUSTOMTOKEN_RESULT_SEARCH').fadeOut();
	$('#ADDCUSTOMTOKEN_SEARCH').unbind();
	$('#ADDCUSTOMTOKEN_SEARCH').click(function() { searchCustomToken(); });
});


$('#ADD_CUSTOM_TOKEN_BTN').click(function() { viewSearchList(1); });

$('#ADDCUSTOMTOKEN_SEARCH').click(function() { searchCustomToken(); });



$('#SELECT_OFT_CHAIN_DEST').change(async function() { 
	$('#SELECT_OFT_CHAIN_LOGO').attr('src', './img/'+$(this).val()+'.svg');
	
	if($('#SELECT_OFT_CHAIN_DEST').val() != $('#PSCT_INPUT_CHAINID').val()) {
		$('#OFT_DIV_FEES').fadeIn();
		$('#OFT_TRANSFER_FEES').html(' <i class="fa fa-spin reunitGradient fa-spinner-third"></i> Fees..');
		let oft_destination		=	$('#SELECT_OFT_CHAIN_DEST option:selected').attr('stargateChain');
		let oft_token			=	$('#PSCT_INPUT_TOKEN').val();
		let oft_chainData		=	chainsData(Number($('#PSCT_INPUT_CHAINID').val()));
		let web3				=	new Web3(oft_chainData.node);
	
		let estimate_contract	=	new web3.eth.Contract([OFT_ESTIMATE_ABI], oft_token);
	
		try {
			await estimate_contract.methods.estimateSendFee(oft_destination,REUNIT_PUBKEY,'0',"0","0x").call().then(async function(nativeResult) {
				
				let gasPrice				=	await web3.eth.getGasPrice();
				let realNativeResult		=	new Big(nativeResult[0]);

				$('#OFT_TRANSFER_FEES').html(((realNativeResult.mul(1.15)).add(Big(gasPrice).add(Big(gasPrice).div(100).mul(REUNIT_CONFIG.gas_speed)).mul(250000))).div(Big(10).pow(18)).toFixed(6).toString())
				
			});
		} catch(e) {
			console.log('[OFT] Gas estimation failed');
			$('#OFT_TRANSFER_FEES').html('N/A');
		}
	} else { 
		console.log('[OFT] Same chain');
		$('#OFT_DIV_FEES').fadeOut();
	}
});


/**
	description		View settings menu
**/
$('#iconTopSettings').click(function() {
	
	// Re-init UI
	$('.popupHome').hide();
	$('.setBubble').hide();
	$('.sett1').css('height', '25px').css('width', '50px').css('margin-left', '210px').css('margin-top', '0px');
	$('.sett2').css('height', '25px').css('width', '50px').css('margin-left', '295px').css('margin-top', '0px');
	$('.sett3').css('height', '25px').css('width', '50px').css('margin-left', '210px').css('margin-top', '57px');
	$('.sett4').css('height', '25px').css('width', '50px').css('margin-left', '295px').css('margin-top', '57px');
	$('.sett0').css('width', '150px');
	
	$('.sett5').css('width', '344px');
	$('.sett6').css('width', '344px');
	
	$('.viewSettings_lang_content').hide();
	$('.viewSettings_currency_content').hide();
	
	$('#sett3_content').hide();
	$('#sett4_content').hide();
	switch(CURRENT_PAGE) {
		case "PAGE_HOME":
			$('#bgPopup').css('background-color', 'rgb(191 191 191 / 0%)').css('backdrop-filter', 'blur(17px)');
			$('.settingsIcon').css('background-color', 'rgb(255 255 255 / 52%)').css('backdrop-filter', 'blur(6px)').css('border-left', '1px solid #e7e7e7').css('border-top', '1px solid #e7e7e7');
			break;
		case "PAGE_SEND_TOKEN":
			$('#bgPopup').css('background-color', 'rgb(249 249 249 / 11%)').css('backdrop-filter', 'blur(17px)');
			$('.settingsIcon').css('background-color', 'rgb(255 255 255 / 73%)').css('backdrop-filter', 'blur(0px)').css('border-left', '0px solid transparent').css('border-top', '0px solid transparent');
			break;
		case "POPUP_WALLET_ACCEPT":
			$('#bgPopup').css('background-color', 'rgb(0 0 0 / 20%)').css('backdrop-filter', 'blur(6px)');
			$('.settingsIcon').css('background-color', 'rgb(255 255 255 / 73%)').css('backdrop-filter', 'blur(0px)').css('border-left', '0px solid transparent').css('border-top', '0px solid transparent');
			break;
		case "PAGE_SEND_CONFIRMED":
			$('#bgPopup').css('background-color', 'rgb(0 0 0 / 20%)').css('backdrop-filter', 'blur(6px)');
			$('.settingsIcon').css('background-color', 'rgb(255 255 255 / 73%)').css('backdrop-filter', 'blur(0px)').css('border-left', '0px solid transparent').css('border-top', '0px solid transparent');
			break;
		case "PAGE_SEND_CUSTOM_TOKEN":
			$('#bgPopup').css('background-color', 'rgb(0 0 0 / 20%)').css('backdrop-filter', 'blur(6px)');
			$('.settingsIcon').css('background-color', 'rgb(255 255 255 / 73%)').css('backdrop-filter', 'blur(0px)').css('border-left', '0px solid transparent').css('border-top', '0px solid transparent');
			break;
	}
	
	
	
	
	
	
	$('.sett0_flag').unbind();
	$('.sett0_flag').click(async function() {
	
	let selected_flag	=	$(this).attr('country');
	// Update config
	REUNIT_CONFIG.lang	=	selected_flag;
	// Update UI
	$('#sett0_img_lang').attr('src', './img/flag/'+selected_flag.toLowerCase()+'.png');
	
	switch(REUNIT_CONFIG.lang) {
   		case "EN":	$('#sett0_lang_text').html('English');	break;
   		case "RU":	$('#sett0_lang_text').html('Russian');	break;
   		case "FR":	$('#sett0_lang_text').html('French');	break;
   		case "KR":	$('#sett0_lang_text').html('Korean');	break;
   		case "CN":	$('#sett0_lang_text').html('Chinese');	break;
   		case "ES":	$('#sett0_lang_text').html('Spanish');	break;
   		case "IT":	$('#sett0_lang_text').html('Italian');	break;
   		
   	
   
   	}
	// Update Langage
	getLang(REUNIT_CONFIG.lang);
		
	tinyNotif('Lang updated', 300);
	});

	$('.sett0_currency').unbind();
	$('.sett0_currency').click( async function() {
	let selected_currency	=	$(this).attr('currency');
	
	// Update config
   	REUNIT_CONFIG.currency	= selected_currency;
   	
   	switch(REUNIT_CONFIG.currency) {
   		case "USD":		$('.sett0_currency_text').html('US Dollars');		$('.sett0_sign_currency').html('<i class="fa-light fa-dollar-sign" style="font-size:25px;color:#3D3D3D;"></i>');	break;
   		case "EUR_USD":	$('.sett0_currency_text').html('Euro');				$('.sett0_sign_currency').html('<i class="fa-light fa-euro-sign" style="font-size:25px;color:#3D3D3D;"></i>');		break;
   		case "GBP_USD":	$('.sett0_currency_text').html('Pound sterling');	$('.sett0_sign_currency').html('<i class="fa-light fa-sterling-sign" style="font-size:25px;color:#3D3D3D;"></i>');	break;
   		case "CNY_USD":	$('.sett0_currency_text').html('Yen');				$('.sett0_sign_currency').html('<i class="fa-light fa-yen-sign" style="font-size:25px;color:#3D3D3D;"></i>');		break;
   	}
   	
   	tinyNotif('Currency updated', 300);
   
   	goHome();
	});

	
	
	
	$('.sett10').unbind();
	$('.sett10').click(async function() {
	chrome.storage.session.remove(["REUNIT_PUBKEY"]);
	$('body').fadeOut({complete: function() { location.reload(); }}, 200);
	});



	$('#bgPopup').fadeIn({
		complete: function() {
			// UI EFFECT
			$('#POPUP_SETTINGS').show();
			$('.settingsIcon').hide();
			$('.sett0').show('puff', 100);
			$('.sett1').show('puff', 200);
			$('.sett2').show('puff', 300);
			$('.sett3').show('puff', 400);
			$('.sett4').show('puff', 500);
			$('.sett5').show('puff', 500);
			$('.sett6').show('puff', 510);
			$('.sett7').show('puff', 520);
			$('.sett8').show('puff', 530);
			$('.sett9').show('puff', 550);
			$('.sett10').show('puff', {
				complete: function () {
					// Bubble notif
					$('.setBubble').fadeIn();
				}
			}, 600);

			loadUISettings(); 
			$('#POPUP_MANAGE_CONTACT').hide();
			
		}
	});

});

/**
	description		Show contacts
**/
$('.manageContact').click(function() {
	let p	=	$(this).attr('page');
	$('.popupHome').hide();
	$('#bgPopup').css('background-color', 'rgb(0 0 0 / 75%)').css('backdrop-filter', 'blur(6px)');
	$('#bgPopup').show("puff", {
		complete: function() { 
			$('#POPUP_ADD_TOKEN').hide();
			$('#POPUP_SETTINGS').hide();
			$('#POPUP_MANAGE_CONTACT').fadeIn();
			
			// UI
			$('.reinitLetter').hide();
			$('.trContactFullText').show();
			$('.selectLetter').css('opacity', '0.5').css('font-weight', 'normal').css('text-decoration', 'none').css('color', 'white');
	
			// Load contacts list
			
			loadContact(p);
			
		} 
	}); 
});


/**
	description		Add contact
**/
$('.addContactBTN').click(function() {
	let contact_cid			=	Date.now();
	let line_add_contact	=	`<tr id="TR_TOP_CONTACT_${contact_cid}" ><td style="height:10px;"></td></tr>
									<tr id="TR_CONTENT_CONTACT_${contact_cid}" class="trAddContact">
										<td style="border-top-left-radius:10px;border-bottom-left-radius:10px;" class="selectContact confContact_${contact_cid}"  address="">
											<img id="CONF_CONTACT_${contact_cid}_PICTURE" src="./img/logo_400.jpeg" style="box-shadow:0px 0px 3px #ffffff6b;width:50px;border-radius:10px;" />
										</td>
										
										<td style="font-size: 13px;padding-left: 20px;width:270px;">
											
											<div id="VIEW_CONTACT_ID_${contact_cid}" style="display:none;" class="selectContact confContact_${contact_cid}"  address="">
												<span id="CONF_CONTACT_${contact_cid}_NAME" class="reunitGradient" style="font-weight: bold;"></span>
												<span id="CONF_CONTACT_${contact_cid}_PSEUDO" style="font-size: 12px;"> </span>
												<br/>
												<span id="CONF_CONTACT_${contact_cid}_ADDRESS" style="font-family:'Arial', sans-serif;font-size:12px;">
												
												</span>
											</div>
								
											<div id="EDIT_CONTACT_ID_${contact_cid}">
												<input id="CONTACT_${contact_cid}_INPUT_NAME" autocorrect="false" spellcheck="false" placeholder="Name" type="text" style="outline:none;width:125px;background-color:transparent;color:#d27ea6;border:0px;border-bottom:1px dashed #FFFFFF50;font-size:13px;font-family:'Open Sans';" value="" /> | 
												<input id="CONTACT_${contact_cid}_INPUT_PSEUDO" autocorrect="false" spellcheck="false" placeholder="Twitter / Telegram / Mail" type="text" style="outline:none;width:125px;background-color:transparent;color:white;border:0px;border-bottom:1px dashed #FFFFFF50;font-size:12px;font-family:'Open Sans';" value="" />
												<br/>
												<input id="CONTACT_${contact_cid}_INPUT_ADDRESS" autocorrect="false" spellcheck="false" placeholder="Address" type="text" style="margin-top:10px;outline:none;width:265px;background-color:transparent;color:white;border:0px;border-bottom:1px dashed #FFFFFF50;font-size:11px;font-family:'Arial';" value="" />
											</div>
										</td>
										
										<td style="width:30px;text-align:center;font-size:16px;border-top-right-radius:10px;border-bottom-right-radius:10px;">
											<i contact_id="${contact_cid}" style="opacity:0.5;" class="deleteContact toOpacOne fa-light fa-xmark"></i>
											<br/>
											<i id="ICON_VALID_CONTACT_ID_${contact_cid}" style="opacity:0.5;margin-top:7px;" class="toOpacOne fa-light fa-check validAddContact" contact_id="${contact_cid}"></i>
										</td>
									</tr>`;
	
	$('#TABLE_POPUP_CONTACT_LIST').prepend(line_add_contact);
	$('#CONTACT_'+contact_cid+'_INPUT_NAME').focus();
	
	// UI Update
	$('.deleteContact').unbind('click');
	$('.deleteContact').click(function () {
		let cid	=	$(this).attr('contact_id');
		updateContact("DELETE", cid);
	});
	
	$('.validAddContact').unbind('click');
	$('.validAddContact').click(function () {
		let cid	=	$(this).attr('contact_id');
		updateContact("ADD", cid);
	});
});

/**
	description		Search contact
**/
$('#searchContactInput').keyup(function () {
	let text_search		=	$(this).val().toLowerCase();
	
	$('.trContactFullText').each( function() {
		let full_text	=	$(this).attr('fulltext').toLowerCase();
		
		if(full_text.includes(text_search)) {
			$(this).show();
		} else {
			$(this).hide();
		}
	});
	
	if(text_search.length == 0) {
		$('.trContactFullText').show();
	} else { } 
	
	$('.reinitLetter').hide();
	$('.selectLetter').css('opacity', '0.5').css('font-weight', 'normal').css('text-decoration', 'none').css('color', 'white');

});


/**
	description		Filter contact by start letter
**/
$('.selectLetter').click(function() {
	
	$('.reinitLetter').fadeIn();
	
	$('.selectLetter').css('opacity', '0.5').css('font-weight', 'normal').css('text-decoration', 'none').css('color', 'white');
	$(this).css('opacity', '1').css('font-weight', 'bold').css('text-decoration', 'underline').css('color', 'white');
	
	let selected_letter	=	$(this).text().toLowerCase();
	$('.trContactFullText').each( function() {
		let full_text	=	$(this).attr('fulltext').toLowerCase();
		
		if(full_text.includes("_"+selected_letter)) {
			$(this).show();
		} else {
			$(this).hide();
		}
	});
});


$('.reinitLetter').click(function() {
	$('.reinitLetter').fadeOut();
	$('.trContactFullText').show();
	$('.selectLetter').css('opacity', '0.5').css('font-weight', 'normal').css('text-decoration', 'none').css('color', 'white');
});

/**
	description		Mange tokens -> Home
**/
$('#goHomeFromAddToken').click(function() {
	$('#POPUP_ADD_TOKEN').fadeOut();
	$('#bgPopup').hide("drop");
	
	showSelectedTokens(1);
});

/**
	description		Manage list -> Home
**/
$('#goHomeFromManageContact').click(function() {
	$('#POPUP_MANAGE_CONTACT').fadeOut();
	$('#bgPopup').hide("drop");
});


$('#goHomeFromSettings').click(function() { 
	$('#POPUP_SETTINGS').fadeOut();
	$('#bgPopup').hide("drop");
});

/**
	description		Show QRCode 
**/
$('#viewQrCode').click(function() { viewQrCode(1); });


/**
	description		View Gas Price
**/
$('#viewGasPrice').click(function () {
	if($('#PST_TOP_CENTER_GAS_DIV').is(":hidden")) {
		$('#PST_TOP_CENTER_GAS_DIV').show("slide", {direction: 'up'});
		loadGasPrice();
	} else {
		$('#PST_TOP_CENTER_GAS_DIV').hide("slide", {direction: 'up'});
	}

});

/**
	description		Search token
**/
$('#searchTokenInput').keyup(function() {
  searchInsideTokenList();
});

/**
	description		Import wallet 
**/
$('#importWalletBTN').click(async function() {  
	$('#PAGE_WELCOME_CHOICE').hide();
	$('#PAGE_WELCOME_TOP_TEXT').hide();
	$('#PAGE_WELCOME_CHOICE_IMPORT').fadeIn();
	$('#PAGE_WELCOME').css('min-height', '400px');  
});


/**
	description		Import seed phrase
**/
$('#importSeedBTN').click(async function() {
	$('#PAGE_WELCOME_CHOICE').hide();
	$('#PAGE_WELCOME_TOP_TEXT').hide();
	$('#PAGE_WELCOME_IMPORT_SEED').fadeIn();
	$('#PAGE_WELCOME').css('min-height', '400px');
});

/**
	description		Import seed phrase step 2
**/

async function uiImportSeed() {
	let imp_i 	= 	1;
	let imp_w	=	'';
	while(imp_i <= 12) {  
		if(imp_i == 1) { imp_w = $('#TDS'+imp_i+'').val();  } else { imp_w = imp_w+' '+$('#TDS'+imp_i+'').val(); }
		imp_i += 1; 
	}
	$('#IMPORT_SEED_STEP1').hide("slide", 
		{
		direction: 'left',
		complete: function() {
			$('#PAGE_WELCOME_IMPORT_SUB_TEXT').hide();
			$('#PAGE_WELCOME_IMPORT_SUB_TEXT2').show();
			$('#IMPORT_SEED_STEP2').show("slide", {
				direction: 'right', 
				complete: function() { importFromSeedPhrase(imp_w,1); } 
			});
		}
	});
}
$('#checkImportedSeed').click(async function() {
	uiImportSeed();
});


$('#checkUserSeed').click(async function() { 

	generateNewWallet(2); 

});

	
$('#createNewWalletBTN').click(async function() {
	$('#PAGE_WELCOME_CHOICE').hide();
	$('#PAGE_WELCOME_TOP_TEXT').hide();
	$('#PAGE_WELCOME_CREATE_WALLET').fadeIn();
	$('#PAGE_WELCOME').css('min-height', '400px'); 
	
	generateNewWallet(1);
});


$('#HOME_IMPORT_privKeyInput').keyup(async function() {
	if(checkPrivAddress($(this).val())) {
	
		$('#TIW_logo_one').css('color', '#acf3a6');
	
	} else {
		$('#TIW_logo_one').css('color', '#ff6c6c');
	}
});


$('#importMyWalletBTN').click(async function() {  uiVerifImport(1); });
$('#HOME_IMPORT_ACCOUNT_PASS').keyup(async function() { uiVerifImport(0); });
$('#HOME_IMPORT_ACCOUNT_PASS_CONFIRM').keyup(async function() { uiVerifImport(0); });


$('#IMPORT_SEED_PASS_CONFIRM').keyup(async function() { 
	let sp	=	$('#IMPORT_SEED_PASS').val();
	let spc	=	$(this).val();
	
	if(sp == spc && sp.length >= 8) {
		$('#ICS_logo_two').css('color', '#acf3a6');
		$('#ICS_logo_one').css('color', '#acf3a6');
		$('#ICS_logo_one').removeClass('fa-lock-keyhole-open').addClass('fa-lock-keyhole');
		$('#ICS_logo_two').removeClass('fa-lock-keyhole-open').addClass('fa-lock-keyhole');
	} else {
		$('#ICS_logo_two').css('color', '#ff6c6c');
		$('#ICS_logo_one').css('color', '#ff6c6c');
		$('#ICS_logo_one').removeClass('fa-lock-keyhole').addClass('fa-lock-keyhole-open');
		$('#ICS_logo_two').removeClass('fa-lock-keyhole').addClass('fa-lock-keyhole-open');
	}
	
});



$('#goWelcomeFromImportSeed').click(async function() {
	$('.tdImportSeed').val('');
	$('#IMPORT_SEED_PASS').val('');
	$('#IMPORT_SEED_PASS_CONFIRM').val('');
	
	$('#PAGE_WELCOME_IMPORT_SEED').hide("slide", {
		direction: 'right',
		complete: function() {
			$('#PAGE_WELCOME_CHOICE').fadeIn();
			$('#PAGE_WELCOME_TOP_TEXT').fadeIn();
			$('#PAGE_WELCOME_IMPORT_SUB_TEXT').show();
			$('#PAGE_WELCOME_IMPORT_SUB_TEXT2').hide();
			$('#IMPORT_SEED_STEP2').hide();
			$('#IMPORT_SEED_STEP1').show();
		}
	});
	
	$('#checkImportedSeed').unbind('click');
	$('#checkImportedSeed').click(async function() { uiImportSeed(); });
	
});

$('#goWelcomeFromImportWallet').click(async function() {
	$('#PAGE_WELCOME_CHOICE_IMPORT').hide("slide", {
		direction: 'right',
		complete: function() {
			$('#PAGE_WELCOME_CHOICE').fadeIn();
			$('#PAGE_WELCOME_TOP_TEXT').fadeIn();
			
			$('#HOME_IMPORT_privKeyInput').val('');
			$('#HOME_IMPORT_ACCOUNT_PASS').val('');
			$('#HOME_IMPORT_ACCOUNT_PASS_CONFIRM').val('');
			$('#TIW_logo_one').css('color', 'white');
			$('#TIW_logo_two').css('color', 'white');
			$('#TIW_logo_three').css('color', 'white');
			$('#TIW_logo_three').removeClass('fa-lock-keyhole').addClass('fa-lock-keyhole-open');
			$('#TIW_logo_two').removeClass('fa-lock-keyhole').addClass('fa-lock-keyhole-open');
		}
	});

});



$('#goWelcomeFromNewWallet').click(async function() {
	$('#PAGE_WELCOME_CREATE_WALLET').hide("slide", {
		direction: 'right',
		complete: function() {
			$('#PAGE_WELCOME_CHOICE').fadeIn();
			$('#PAGE_WELCOME_TOP_TEXT').fadeIn();
			uiReinitCreate();
		}
	});
});

function uiReinitCreate() {
	$('#PAGE_WELCOME_CREATE_WALLET').css('opacity', '1');
	$('#TABLE_SEED_WORD').html('<tr> <td class="tdCreateWallet tdWall_1">1</td> <td id="NEW_WALL_1" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> <td class="tdCreateWallet tdWall_2">2</td> <td id="NEW_WALL_2" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> <td class="tdCreateWallet tdWall_3">3</td> <td id="NEW_WALL_3" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> </tr> <tr> <td class="tdCreateWallet tdWall_4">4</td> <td id="NEW_WALL_4" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> <td class="tdCreateWallet tdWall_5">5</td> <td id="NEW_WALL_5" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> <td class="tdCreateWallet tdWall_6">6</td> <td id="NEW_WALL_6" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> </tr> <tr> <td class="tdCreateWallet tdWall_7">7</td> <td id="NEW_WALL_7" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> <td class="tdCreateWallet tdWall_8">8</td> <td id="NEW_WALL_8" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> <td class="tdCreateWallet tdWall_9">9</td> <td id="NEW_WALL_9" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> </tr> <tr> <td class="tdCreateWallet tdWall_10">10</td> <td id="NEW_WALL_10" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> <td class="tdCreateWallet tdWall_11">11</td> <td id="NEW_WALL_11" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> <td class="tdCreateWallet tdWall_12">12</td> <td id="NEW_WALL_12" class="tdCreateWalletText"><i class="fa-duotone fa-spinner-third fa-spin"></i></td> </tr> <tr> <td id="PAGE_WELCOM_NEW_PUBKEY" colspan="6" style="text-align:center;font-weight:normal;font-size:14px;"> </td> </tr>');
	$('.tdCreateWallet').css('opacity', '1');
	$('.tdCreateWalletText').css('opacity', '1');
	$('#PAGE_WELCOME_CREATE_WALLET_SUB_TEXT').hide();
	$('#checkUserSeed').html('Next <i class="fa-duotone fa-chevrons-right"></i>');
	$('#TABLE_SEED_WORD').show();
	$('#TABLE_SEED_ACCOUNT').hide();
	
	$('#TABLE_SEED_ACCOUNT').html('<table border="0" style="width:100%;border:1px solid #FFFFFF30;border-radius: 10px;"> <tr> <td style="text-align:center;color:white;"><i id="TSA_keyhole_pass" class="fa-thin fa-lock-keyhole-open"></i></td> <td> <input id="TABLE_SEED_ACCOUNT_PASS" autofocus="" type="password" autocomplete="off" spellcheck="false" autocorrect="off" placeholder="Type a password..." style="font-family:\'Roboto\',sans-serif;font-size:14px;outline:none;background-color:transparent;color:white;border:0px;padding:10px;width:100%;position:relative;"> </td> </tr> </table> <br/><br/> <table border="0" style="width:100%;border:1px solid #FFFFFF30;border-radius: 10px;"> <tr> <td style="text-align:center;color:white;"><i id="TSA_keyhole_pass_conf" class="fa-thin fa-lock-keyhole-open"></i></td> <td> <input id="TABLE_SEED_ACCOUNT_PASS_CONFIRM" autofocus="" type="password" autocomplete="off" spellcheck="false" autocorrect="off" placeholder="Confirm your password..." style="font-family:\'Roboto\',sans-serif;font-size:14px;outline:none;background-color:transparent;color:white;border:0px;padding:10px;width:100%;position:relative;"> </td> </tr> </table>');

	$('#PAGE_WELCOME_CREATE_ACCOUNT_SUB_TEXT').hide();
	
	$('#checkUserSeed').unbind('click');
	$('#checkUserSeed').click(async function() { generateNewWallet(2); });
}

function uiVerifImport(val) {
	let pass		=	$('#HOME_IMPORT_ACCOUNT_PASS').val();
	let passConfirm	=	$('#HOME_IMPORT_ACCOUNT_PASS_CONFIRM').val();
	
	if(pass == passConfirm && pass.length >= 8) {
		$('#TIW_logo_two').css('color', '#acf3a6');
		$('#TIW_logo_three').css('color', '#acf3a6');
		$('#TIW_logo_three').removeClass('fa-lock-keyhole-open').addClass('fa-lock-keyhole');
		$('#TIW_logo_two').removeClass('fa-lock-keyhole-open').addClass('fa-lock-keyhole');
		
		
		if(val == 1) { walletImport(); } else { }
	
	} 
	else {
	
		$('#TIW_logo_two').css('color', '#ff6c6c');
		$('#TIW_logo_three').css('color', '#ff6c6c');
		$('#TIW_logo_three').removeClass('fa-lock-keyhole').addClass('fa-lock-keyhole-open');
		$('#TIW_logo_two').removeClass('fa-lock-keyhole').addClass('fa-lock-keyhole-open');
		
			
	}
	
	
}
			
function viewQrCode(val) {
	
	if(val == 1) {
		$('#viewQrCode').unbind( "click" );
		$('#viewQrCode').click(function() { viewQrCode(2); });
		
		$('#REUNIT_PUB_QRCODE').html('');
		$('#REUNIT_PUB_QRCODE').qrcode({text: REUNIT_PUBKEY, ecLevel: 'L', render: 'div', size:130, radius: 0,fill:"white",background:"transparent"});
		$('#QRCODE_SHOW_TEXT').html(REUNIT_PUBKEY);
		$('#WHITE_BACKGROUND').fadeIn();
		$('#QR_CODE').slideDown();
		
		
		$('#WHITE_BACKGROUND').click(function () { viewQrCode(2); });
		
	} else {
		
		$('#viewQrCode').unbind( "click" );
		$('#WHITE_BACKGROUND').unbind("click");
		$('#viewQrCode').click(function() { viewQrCode(1); });
		$('#WHITE_BACKGROUND').fadeOut();
		
		$('#QR_CODE').slideUp(function() {
			$('#QRCODE_SHOW_TEXT').html('');
			$('#REUNIT_PUB_QRCODE').html('');
		});
		
	}
	
	
	
}



$('.viewSettings_0').click(async function() {
	let current_width	=	$('.sett0').css('width');
	if(current_width != "345px") {
		$('.sett0_td').css('width', '300px');
		$('.sett0').animate({ "width": "345px"}, 300, function() {
		
			$('.viewSettings_lang_content').show();
			$('.viewSettings_currency_content').show();
		
		});
		
		$('.sett1').animate({ "margin-top": "113px"}, 300);
		$('.sett2').animate({ "margin-top": "113px"}, 300);
		
		let set3_width		=	$('.sett3').css("width");
		let set4_width		=	$('.sett4').css("width");
		
		if(set3_width == "135px" || set4_width == "135px") {
			$('.sett3').animate({ "margin-top": "113px"}, 300);
			$('.sett4').animate({ "margin-top": "113px"}, 300);
		} else {
			$('.sett3').animate({ "margin-top": "169px"}, 300);
			$('.sett4').animate({ "margin-top": "169px"}, 300);
		}
		
		
		$('.sett5').animate({ width: "150px"}, 300);
		$('.sett6').animate({ width: "150px"}, 300);
		
		$('#settings_text_speed').hide();
		$('#settings_text_locktime').hide();
		
		

	} else {
		$('.viewSettings_lang_content').hide();
		$('.viewSettings_currency_content').hide();
		
		$('.sett0_td').css('width', '110px');
		$('.sett0').animate({ "width": "150px"}, 300);
		$('.sett1').animate({ "margin-top": "0"}, 300);
		$('.sett2').animate({ "margin-top": "0"}, 300);
		
		let set3_top		=	$('.sett3').css("margin-top");
		let set4_top		=	$('.sett4').css("margin-top");
		if(set3_top	== "113px" || set4_top == "113px") {
			$('.sett3').animate({ "margin-top": "0px"}, 300);
			$('.sett4').animate({ "margin-top": "0px"}, 300);
		} else {
			$('.sett3').animate({ "margin-top": "57px"}, 300);
			$('.sett4').animate({ "margin-top": "57px"}, 300);
		}
		
		
		$('.sett5').animate({ width: "344px"}, 300);
		$('.sett6').animate({ width: "344px"}, 300);
		$('#settings_text_speed').fadeIn();
		$('#settings_text_locktime').fadeIn();
			
	
	}
});


$('.viewSettings_1').click(async function() {
	/**
	let current_width	=	$('.sett1').css('width');
	if(current_width == "50px") {
		$('.sett1').animate({ "width": "135px", "height": "82px"}, 300);
		$('.sett2').hide('puff', 150);
		$('.sett3').hide('puff', 150);
		$('.sett4').hide('puff', 150);
	
	} else {
		$('.sett1').animate({ "width": "50px", "height": "25px"}, 300);
		$('.sett2').show('puff', 150);
		$('.sett3').show('puff', 150);
		$('.sett4').show('puff', 150);
	}
	**/
	$('#IMPORT_WALLET').click();
});


$('.viewSettings_2').click(async function() {
	export_wallet();
	tinyNotif('Wallet exported', 300);
});

$('.viewSettings_3').click(async function() {
	let current_width	=	$('.sett3').css('width');
	let set1_top		=	$('.sett1').css("margin-top");
	
	if(current_width == "50px") {
		if(set1_top == "113px") {
			$('.sett3').animate({ "width": "135px", "height": "82px", "margin-top": "113px"}, 300);	
		} else {
			$('.sett3').animate({ "width": "135px", "height": "82px", "margin-top": "0px"}, 300);
		}
		
		$('.sett1').hide('puff', 150);
		$('.sett2').hide('puff', 150);
		$('.sett4').hide('puff', 150);
		$('#sett3_content').show();
	
	} else {
		if(set1_top == "113px") {
			$('.sett3').animate({ "width": "50px", "height": "25px", "margin-top": "169px"}, 300);
			$('.sett4').css("width", "50px").css("height", "25px").css("margin-top", "169px");
		} else {
			$('.sett3').animate({ "width": "50px", "height": "25px", "margin-top": "57px"}, 300);
			$('.sett4').css("width", "50px").css("height", "25px").css("margin-top", "57px");
		}
		
		$('.sett1').show('puff', 150);
		$('.sett2').show('puff', 150);
		$('.sett4').show('puff', 150);
		$('#sett3_content').hide();
	}

});

$('.viewSettings_4').click(async function() {
	let current_width	=	$('.sett4').css('width');
	let set1_top		=	$('.sett1').css("margin-top");
	
	if(current_width == "50px") {
		if(set1_top == "113px") {
			$('.sett4').animate({ "width": "135px", "height": "82px", "margin-top": "113px", "margin-left": "210px"}, 300);	
		} else {
			$('.sett4').animate({ "width": "135px", "height": "82px", "margin-top": "0px", "margin-left": "210px"}, 300);
		}
		
		$('.sett1').hide('puff', 150);
		$('.sett2').hide('puff', 150);
		$('.sett3').hide('puff', 150);
		$('#sett4_content').show();
	
	} else {
		if(set1_top == "113px") {
			$('.sett4').animate({ "width": "50px", "height": "25px", "margin-top": "169px", "margin-left": "295px"}, 300);
			$('.sett3').css("width", "50px").css("height", "25px").css("margin-top", "169px");
		} else {
			$('.sett4').animate({ "width": "50px", "height": "25px", "margin-top": "57px", "margin-left": "295px"}, 300);
			$('.sett3').css("width", "50px").css("height", "25px").css("margin-top", "57px");
		}
		
		$('.sett1').show('puff', 150);
		$('.sett2').show('puff', 150);
		$('.sett3').show('puff', 150);
		$('#sett4_content').hide();
	}

});

$('.sett7').click(async function() {
	let current_state	=	REUNIT_CONFIG.network;
	
	if(current_state == "testnet") {
		
		$('.viewSettings_7').hide('slide', {direction: "left"}, 250, function() {
			$('#CURRENT_NETWORK_OPTION').text('MAINNET');
			$('.viewSettings_7').show('slide', {direction: "right"}, 250);
		});
		
   		REUNIT_CONFIG.network	= "mainnet";
   		switchNetwork(REUNIT_CONFIG.network);
   		
   		
	} else {
		$('.viewSettings_7').hide('slide', {direction: "left"}, 250, function() {
			$('#CURRENT_NETWORK_OPTION').text('TESTNET');
			$('.viewSettings_7').show('slide', {direction: "right"}, 250);
		});
		
   		REUNIT_CONFIG.network	= "testnet";
   		switchNetwork(REUNIT_CONFIG.network);
		
	}
	
});



$('#unlock_submit').click(async function() {
	let p	=	$('#unlock_input').val();
	unlockWallet(p,'lock_page');
});

$('#unlock_input').keyup(async function(e) {
	if(e.which == 13) {
		let p	=	$('#unlock_input').val();
		unlockWallet(p,'lock_page');
	} else { }
});


$('#unlockToSend_button').click(async function() {
	let p	=	$('#unlockToSend_input').val();
	unlockWallet(p,'stargate_page');
});


function showReunitTransferError(chainID,tokenName,nativeToken,type,m) {
 	$('.TABLE_SEND_TD_'+chainID).css('opacity', '0');
 	$('#TABLE_SEND_DIV_NOTENOUGH_'+chainID).show();
	$('#TABLE_SEND_DIV_NOTENOUGH_'+chainID+' .tx_warning_message').html(m);
 	
 	if(type == 0) { $('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID+'').hide(); }
 	else { $('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID+'').show(); }

 	currentAmount	=	new Big(REUNIT_TRANSFER_CHAIN[chainID]); 
	currentTotal	=	new Big($('#PAGE_SEND_INPUT_TOTAL_AMOUNT_TO_SEND').val());
	newAmount		=	currentTotal.minus(currentAmount);
	
	$('#PAGE_SEND_TOTAL_AMOUNT_TO_SEND').html(''+newAmount+'');
	$('#PAGE_SEND_INPUT_TOTAL_AMOUNT_TO_SEND').val(newAmount);
	$("#"+chainID+"_"+tokenName+"_TO_SEND").html(0);
	$("#"+chainID+"_"+tokenName+"_AMOUNT").val(0);
       	 										
	REUNIT_TRANSFER_CHAIN[chainID]	=	new Big(0);
	calculTotal(chainID,tokenName);
}


function viewInfo(index,type,tokenID,chainID) {
	console.log('[viewInfo] Start loading UI info interface');
	let divID	=	"#HOME_HISTORY_"+index;
	let tableID	=	"TABLE_HISTORY_"+index;
	$(divID).css('border-top', '1px solid #efefef').css('width', '99%').css('background-color', 'white');
	
	$(divID).html(`
		<div style="width:1px;height:5px;"></div>
		<div parentDiv="${divID}" class="exitHistory" style="position:relative;cursor:pointer;float:right;right:10px;margin-top:8px;color:#0d1725;font-size:14px;">
			<i class="fa fa-xmark"></i>
		</div>
		
		<div style="text-align:center;margin-top:10px;">
			<span style="font-size:16px;font-weight:bold;color:0d1725;font-family:'Open Sans'">Token information</span>
		</div>
		
		<div id="${tableID}" style="overflow:auto;-ms-overflow-style: none; scrollbar-width: none;height:240px;">
			
			<table border="0" style="color: black; font-size: 14px; margin-top: 20px; width: 90%; margin-left: 5%;">
				<tr>
					<td valign="top" style="font-weight:bold;">Tags</td>
					<td style="padding-left:10px;font-family:'Open-Sans',sans-serif;font-size:13px;" id="TOKEN_INFO_TAGS_${index}">
					-
					</td>
				</tr>
				<tr>
					<td valign="top" style="font-weight:bold;padding-top:7px;">Token</td>
					<td style="padding-top:7px;padding-left:10px;font-family:'Open-Sans',sans-serif;font-size:13px;" id="TOKEN_INFO_FULLNAME_${index}">
					-
					</td>
				</tr>
				<tr	id="TR_TOKEN_INFO_ADDRESS_${index}">
					<td valign="top" style="font-weight:bold;padding-top:7px;">Address</td>
					<td style="padding-top:7px;padding-left:10px;width:75%;font-family:'Open-Sans',sans-serif;font-size:13px;" id="TOKEN_INFO_ADDRESS_${index}">
					-
					</td>
				</tr>
				<tr id="TR_TOKEN_INFO_DESCRIPTION_${index}">
					<td valign="top" style="font-weight:bold;padding-top:7px;">Description</td>
					<td style="padding-top:7px;padding-left:10px;width:75%;font-family:'Open-Sans',sans-serif;font-size:13px;" id="TOKEN_INFO_DESCRIPTION_${index}">
					-
					</td>
				</tr>
				
				<tr>
					<td valign="top" style="font-weight:bold;padding-top:7px;">Explorer</td>
					<td style="padding-top:7px;padding-left:10px;font-size:14px;font-family:'Open-Sans',sans-serif;font-size:13px;" id="TOKEN_INFO_EXPLORER_${index}">
					-
					</td>
				</tr>
				<tr id="TR_TOKEN_INFO_LINKS_${index}">
					<td valign="top" style="font-weight:bold;padding-top:7px;">${LANG_HOME.LG31}</td>
					<td style="padding-top:7px;padding-left:10px;font-size:14px;font-family:'Open-Sans',sans-serif;font-size:13px;" id="TOKEN_INFO_LINKS_${index}">
					-
					</td>
				</tr>
				<tr id="TR_TOKEN_INFO_PRICE_${index}" style="display:none;">
					<td valign="top" style="font-weight:bold;padding-top:7px;">Price</td>
					<td style="padding-top:7px;padding-left:10px;font-size:14px;font-family:'Open-Sans',sans-serif;font-size:13px;" id="TOKEN_INFO_PRICE_${index}">
					-
					</td>
				</tr>
			</table>
			
			<br/><br/><br/><br/>
		</div>
	`);
	
	loadInfo(type,chainID,index);
	
	$(divID).animate({"height": "260px"}, 100, function() {
		
		let a	=	Number($(divID).offset().top);
		let b	=	Number($('#WRAPPER_HOME_TOKEN').scrollTop());
		let c	=	(a > 215) ? (b+(a-215)) : (b-(215-a));
		$('#WRAPPER_HOME_TOKEN').animate({scrollTop: c},300);
		
	});
	
	$('.exitHistory').unbind('click');
	$('.exitHistory').click(async function() { 
		let pdiv	=	$(this).attr('parentDiv');
		$(pdiv).css('border-top', '0px').animate({"height": "1px", "background-color": "white", "border-top": "0px"},500, function() {
			$(pdiv).html('');
		});
	});
}

function viewHistory(index) {
	console.log('[viewHistory] Start loading UI history interface');
	let divID	=	"#HOME_HISTORY_"+index;
	let tableID	=	"TABLE_HISTORY_"+index;
	$(divID).css('border-top', '1px solid #efefef').css('width', '99%').css('background-color', 'white');
	
	
	$(divID).html(`
		<div style="width:1px;height:5px;"></div>
		<div parentDiv="${divID}" class="exitHistory" style="position:relative;cursor:pointer;float:right;right:10px;margin-top:8px;color:#0d1725;font-size:14px;">
			<i class="fa fa-xmark"></i>
		</div>
		
		<div class="tdRight" style="display:none;margin-left: 10px; margin-top: 3px;position:absolute;box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-radius: 5px;color: white;background-color: #0c1c2e45;font-size:13px;width: 20px;font-family: 'Open Sans',sans -serif;"><i class="fa-light fa-filter-list"></i></div>
			
		<div style="margin-top:5px;">
			<center><span style="font-size:16px;font-weight:bold;color:0d1725;font-family:'Open Sans'">${LANG_HOME.LG26}</span></center>
		</div>
		
		<div id="${tableID}" style="overflow:auto;-ms-overflow-style: none; scrollbar-width: none;height:240px;">
		
		</div>
	`);

		
	$(divID).animate({"height": "260px"}, 100, function() {
		loadHistory(index);	
		
		let a	=	Number($(divID).offset().top);
		let b	=	Number($('#WRAPPER_HOME_TOKEN').scrollTop());
		let c	=	(a > 215) ? (b+(a-215)) : (b-(215-a));
		
		$('#WRAPPER_HOME_TOKEN').animate({scrollTop: c},300);
		
		$('.tableHistory').unbind('click');
				
		$('.tableHistory').click(async function() {
				$('#bgBackHistory').fadeIn();
				$('#bgWallHome').animate({"height": "100%"},250);
				
				loadTxHistory(index, $(this).attr('reunit_txid'));
				
				$('#popupHistory').show().animate({"height": "80%" }, 500, function() { 
						$('#detailHistoryAmount').show('puff',150);
						animateIco();
				});
		});
	});
	
	
	$('.exitHistory').unbind('click');
	$('.exitHistory').click(async function() { 
		let pdiv	=	$(this).attr('parentDiv');
		$(pdiv).css('border-top', '0px').animate({"height": "1px", "background-color": "white", "border-top": "0px"},500, function() {
			$(pdiv).html('');
		});
	});
	
		
	
}

$('.historyToHome').click(async function() {
	$('#bgWallHome').animate({"height": "0%"},250);
	$('#bgBackHistory').fadeOut(200); 
	$('#popupHistory').animate({"height": "0%" }, 500, function() { $('#popupHistory').hide(); });
	$('#detailHistoryAmount').hide();
});


function animateIco() {
	$('#txHistoryChainIcon').css('opacity', 1);
	$('#txHistoryChainIcon').animate({"margin-left": "330px", "opacity": "0"}, 3000, function() {
		$('#txHistoryChainIcon').css('margin-left', '0px');
		animateIco();
	});
}

// Detect if the user press something
$(document).ready(function() {
    $(document).on("keyup", function(event) {
   	 	if(CURRENT_PAGE == "PAGE_HOME" && $('#homeTokenSearch').is(':focus') == 0 && $('#homeviewlist').is(':visible') == false && $('#bottomPopupTokenMenu').is(':visible') == false && $('#addTokenlistTOP').is(':visible') == false && $('#popupHistory').is(':visible') == false && $('#bgPopup').is(':visible') == false) {
        	let key = event.which;
        	if((key >= 48 && key <= 57) || (key >= 65 && key <= 90) || (key >= 97 && key <= 122) || (key == 8)) {
            	
            	
            	
            	let old_val	=	$('#homeTokenSearch').val();
            	let	new_val	=	(key != 8) ? (old_val+String.fromCharCode(key)).toUpperCase() : (old_val.substr(0, old_val.length-1));
            	$('#homeTokenSearch').val(new_val);
            	
            	homeFilterSearch();
            	if((key == 8 && new_val.length == 0)|| new_val == '') {
            		
            	} else {
            		$('#PARENT_TOTAL_MAIN_TOP').hide();
            		$('#homeSelectList').css('opacity', 0);
            		$('#topHeader_search').show("slide", {direction: "down"}, 250);
            	}
            	
            	
        	} else {
            	
        	}
        }
    });
    
    $('#homeTokenSearch').on("keyup", function() {
		$('#homeTokenSearch').val(($(this).val()).toUpperCase());
		homeFilterSearch();
		
	});
});

async function homeFilterSearch() {
	let keyword	=	$('#homeTokenSearch').val().toUpperCase();
	
	
	
	if((keyword == '' || keyword.length == 0) && $('#topHeader_search').is(':visible') == true) {
		$('.trHomeTokenLIST').show();
		$('.trHomeTokenHistory').show();
		$('#homeTokenSearch:focus').blur();
		$('#topHeader_search').hide('slide', {direction: "down"}, function() {
			$('#PARENT_TOTAL_MAIN_TOP').show('puff');
			$('#homeSelectList').css('opacity', 1);
		});
		
		
	} else {
	
		$('.trHomeTokenLIST').each(function () {
			if($(this).attr('token').includes(keyword)) {
				$(this).show();
			} else {
				$(this).hide();
			}
		});
	
		$('.trHomeTokenHistory').each(function () {
			if($(this).attr('token').includes(keyword)) {
				$(this).show();
			} else {
				$(this).hide();
			}
		});
	
	}
}

// Fail loading img
$("img").on("error", function () { $(this).attr("src", "./img/no_image.png"); });

$('#unlockToSend_exit').click(function() {
	$('#POPUP_WAIT_SEND').fadeOut();
	$('#bgPopup').hide("drop");
	// Re-bind
	let tokenName	=	$('#current_tokenName').val();
	$('#BTN_REUNIT_TRANSFER').click(function() { checkReunitTransfer(tokenName); });
});


$('#homeMenuRight').click(async function() { menuRight(); });

function menuRight() {
	$('#homeMenuRight').unbind();
	$('#homeMenuRight').html('<i class="fa-solid fa-square-plus"></i>');
	$('#homeMenuRight').css('opacity', '1');
	$('#homeMenuLeft').css('opacity', '0.5');
	$('#homeTopTotalBalance').hide('slide', {direction: 'left'}, function() {
		$('#homeSelectList').show('slide', {direction: 'down'}, function() {
			$('#homeMenuLeft').click(async function() { menuLeft(); });
			$('#homeMenuRight').click(async function() { newTokenList(); });
		});
	});
	
	viewAllTokenLists();
	
	
	
}

function menuLeft() {
	$('#homeMenuLeft').unbind();
	$('#homeMenuLeft').css('opacity', '0.05');
	
	$('#homeMenuRight').css('opacity', '0.5');
	$('#homeMenuRight').html('<i class="fa-solid fa-square-chevron-right"></i>');
	
	$('#homeSelectList').hide('slide', {direction: 'left'}, function() {
		$('#homeTopTotalBalance').show('slide', {direction: 'down'});
	});
	
	$('#homeMenuRight').unbind();
	$('#homeMenuRight').click(async function() { menuRight(); });
}

function tinyNotif(text,w,t,ms) {
	$('#littleNotifText').text(text);
	let delay;
	
	if(t > 0) { $('#littleNotif').css('margin-top', t+'%'); } else { $('#littleNotif').css('margin-top', '5%'); }
	if(ms > 0) { delay = ms; } else { delay = 500; }
	
	if(w > 0) { $('#littleNotif').css('width', w+'px').css('margin-left', (360-w)/2+'px'); } else { }
	$('#littleNotif').show('puff', 500, function() { 
		setTimeout(() => {
		$(this).hide('puff'); 
		
		}, delay);
	});
}

$('#menu_DAPPS').click(async function() {
	tinyNotif('Open the 29 April', 250, 60, 500);
});

function newTokenList() {
	$('#topHeader').animate({height: '190px'}, 150, function() {
		$('#homeSelectList').hide('slide', {direction: 'left'}, 150, function() {
			$('#addTokenlistTOP').show('slide', {direction: 'up'});
			$('#addTokenlistFORM').fadeIn();
		});
	});
	
	$('#homeMenuLeft').unbind();
	$('#homeMenuLeft').fadeOut();
	$('#homeMenuRight').unbind();
	$('#homeMenuRight').click(async function() { hideNewTokenList(); });
	$('#homeMenuRight').html('<i class="fa-solid fa-square-x"></i>');
}

async function viewAllTokenLists() {
	$('#homeviewlist').html('<option value="ALL" selected disabled>'+LANG_HOME.LG19+'</option><option value="ALL">'+LANG_HOME.LG20+'</option><option value="NATIVE">Native tokens</option>');
	for(l in LISTS_TOKENLIST) {
		$('#homeviewlist').append('<option value="'+l+'">'+LISTS_TOKENLIST[l]+'</option>');
	}
}


function hideNewTokenList() {

	$('#addTokenlistFORM').fadeOut(190);
	$('#addTokenlistTOP').hide('slide', {direction: 'up'}, 200, function() {
		
		$('#topHeader').animate({height: '101px'}, 150, function() {
			$('#homeSelectList').show('slide', {direction: 'down'});
		});
	});
	
	$('#homeMenuRight').unbind();
	$('#homeMenuLeft').unbind();
	$('#homeMenuLeft').fadeIn();
	$('#homeMenuRight').html('<i class="fa-solid fa-square-plus"></i>');
	$('#homeMenuRight').css('opacity', '1');
	$('#homeMenuLeft').css('opacity', '0.5');
	
	viewAllTokenLists();
	$('#homeMenuLeft').click(async function() { menuLeft(); });
	$('#homeMenuRight').click(async function() { newTokenList(); });
}

$('#createNewTokenList').click(async function() { addListToTokenLists(); });

async function addListToTokenLists() { 
	$('#createNewTokenList').unbind();
	let listName	=	$('#createNewTokenList_input').val();
	
	if(listName.length == 0) {
		$('#createNewTokenList_input').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
		$('#createNewTokenList').click(async function() { addListToTokenLists(); });
	} else {
		manageListOfTokens("ADD", listName);
		tinyNotif(' New list created', 250);
		$('#createNewTokenList_input').val('');
		hideNewTokenList();
		$('#createNewTokenList').click(async function() { addListToTokenLists(); });
	}
}


$('#homeviewlist').change(function() { 
	let list			=	$('#homeviewlist').val();
	CURRENT_TOKENLIST	=	list;
	tinyNotif(' List changed', 250);
	showSelectedTokens(1);
});

$('.backFromEmptyList').click(async function() {
	$('#homeviewlist option[value="ALL"]').prop('selected', true);
	CURRENT_TOKENLIST	=	"ALL";
	showSelectedTokens(1);
});


$('#menu_HELP').click(async function() {
	$('#bottomPopupHelpCenter').hide('slide', {direction: "down"}, 100);
	
	$('#bottomPopupHelpCenter').show('slide', {direction: "down"}, 200);
	$('#WRAPPER_HOME_TOKEN').css('filter', 'blur(2px)');
	

	$('#closePopupHelpCenter').unbind();
	$('#closePopupHelpCenter').click(async function() {  
		$('#bottomPopupHelpCenter').hide('slide', {direction: "down"}, 200);
		$('#WRAPPER_HOME_TOKEN').css('filter', 'blur(0px)');
	});

});

$('.homeFlag').click(async function() {
	getLang($(this).attr('country'));
});

function viewMenuToken(t,k) {
	let tokenID	=	t;
	let key		=	k;
	
	$('#bottomPopupTokenMenu').hide('slide', {direction: "down"}, 100);
	
	$('#bottomPopupTokenMenu').show('slide', {direction: "down"}, 200);
	$('#WRAPPER_HOME_TOKEN').css('filter', 'blur(2px)');
	

	$('#closePopupTokenMenu').unbind();
	$('#closePopupTokenMenu').click(async function() {  
		$('#bottomPopupTokenMenu').hide('slide', {direction: "down"}, 200);
		$('#WRAPPER_HOME_TOKEN').css('filter', 'blur(0px)');
	});
	
	$('#TR_addToATokenList').unbind();
	$('#TR_addToATokenList').click(async function() {
		$('#tokenMenu').hide('slide', {direction: "down"}, 200, function() {
			$('#tokenMenuAddToAList').fadeIn();
		});
	});
	
	$('#BackFromAddTokenToAList').unbind();
	$('#BackFromAddTokenToAList').click(async function() {
		$('#tokenMenuAddToAList').hide('slide', {direction: "left"}, 200, function() {
			$('#tokenMenu').fadeIn();
		});
	});
	
	$('#tokenMenuViewList').html('<option value="NO_LIST" selected disabled>'+LANG_HOME.LG67+'</option>');
	for(l in LISTS_TOKENLIST) {
		$('#tokenMenuViewList').append('<option value="'+l+'">'+LISTS_TOKENLIST[l]+'</option>');
	}
	
	$('#addThisTokenToAList').unbind();
	$('#addThisTokenToAList').click(async function() {
		let newList		=	$('#tokenMenuViewList').val();
		let tokenExist 	=	0;
		if(newList == null || newList == undefined || newList == "NO_LIST") {
			$('#addThisTokenToAList').effect('shake');
		} else {
		$('#addThisTokenToAList').html('<i class="fa fa-spinner-third fa-spin"></i>');
		
		if(k.includes("STARGATE_") || k.includes("NATIVE_")) {
			if(MY_TOKENS_LIST[k] != undefined) {
					MY_TOKENS_LIST[k][''+newList+'']	=	true;
			} else {
					MY_TOKENS_LIST[k] 					=	{};
					MY_TOKENS_LIST[k][''+newList+'']	=	true;
			}
			tokenExist = 1;
		} else {
			if(!MY_TOKENS_LIST[k][newList]) {
				MY_TOKENS_LIST[k][newList]	=	true;
				tokenExist = 1;
			} else {
				tokenExist = 0;
			}
		}
		
		
		if(tokenExist == 1) {
			
			chrome.storage.local.set({CUSTOM_TOKEN_LIST: MY_TOKENS_LIST});
			tinyNotif(LANG_HOME.LG55, 250);
			$('#addThisTokenToAList').html('<i class="fa fa-check"></i> '+LANG_HOME.LG55);
			setTimeout( () => {
			$('#tokenMenuAddToAList').hide('slide', {direction: "left"}, 200, function() {
				$('#tokenMenu').fadeIn();
				$('#addThisTokenToAList').html(LANG_HOME.LG68);
			});
			
			}, 500);
		} else {
			$('#addThisTokenToAList').effect('shake', function() {
				$('#addThisTokenToAList').html(LANG_HOME.LG68);
			});
		}
		
		}
	});
	
	
	if(t.includes("STARGATE_") || t.includes("NATIVE_")) {
		$('#TR_removeThisToken').css('opacity', '0.3');
		$('#TR_removeThisToken').unbind(); 
	} else {
		$('#TR_removeThisToken').css('opacity', 1);
		$('#TR_removeThisToken').click(async function() { 
			manageTokenToTokensList("DELETE", key, 0, 0); 
			setTimeout( () => { showSelectedTokens(1); },500);  
		
			$('#bottomPopupTokenMenu').hide('slide', {direction: "down"}, 200);
			$('#WRAPPER_HOME_TOKEN').css('filter', 'blur(0px)');
		});
	}
	
	if(CURRENT_TOKENLIST == "ALL") {
		$('#TR_removeFromThisList').css('opacity', '0.3');
		$('#TR_removeFromThisList').unbind(); 
	} else {
		$('#TR_removeFromThisList').css('opacity', 1);
		
		$('#TR_removeFromThisList').click(async function() {
			
			if(MY_TOKENS_LIST[k][CURRENT_TOKENLIST]) {
				delete MY_TOKENS_LIST[k][CURRENT_TOKENLIST];
				chrome.storage.local.set({CUSTOM_TOKEN_LIST: MY_TOKENS_LIST});
				tinyNotif('Removed', 250);
				showSelectedTokens(1);
				$('#bottomPopupTokenMenu').hide('slide', {direction: "down"}, 200);
				$('#WRAPPER_HOME_TOKEN').css('filter', 'blur(0px)');
			} else { }
		});
	}
	
	
}


$('.deleteThisList').click(async function() {
	
	delete LISTS_TOKENLIST[CURRENT_TOKENLIST];
	await chrome.storage.local.set({LIST_OF_TOKENS: LISTS_TOKENLIST});
	
	viewAllTokenLists();
	
	CURRENT_TOKENLIST	=	"ALL";
	
	tinyNotif('List deleted', 250);
	showSelectedTokens(1);

});

function hideMenuToken(tid) {
	let tokenID	=	tid;
	$('.viewMenu_'+tokenID).addClass('fa-ellipsis-vertical').removeClass('fa-solid fa-caret-left');
	$('#menu_'+tokenID).hide('slide', 150, {direction: "left"});
	$('.td_'+tokenID).css('filter', 'blur(0px)');
	$('.viewMenu_'+tokenID).unbind();
	$('.viewMenu_'+tokenID).click(async function() {  viewMenuToken(tokenID); });
}


function UIConfirmCustomSend() {
	$('#unlockToSend_sending_logo').html('<i style="font-size:16px;" class="green fa-check fa-regular"></i>');
	$('#bgPopup').fadeOut(500, function() {
		$('#PSCT_TOP_SEND_CONFIRMATION').fadeIn({
			complete: function() {
				$('#PSCT_TOP_LOAD_CONFIRMATION').hide();
				$('#PSCT_LOGO_CIRCLE').animate({"opacity": "1"}, 150, function() {
					$('#PSCT_LOGO_NETWORK_CONFIRM').animate({"margin-left": "-28px", "opacity": "0.3"}, 250);
					$('#PSCT_LOGO_TOKEN_CONFIRM').animate({"margin-left": "51px", "opacity": "0.3"}, 250);
					$('#PSCT_BAR').animate({"height": "220px"}, 1000);
					$('#ERC20_SUM_1').animate({"opacity": 1}, 250, function() {
    					$('#ERC20_SUM_2').animate({"opacity": 1}, 250, function() {
        					$('#ERC20_SUM_3').animate({"opacity": 1}, 250, function() {
            					$('#ERC20_SUM_4').animate({"opacity": 1}, 250);
        					});
    					});
					});

				});
			}
		});
	});
}