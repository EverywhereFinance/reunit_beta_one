// Create by me, for you <3
var CHAINS;
var CHAINS_COLOR			=	{	10101: "#627eea", 1: "#627eea",
									10102:"#efb90a" , 56: "#efb90a",
									10106: "#e84141", 43114: "#e84141",
									10109: "#8e59e8", 137: "#8e59e8", 
									10110: "#96bedc", 42161: "#96bedc",
									10111: "#ff0320", 10: "#ff0320",
									10112: "#11b4ec", 250: "#11b4ec" 
								};
var STARGATE_TOKEN			=	["usdc", "usdt", "dai", "busd"];
var REUNIT_BALANCE			=	{"unified_balance": 0};
var REUNIT_PUBKEY			=	"";
var CURRENT_PAGE			=	"";

var REUNIT_TRANSFER_CHAIN	=	{};
var REUNIT_CONFIG			=	{};
var REUNIT_TX_HISTORY		=	{};
var MY_TOKENS_LIST			=	{};
var MY_CONTACTS_LIST		=	{};
var LISTS_TOKENLIST			=	{};

var CURRENT_TOKENLIST		=	"ALL";

var TOKENS_LIST;
var INTERVAL_UPDATE;

var FOREX_PRICE;

var LANG_WELCOME;
var LANG_HOME;
var LANG_SEND;
var LANG_CROSSCHAIN;

initForex();





/**
	description		Check if wallet must be locked or not
**/
function is_locked() {
	let last_lockout	=	Number(REUNIT_CONFIG.last_lockout);
	let	locktime		=	Number(REUNIT_CONFIG.locktime)*60;
	let now				=	new Date();
	let now_timestamp	=	Math.ceil(now.getTime()/1000);
	
	if(last_lockout+locktime <= now_timestamp) {
		return 1;
	} else {
		return 0;
	}
}

/**
	description		SwitchNetwork
**/
async function switchNetwork(networkType) {
	console.log('[switchNetwork]');
	switch(networkType) {
   		case "testnet":
   			CHAINS					=	[10101, 10102, 10106, 10109, 10112];
   			STARGATE_TOKEN			=	["usdc", "usdt"];
   			break;
   		case "mainnet":
   			CHAINS					=	[1,56,43114,137,42161,10,250];
   			STARGATE_TOKEN			=	["usdc", "usdt", "dai", "busd"];
   			break;
   	}
   await initBalance();
   showSelectedTokens(1);
   goHome();
   tinyNotif(LANG_HOME.LG45, 250);	
}

/**
	description		Load settings
**/
async function load_settings(val) {
	
	chrome.storage.local.get(['REUNIT_SETTINGS'], async function(storage) {
		try {
			REUNIT_CONFIG	=	storage.REUNIT_SETTINGS;
			
			
			
			console.log('%c[load_settings] Settings loaded', 'color:white;background-color:#22bcce;');
			switch(REUNIT_CONFIG.gas_speed) {
				case 10:
					$('#settings_text_speed').html(LANG_HOME.LG36+' +10%');
					break;
				case 20:
					$('#settings_text_speed').html(LANG_HOME.LG37+' +20%');
					break;
				case 30:
					$('#settings_text_speed').html(LANG_HOME.LG38+' +30%');
					break;
				case 40:
					$('#settings_text_speed').html(LANG_HOME.LG39+' +40%');
					break; 
			}
			
   			$('#settings_text_locktime').html(''+REUNIT_CONFIG.locktime+' '+LANG_HOME.LG41);
   			
   			$('#CURRENT_NETWORK_OPTION').text(REUNIT_CONFIG.network.toUpperCase());
   			
   			switch(REUNIT_CONFIG.network) {
   				case "testnet":
   					CHAINS					=	[10101, 10102, 10106, 10109, 10112];
   					STARGATE_TOKEN			=	["usdc", "usdt"];
   					break;
   				case "mainnet":
   					CHAINS					=	[1,56,43114,137,42161,10,250];
   					STARGATE_TOKEN			=	["usdc", "usdt", "dai", "busd"];
   					break;
   			}
   				
   			switch(REUNIT_CONFIG.lang) {
   				case "EN":	$('#sett0_img_lang').attr('src', './img/flag/uk.png');	$('#sett0_lang_text').html('English');	break;
   				case "RU":	$('#sett0_img_lang').attr('src', './img/flag/ru.png');	$('#sett0_lang_text').html('Russian');	break;
   				case "FR":	$('#sett0_img_lang').attr('src', './img/flag/fr.png');	$('#sett0_lang_text').html('French');	break;
   				case "KR":	$('#sett0_img_lang').attr('src', './img/flag/kr.png');	$('#sett0_lang_text').html('Korean');	break;
   				case "CN":	$('#sett0_img_lang').attr('src', './img/flag/cn.png');	$('#sett0_lang_text').html('Chinese');	break;
   				case "ES":	$('#sett0_img_lang').attr('src', './img/flag/es.png');	$('#sett0_lang_text').html('Spanish');	break;
   				case "IT":	$('#sett0_img_lang').attr('src', './img/flag/it.png');	$('#sett0_lang_text').html('Italian');	break;
   			}
   			
   			getLang(REUNIT_CONFIG.lang);
   			
   			switch(REUNIT_CONFIG.currency) {
   				case "USD":	$('.sett0_currency_text').html('US Dollars');		$('.sett0_sign_currency').html('<i class="fa-light fa-dollar-sign" style="font-size:25px;color:#3D3D3D;"></i>');	break;
   				case "EUR_USD":	$('.sett0_currency_text').html('Euro');				$('.sett0_sign_currency').html('<i class="fa-light fa-euro-sign" style="font-size:25px;color:#3D3D3D;"></i>');		break;
   				case "GBP_USD":	$('.sett0_currency_text').html('Pound sterling');	$('.sett0_sign_currency').html('<i class="fa-light fa-sterling-sign" style="font-size:25px;color:#3D3D3D;"></i>');	break;
   				case "CNY_USD":	$('.sett0_currency_text').html('Yen');				$('.sett0_sign_currency').html('<i class="fa-light fa-yen-sign" style="font-size:25px;color:#3D3D3D;"></i>');		break;
			}
   			
   			if(val == "HOME") {
   				loadHomePage();
   				showSelectedTokens(1);
   			}
   			
		} catch(e) {
			console.log(e);	
			console.log('%c[load_settings] Error', 'color:red;background-color:#22bcce;');
		}
		
		
	});
	
	
}


/**
	description		Update settings
**/
async function update_settings() {
	chrome.storage.local.set({REUNIT_SETTINGS: REUNIT_CONFIG});
}


/**
	description		Page manager 
**/
async function start(option) {
	let reunit		=	new URL(window.location.href);
	let url_action	=	reunit.searchParams.get("action");
	let action;
	let locked;
	
	console.log('[start] '+option);
	switch(option) {
		case "INIT":		action	=	"WELCOME";		locked	=	0;	break;
		case "OK":			action	=	url_action;		locked	=	0;	INTERVAL_UPDATE = setInterval(function() { update_settings(); },500); break;
		case "NO_PUBKEY":	action	=	"NO_PUBKEY";	locked	=	1;	break;
	}
	
	
	if(action != "WELCOME" && locked == 0) {
		getTokensList();
		loadTokensList();
	} else { }
	
	switch(action) {			
		case "WELCOME":
			CURRENT_PAGE	=	"PAGE_WELCOME";
			$('#topHeader').hide();
			$('#PAGE_HOME').hide();
			$('#startBG').fadeOut();
			$('#PAGE_WELCOME').show();
			
			$('#PAGE_WELCOME_TOP').show();
			$('#PAGE_WELCOME_TOP_LOGO').show('puff');
			$('#PAGE_WELCOME_CHOICE').fadeIn(1500);
			break;

		case "NO_PUBKEY":
			CURRENT_PAGE	=	"PAGE_LOCKED";
			console.log('[start] Wallet must be locked - UI locked ');
			$('#startBG').fadeOut();
			$('#bgPopup').css('background', 'linear-gradient(black 5%, rgb(17, 15, 34) 40%, black 90%)');
			$('#bgPopup').show("puff", {
				complete: function() { 
					$('#POPUP_MANAGE_CONTACT').hide();
					$('#POPUP_SETTINGS').hide();
					$('#POPUP_ADD_TOKEN').hide();
					$('#POPUP_LOCKED').show();
					$('#unlock_input').focus();
				} 
			}, 1);
			break;
			
		default:
			CURRENT_PAGE	=	"PAGE_HOME";
			load_settings('HOME');
			
			break;
	}
	

}


/**
	description		load HomePage
**/
function loadHomePage() {
	$('#PAGE_WELCOME').hide();
	$('#PAGE_WELCOME_TOP').hide();
	$('#topHeader').show();
	$('#PAGE_HOME').show();
	$('#startBG').fadeOut();
	//showCurrentWallet();
	$('#TOP_CURRENT_WALLET').html('<span class="reunitGradient">'+REUNIT_PUBKEY.substring(0,6)+'</span>'+REUNIT_PUBKEY.substring(6,9)+'....'+REUNIT_PUBKEY.substring(REUNIT_PUBKEY.length-8,REUNIT_PUBKEY.length-5)+'<span class="reunitGradient">'+REUNIT_PUBKEY.substring(REUNIT_PUBKEY.length-4,REUNIT_PUBKEY.length)+'</span>');
	initBalance();
			
	$('#PAGE_HOME_TOKENS_VIEW').html('');
			
	
	
	// Tokens added
	
	// UI
	$('.buttonHistory').unbind('click');
	$('.buttonHistory').click(async function() {
		let index	=	$(this).attr('index_info');
		viewHistory(index);
	});
	
	$('.buttonInfo').unbind('click');
	$('.buttonInfo').click(async function() {
		let tokenID		=	$(this).attr('tokenID');
		let type		=	$(this).attr('type');
		let index		=	$(this).attr('index_info');
		let tokchain	=	$(this).attr('chainID');
		viewInfo(index,type,tokenID,tokchain);
	});
	
}

/**
	description		Init token's balance to REUNIT_BALANCE
**/
function initBalance() {
	REUNIT_BALANCE			=	{"unified_balance": new Big(0)};
	
	CHAINS.forEach( function(chainID) { 
		STARGATE_TOKEN.forEach( function(tokenName) {
			if(!REUNIT_BALANCE.hasOwnProperty(tokenName)) {
				REUNIT_BALANCE[tokenName] = {"total": new Big(0)};
			} else { }
				REUNIT_BALANCE[tokenName][chainID] = new Big(0);
		});								   
	});
	
	// Supported stargate tokens
	STARGATE_TOKEN.forEach( function(tokenName) {
		loadBalanceByToken(tokenName);
	});
	
	
}


/**
	description		Load balance by native
**/
async function loadNativeBalance(t) {

	CHAINS.forEach( async function(chainID) { 
			
			
		let data	=	chainsData(Number(chainID));
		let web3	=	new Web3(data.node+"&mode=normal");
		
		await web3.eth.getBalance(REUNIT_PUBKEY).then(function(result) {
			
			REUNIT_BALANCE[chainID+"_"+data.nativeToken]	=	new Big(result).div(new Big(10).pow(18));
			if(t == "VIEW_HOME") {
				$('#HOME_VIEW_BALANCE_'+chainID+'_'+data.nativeToken).html(REUNIT_BALANCE[chainID+"_"+data.nativeToken].toFixed(6));
				
			} else { }
			
		});
		
	});
	
	
}


/**
	description		Load all balance by tokenName
**/
async function loadBalanceByToken(tokenName,pg) {
	if(REUNIT_BALANCE.hasOwnProperty(tokenName)) {
	
		
		// (re)init total at 0
		REUNIT_BALANCE[tokenName]["total"]	=	new Big(0);
		// Call balanceOf by chain
		
		let chain_available	=	0;
		
		// No balance ?
		$('#PAGE_SEND_TOKEN_MAIN_TABLE').append('<tr id="PST_TABLE_NO_BALANCE"><td colspan="6" style="width:390px;"><div id="PST_DIV_NO_BALANCE" style=" font-family: \'Roboto\',sans -serif; width: 100%; background-color: #0d1a2b00; text-align: center; padding-top: 50px; padding-bottom: 50px; ">You don\'t hold <b>'+tokenName.toUpperCase()+'</b> on the following blockchains:<br/><br/></div></td></tr>');
		
		
		CHAINS.forEach( async function(chainID) {
			let l_chainData	=	chainsData(chainID);
			
			// Check if tokenName exist for chainID
			if(l_chainData.hasOwnProperty(tokenName)) {
				// UI
				if(pg == "PAGE_SEND_TOKEN") {
					$('#PST_TOP_CENTER').prepend('<i id="PST_TOP_LOADING_'+tokenName+'_'+chainID+'" class="PST_LOAD_CIRCLE fa-thin fa-spinner-third fa-spin" style="position: absolute; font-size: 75px; margin-top: -8px; margin-left: -13px; opacity:1; color: #00aeff; "></i>');
					
				} else { }
				
				let l_web3		=	new Web3(l_chainData.node+'&mode=normal');
				let l_contract	=	new l_web3.eth.Contract(ERC20_ABI, l_chainData[tokenName]["address"]);
				
				await l_contract.methods.balanceOf(REUNIT_PUBKEY).call().then(function(result) {
					
					console.log('[loadBalanceByToken] '+tokenName+'@'+chainID+' : '+result+'');
					try {
						REUNIT_BALANCE[tokenName][chainID]	=	new Big(result).div(l_chainData[tokenName]["decimals"]);
						updateTotalBalanceByToken();
						
					} catch(e) {
						REUNIT_BALANCE[tokenName][chainID]	= 	new Big(0);
					}
					
					// Calcul new unified balance
					calculUnifiedBalance();
					updateTotalBalanceByToken();
					
					
					if(pg == "PAGE_SEND_TOKEN") {
						
						$('#PST_TOP_LOADING_'+tokenName+'_'+chainID+'').remove();
						
						$('#PAGE_SEND_TOKEN_TOP_BALANCE').html(Intl.NumberFormat('en-US', {}).format(REUNIT_BALANCE[tokenName]["total"].toFixed(3)));
						
						var newLine = `
						<tr>
							<td style="width:5px;color:black;">
								<div id="TABLE_SEND_DIV_NOTENOUGH_${chainID}" style="display:none;z-index: 99;position: absolute;">
									<div class="UIbuttonReunit buttonReunit" id="BTN_TRANSFER_APPROVE_`+tokenName+`_`+chainID+`" style="height:18px;z-index:2;text-align:center;border-radius: 10px; padding: 5px; margin-left: 315px; margin-top: -8px;position:absolute;color: white;font-size: 13px;width: 66px;font-family: 'Open Sans', sans-serif;">
										`+LANG_CROSSCHAIN.LG93+`
									</div>
									<span class="tx_warning_message" style="margin-left: 60px;margin-top: -1px;font-weight:bold;width: 300px;position: absolute;">Allow cross-chain transfers on `+l_chainData.nativeToken+`</span>
									
								</div>
								<i class="fa-solid fa-ellipsis-vertical pointer"></i>
							</td>

							<td style="text-align:center;width:40px;"> 
								<img id="SEND_LOGO_NATIVE_${chainID}" class="logoSendPage_${chainID}" src="./img/${chainID}.svg" style="z-index:100;cursor:pointer;position:relative;width:30px;height:30px;"> 
								<div id="SEND_VIEW_NATIVE_${chainID}" class="viewNativeSend" style="background-color:${CHAINS_COLOR[chainID]};">
									<div style="margin-top: 6px;">0</div>
								</div>
							</td>
			
							<td class="TABLE_SEND_TD_${chainID}" style="text-align:center;padding-left:10px;width:35px">
								<b id="${chainID}_${tokenName.toLowerCase()}_MAX">${Intl.NumberFormat('en-US', {}).format(REUNIT_BALANCE[tokenName][chainID])}</b>
							</td>
			
							<td class="TABLE_SEND_TD_${chainID}" style="padding-left:20px;width:220px;">
								<div id="${chainID}_${tokenName.toLowerCase()}_SLIDER" style="margin-top:5px;"></div>
							</td>
			
							<td class="TABLE_SEND_TD_${chainID}" style="width:100px;text-align:center;">
								<b style="display:none;" id="${chainID}_${tokenName.toLowerCase()}_TO_SEND">0</b>
								<input type="number" class="placeblack" placeholder="0" style="cursor:pointer;font-size:14px;background-color:white;text-rendering: geometricPrecision;font-family:'Roboto',sans-serif;text-align:center;font-weight:bold;border:0px;outline:none;width:50px;" id="${chainID}_${tokenName.toLowerCase()}_AMOUNT" />
							</td>
						</tr>
						`;
						
						
						
						// Add  line only if amount > 0
						if(Big(REUNIT_BALANCE[tokenName][chainID]).gt(0)) {
							
							console.log('[loadBalanceByToken] - '+tokenName+'@'+chainID+' '+pg+' : UI Line added');
							REUNIT_TRANSFER_CHAIN[chainID]	=	new Big(0);
							chain_available++;
							$('#PAGE_SEND_TOKEN_MAIN_TABLE').append(newLine);
					
							// UI
							$('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID).unbind( "click" );
							$('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID).click(function() { popupSign(''+tokenName+'','STARGATE_APPROVE',chainID); });
				
				
							$('#PAGE_SEND_TOKEN_MAIN_TABLE').append('<tr><td colspan="6"> <div style="margin-top:5px;margin-bottom:5px;width:100%;height:1px;"></div> </td></tr>');
				
							$('#SEND_LOGO_NATIVE_'+chainID+'').click( function() {  viewNativeBalance(chainID,1); });
				
							$("#"+chainID+"_"+tokenName+"_SLIDER").slider({
								orientation: "horizontal",range:"min",value:0,min: 0,max: REUNIT_BALANCE[tokenName][chainID].toString(),step: 0.1,
								classes: {
									"ui-slider-range": "crosschain-slider-range"
								},
								slide: function( event, ui ) {
								let uiValue	=	new Big(ui.value);
								
       	 						$("#"+chainID+"_"+tokenName+"_TO_SEND").html(uiValue.toString());
       	 						$("#"+chainID+"_"+tokenName+"_AMOUNT").val(uiValue.toString());
       	 						
       	 						REUNIT_TRANSFER_CHAIN[chainID]	=	uiValue;
       	 						calculTotal(tokenName);
      						}
      						});
      				
      				
      						$('#'+chainID+'_'+tokenName.toLowerCase()+'_AMOUNT').keyup( function() {
      							
      							try {
      							let newVal = 0;
      							if($(this).val() == '' || $(this).val() == undefined || $(this).val() == null) {
      								newVal	=	new Big(0);
      							} else {
      								newVal = new Big($(this).val());
      							}
      							
      							$( '#'+chainID+'_'+tokenName.toLowerCase()+'_SLIDER' ).slider( "value", newVal); 
      							$("#"+chainID+"_"+tokenName+"_TO_SEND").html(newVal);
      							
      							REUNIT_TRANSFER_CHAIN[chainID]	=	newVal;
      							calculTotal(tokenName);
      							
    							} catch(e) { }
      						});
      				
      						
      						
					
      	
						} else { }
						
						
						if(chain_available == 0) { 
							$('#PST_DIV_NO_BALANCE').append('<img src="./img/'+chainID+'.svg" class="dot" style="opacity:0.5;width:20px;border-radius:100px;" />&nbsp;&nbsp;');
						} else { $('#PST_TABLE_NO_BALANCE').hide(); }
						
					} else { }
				}).catch( function(error) {
					 // Notify error 
				});
				
				
			} else { 
				// debug
				// console.log('loadBalanceByToken > '+tokenName+' does not exist in chainData('+chainID+')'); 
			}
			
			
		});
		
		
		
		
	} else {
		// Debug
		
	}
	
}


/**
	description		Update REUNIT_BALANCE[token][total]
**/
function updateTotalBalanceByToken() {
	
	STARGATE_TOKEN.forEach( function(tokenName) {
		let u_total	=	new Big(0);
		CHAINS.forEach( function(chainID) {
			u_total	=	u_total.add(REUNIT_BALANCE[tokenName][chainID]);
		});
		REUNIT_BALANCE[tokenName]['total']	=	u_total;
	});
	
}


/**
	description		Calcul the unified balance
**/
var ETH_PRICE;
var FTM_PRICE;
var MATIC_PRICE;
var AVAX_PRICE;
var BNB_PRICE;

async function load_nativePrice() {
	ETH_PRICE	=	await getBinancePrice('ETHUSDT');
	FTM_PRICE	=	await getBinancePrice('FTMUSDT');
	MATIC_PRICE	=	await getBinancePrice('MATICUSDT');
	AVAX_PRICE	=	await getBinancePrice('AVAXUSDT');
	BNB_PRICE	=	await getBinancePrice('BNBUSDT');
}

load_nativePrice();


function getNativePrice(c) {
	let nativePrice;
	switch(c) {
			case 1:
			case 5:
			case 10:
			case 101:
			case 10101:
			case 42161:		nativePrice	=	ETH_PRICE;		break;
			
			case 10102:
			case 56:		nativePrice	=	BNB_PRICE;		break;
			
			case 10109:
			case 137:		nativePrice	=	MATIC_PRICE;	break;
			
			case 10112:
			case 250:		nativePrice	=	FTM_PRICE;		break;
			
			case 10106:
			case 43114:		nativePrice	=	AVAX_PRICE;		break;
		}
	return nativePrice;
}


var STG_PRICE	=	0;
function calculUnifiedBalance() {
	// (re) init to avoid error
	REUNIT_BALANCE["unified_balance"] = new Big(0);
	
	// STARGATE_TOKEN
	STARGATE_TOKEN.forEach( async function(tokenName) {
			if(tokenName.toUpperCase() == "STG") {
				if(STG_PRICE	==	0) {
					
					try {
						STG_PRICE		=	await getBinancePrice('STGUSDT');
						let stg_value	=	new Big(STG_PRICE).mul(REUNIT_BALANCE[tokenName]["total"]);
						REUNIT_BALANCE["unified_balance"] = REUNIT_BALANCE["unified_balance"].add(stg_value);
					
					} catch(e) {  }
				} else { 
					let stg_value	=	new Big(STG_PRICE).mul(REUNIT_BALANCE[tokenName]["total"]);
					REUNIT_BALANCE["unified_balance"] = REUNIT_BALANCE["unified_balance"].add(stg_value);
				} 
				
				
				
			} else {
				REUNIT_BALANCE["unified_balance"] = REUNIT_BALANCE["unified_balance"].add(REUNIT_BALANCE[tokenName]["total"]);
			}
			
			switch(CURRENT_PAGE) {
				case "PAGE_HOME":
					$('#HOME_VIEW_BALANCE_'+tokenName.toUpperCase()+'').html(Intl.NumberFormat('en-US', {}).format(REUNIT_BALANCE[tokenName]["total"].toFixed(3)));
					break;
			}
	});
	
	
	// ERC20
	for(tokenid in MY_TOKENS_LIST) {
		if(MY_TOKENS_LIST[tokenid]['is_stargate'] != 1 && MY_TOKENS_LIST[tokenid]['usd_price'] != undefined && MY_TOKENS_LIST[tokenid]['usd_price'] != null) {
			try {
			let tokenData						=	MY_TOKENS_LIST[tokenid];
			let usd_value						=	new Big(tokenData['balance']).div(new Big(10).pow(tokenData['decimals'])).mul(tokenData['usd_price']);
			REUNIT_BALANCE["unified_balance"] 	=	REUNIT_BALANCE["unified_balance"].add(usd_value);
			} catch(e) { }
		}
	}
	
	// CHAINS NATIVE
	CHAINS.forEach( function(c) {
		let nativeData	=	chainsData(c);
		let nativePrice	=	getNativePrice(c);
		
		try {
			let native_usd_value				=	new Big(REUNIT_BALANCE[c+'_'+nativeData.nativeToken]).mul(nativePrice);
			REUNIT_BALANCE["unified_balance"] 	=	REUNIT_BALANCE["unified_balance"].add(native_usd_value);
		} catch(e) { }
	});


	// TOP HEADER 
	if(REUNIT_BALANCE["unified_balance"] == 0) {
		$('#TOTAL_MAIN_TOP').html('00.00');	
	} else {
		$('#TOTAL_MAIN_TOP').html(Intl.NumberFormat('en-US', {}).format(REUNIT_BALANCE["unified_balance"].mul(FOREX_PRICE[REUNIT_CONFIG.currency]).toFixed(2)));	
		let s;

		switch(REUNIT_CONFIG.currency) {
			case "USD":		s	=	36;			break;
			case "EUR_USD":	s	=	8364;		break;
			case "GBP_USD": s	=	163;		break;
			case "CNY_USD": s	=	165;		break;
		}
		
		$('#TOTAL_MAIN_TOP_SIGN').text(String.fromCharCode(s));
		$('#TOTAL_MAIN_TOP_SYMBOL').text(REUNIT_CONFIG.currency.split('_')[0]);
	}
	
				   
}


/**
	description		Calcul total to send
**/
function calculTotal(tokenName) {
	let total		=	new Big(0);
	let totalFees	=	new Big(0);
	let chainDest	=	new Big($('#PAGE_SEND_DESTINATION_CHAINID').val());
	
	CHAINS.forEach( function(chainID) {
		if(REUNIT_TRANSFER_CHAIN.hasOwnProperty(chainID) && Big(REUNIT_TRANSFER_CHAIN[chainID]).gt(0)) {
			// Verification max
			if(Big(REUNIT_BALANCE[tokenName][chainID]).lt(REUNIT_TRANSFER_CHAIN[chainID])) {
				REUNIT_TRANSFER_CHAIN[chainID]	=	new Big(0);
				$( '#'+chainID+'_'+tokenName.toLowerCase()+'_SLIDER' ).slider("value", 0);
				$( '#'+chainID+'_'+tokenName.toLowerCase()+'_AMOUNT' ).val('');
				$( '#'+chainID+'_'+tokenName.toLowerCase()+'_AMOUNT' ).blur();
			} else {
				
				amount	=	new Big(REUNIT_TRANSFER_CHAIN[chainID]); 
				total	=	total.plus(amount);
				
				if(chainDest.eq(Big(chainID))) {
					totalFees	=	totalFees.plus(amount);
				} else {
					totalFees	=	totalFees.plus(amount.mul(0.9994));
				}
				
				
			}
		} else { }
	});
	
	
	
	$('#PAGE_SEND_TOTAL_AMOUNT_TO_SEND').html(''+total.toString()+'');
	$('#PAGE_SEND_INPUT_TOTAL_AMOUNT_TO_SEND').val(''+total.toString()+'');
	
	// Amount received minus fees
	$('#PAGE_SEND_TOKEN_TOP_TO_RECEIVE').html(''+totalFees.toString()+'');
}


 
 
 
 
   
/**
	description		Send tokens through stargate or normal if same chain					
**/
async function reunitTransfer(tokenName,nativeTest,p) {
	console.log('%c[reunitTransfer] '+tokenName, 'background:#22bcce;color:white;');

	let part			=	0;
	let startPart		=	1;
	let numberError		=	0;
	let recipient		=	$('#recipientTarget').val();
	let totalAmount		=	new Big($('#PAGE_SEND_INPUT_TOTAL_AMOUNT_TO_SEND').val());
	let dstChainID		=	Number($('#PAGE_SEND_DESTINATION_CHAINID').val());
	let currentOps		=	nativeTest == 1 ? "Verif" : "Sending";
	
	let reunitTxID		=	Date.now() // generateUUID();
	// How many blockchains will be used
	CHAINS.forEach( function(chainID) { if(REUNIT_TRANSFER_CHAIN.hasOwnProperty(chainID) && Big(REUNIT_TRANSFER_CHAIN[chainID]).gt(0)) { part++; } else { } });
	

	$('#PAGE_CONFIRMED_SUMMARY').html('');
	let progress;
	// $('#unlockToSend_check_gas_logo').html('<i style="font-size:16px;" class="green fa-check fa-regular"></i>');
	
	if(nativeTest == 1) {
		$('#unlockToSend_check_gas_logo').html('<i class="fa fa-spinner-third fa-spin"></i>');
	}
	// For each blockchain
	for (var i = 0; i < CHAINS.length; i++) {
		
		let chainID			=	CHAINS[i];
		
		if(REUNIT_TRANSFER_CHAIN[chainID] != undefined && REUNIT_TRANSFER_CHAIN[chainID] != null) {
		
		let superChainID 	= 	chainID;
		let amount			=	REUNIT_TRANSFER_CHAIN[chainID];
		
		// If the current blockchain is used (amount > 0) + amount <= balance
	
		if(amount.gt(0) && Big(REUNIT_BALANCE[tokenName][chainID]).gte(amount) && REUNIT_TRANSFER_CHAIN.hasOwnProperty(chainID) && Number(REUNIT_TRANSFER_CHAIN[chainID]) > 0) {
			
			let chainData		=	chainsData(chainID);							
			let web3			=	new Web3(chainData.node);
			let stgChainId		=	chainData.stargateChainID;
			let tokenAddress	=	chainData[tokenName]["address"];
			let tokenDecimals	=	chainData[tokenName]["decimals"];
			let tokenDecNumb	=	chainData[tokenName]["decimalNumber"];
			let minAmount		=	amount.sub(amount.div(100));							
			let realChainID		=	chainData.realChainID;							

			web3.eth.defaultAccount		=	REUNIT_PUBKEY;
			let srcPoolID				=	chainData[tokenName]["poolID"];
			let dstChainID				=	Number($('#PAGE_SEND_DESTINATION_CHAINID').val());
			let dstData					=	chainsData(dstChainID);
			let dstPoolID				=	Number(dstData[tokenName]["poolID"]);
			let quoteFee				=	new web3.eth.Contract(STG_QUOTE_ABI, chainData["stargateRelayer"]);
				
			// 1. Get gas Price -> 2. Estimate native fee -> 3. TxCount -> 4. Send
			// If the token is sent to another blockchain
			if(chainID != dstChainID) {
				await web3.eth.getGasPrice().then( async function(gasresult) {
					console.log('[reunitTransfer] from:'+chainID+':'+chainData["stargateRelayer"]+' -> chainDestination:'+dstChainID+' : to:'+recipient);
					await quoteFee.methods.quoteLayerZeroFee(dstChainID,1,recipient,"0x",{dstGasForCall: 0, dstNativeAmount: 0, dstNativeAddr: recipient}).call().catch(async function(e) {
						console.log('%c [reunitTransfer] Error inside the LayerZero contract', 'background:red;color:white;');
						$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
						numberError++;
					
					}).then(async function(result) {
						
						try {
						let resultFee		=	new Big(result[0]);
						let nativFees		=	resultFee.add(resultFee.div(100).mul(10)).toFixed(0);
						let gasResult		=	new Big(gasresult);
						let tx_realGasPrice	=	gasResult.add(gasResult.div(100).mul(REUNIT_CONFIG.gas_speed)).toFixed(0);

						console.log('%c [reunitTransfer @'+currentOps+'] '+tokenName+' from '+chainID+' to '+dstChainID+'', 'background:#22bcce;color:white;');
						console.log('[reunitTransfer @'+currentOps+'] Gas price : '+ gasresult+ ' | Estimated stargate Fees : '+ result[0]);
						console.log('[reunitTransfer @'+currentOps+'] '+dstChainID+" - "+srcPoolID+" - "+dstPoolID+" - "+REUNIT_PUBKEY+" - "+amount+" - "+minAmount+" - "+recipient);
						
						let encodeData		=	web3.eth.abi.encodeFunctionCall(STG_SWAP_ABI,
												[dstChainID,srcPoolID,dstPoolID,REUNIT_PUBKEY,
												''+amount.mul(new Big(10).pow(tokenDecNumb)).toFixed(0).toString()+'',
												''+minAmount.mul(new Big(10).pow(tokenDecNumb)).toFixed(0).toString()+'',
												{ dstGasForCall: 0, dstNativeAmount: 0, dstNativeAddr: "0x" },recipient,"0x"]);
						
						console.log('[reunitTransfer @'+currentOps+'] chainID: '+chainID+' | realchainID: '+realChainID);
							
    				 	
    				 	// nativeTest 1: test, 2: send
 						if(nativeTest == 1) {
 						
 							// Check Native Balance 
 							await web3.eth.getBalance(REUNIT_PUBKEY).then(async function(result) {
 								
 								
 								let currentBalance	= 	new Big(result);
 								let error_message	=	'';
 								console.log("Fees native : "+nativFees);
 								await web3.eth.estimateGas({ to: chainData.stargateRelayer, data: encodeData, value: nativFees }).then(async function(gaslimitresult) {
 									
 									let resultGasLimit	=	new Big(gaslimitresult);	
 									let realGasLimit	=	resultGasLimit.add(resultGasLimit.div(100).mul(10));	
									let bigNative		=	new Big(nativFees);
									let totalFees		=	bigNative.add(realGasLimit.mul(tx_realGasPrice));
											
									// Native balance lower than required to pay fees
									if(currentBalance.lt(totalFees)) {
										console.log('%c [reunitTransfer] The transaction cannot be sent', 'background:red;color:white;');
										$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
										error_message	=	"You don't have enough "+chainData['nativeToken']+" to pay the fees";
 										showReunitTransferError(chainID,tokenName,chainData['nativeToken'],0,error_message);
 										numberError++;
 									}
 										
 								}).catch(function(gaslimiterror){
 									
 									console.log('%c [reunitTransfer] The transaction cannot be sent', 'background:red;color:white;');
 									$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
 									
 									if(gaslimiterror.message.includes('TRANSFER_FROM_FAILED')) {
 										error_message	=	'Allow cross-chain transfers on '+chainData['nativeToken'].toUpperCase();
 										showReunitTransferError(chainID,tokenName,chainData['nativeToken'],1,error_message);
 									} else if(gaslimiterror.message.includes('insufficient funds for gas')) {
 										error_message	=	"You don't have enough "+chainData['nativeToken']+" to pay the fees";
 										showReunitTransferError(chainID,tokenName,chainData['nativeToken'],0,error_message);
 									} else if(gaslimiterror.message.includes('insufficient')) {
 										error_message	=	"You don't have enough "+chainData['nativeToken']+" to pay the fees";
 										showReunitTransferError(chainID,tokenName,chainData['nativeToken'],0,error_message);
 									}	else {
 										error_message	=	"An error has occured";
 										showReunitTransferError(chainID,tokenName,chainData['nativeToken'],0,error_message);
 									}
 												
 									numberError++;
 								});
 									
 							});
 						}
 						
 						else {
 						
 							await web3.eth.getTransactionCount(REUNIT_PUBKEY).then( async function(txCount) {
 								let tx_gasLimit		= 	new Big(await web3.eth.estimateGas({ to: chainData.stargateRelayer, data: encodeData, value: nativFees }));				
 								let tx_realGasLimit	=	tx_gasLimit.add(tx_gasLimit.div(100).mul(10)).toFixed(0);
 								
 								let txObject 	= { nonce:    web3.utils.toHex(txCount),
    				 								to:       chainData.stargateRelayer,
    				 								gasLimit: web3.utils.toHex(tx_realGasLimit),
    				 								gasPrice: web3.utils.toHex(tx_realGasPrice),
    				 								data: encodeData,
    				 								value: nativFees,
    				 								chainId:realChainID,
    				 								networkId:realChainID };
    				 			
    				 			
    				 				  			
 								let dKey		=	await decodeKey(atob(p));
								let signedTX	=	await web3.eth.accounts.signTransaction(txObject, dKey.privKey);
 								let signed_hash	=	signedTX.transactionHash;
 								
 								
 								// Add to history
    				 			let txInfo	=	{	"status": "pending", 
													"amount": amount.toString(), 
													"stargateFees": nativFees.toString(),
													"gasPrice": tx_realGasPrice.toString(),
													"gasLimit": tx_realGasLimit.toString(),
													"nonce": txCount,
													"timestamp": Date.now(),
													"type": "crosschain",
													"tokenAddress": tokenAddress,
													"tokenDecimals": tokenDecimals,
													"tokenDecNumber": tokenDecNumb,
													"hash": signed_hash,
													"txObject": txObject };
								
											
    				 			addTxToHistory("STARGATE_"+tokenName.toLowerCase()+"",reunitTxID,REUNIT_PUBKEY,recipient,Date.now(),totalAmount.toString(),0,tokenName,dstChainID,chainID,"crosschain",txInfo);
    				 			
    				 			
    				 			// UI : add line to confirmation Page
 								let newLine		=	`<tr> <td style="padding:5px;text-align:center;"> <img src="./img/${chainID}.svg" style="width:20px;height:20px;" /> </td> <td style="padding:5px;"> ${chainData.name} </td> <td style="padding:5px;color:#25bccf;"> <div style="overflow-wrap: break-word;width: 127px;"> ${amount} ${tokenName.toUpperCase()} </div></td> <td style="padding:5px;"> <i class="fa fa-chevron-right"></i> </td> <td> <u id="TX_CONFIRMED_LINK_${chainID}"><i class="fa-spin fa-light fa-circle-notch"></i></u> </td> </tr>`;
								$('#PAGE_CONFIRMED_SUMMARY').append(newLine);
								
								let predictedHash = signed_hash.substring(0,5)+'[....]'+signed_hash.substring(signed_hash.length-5,signed_hash.length);
 								$('#TX_CONFIRMED_LINK_'+chainID).html(predictedHash);
 									
								// Send the tx
								web3.eth.sendSignedTransaction(signedTX.rawTransaction).on('transactionHash', async function(txHash){ });
 								
 								progress = ((startPart/part)*100).toFixed();
 								$('#unlockToSend_sending_text').text('Sending : '+progress+'%...');
 								console.log('[reunitTransfer @'+currentOps+']  '+Date.now()+' | '+tokenName+' | '+chainID+' | Total : '+startPart+'/'+part+'');
 							
 							});
 						}
 						
 						 } catch(e) {
 							console.log('%c [reunitTransfer] LayerZero error ', 'background:red;color:white;');
 							$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
 							numberError++;
 						}
 					});
 				});
			}
				
			
			
			
			// If the token is sent to the same blockchain
			else {
				await web3.eth.getGasPrice().then( async function(gasresult) {
					
					let txRealAmount		=	amount.mul(new Big(10).pow(tokenDecNumb)).toFixed(0).toString();
					console.log('%c[reunitTransfer] : '+txRealAmount, 'background:orange');
					let encodeData			=	web3.eth.abi.encodeFunctionCall(ERC20_TRANSFER_ABI,[recipient,""+txRealAmount+""]);
    				
					await web3.eth.estimateGas({ from:REUNIT_PUBKEY, to: chainData[tokenName].address, data: encodeData }).then(async function(gaslimitresult) {
										
						let tx_gasLimit		=	new Big(gaslimitresult);					
						let tx_realGasLimit	=	tx_gasLimit.add(tx_gasLimit.div(100).mul(10)).toFixed(0);	
						let tx_gasPrice		=	new Big(gasresult);
						let tx_realGasPrice	=	tx_gasPrice.add(tx_gasPrice.div(100).mul(REUNIT_CONFIG.gas_speed)).toFixed(0);
						let error_message	=	"You don't have enough "+chainData['nativeToken']+" to pay the fees";
						
						
						console.log('%c [reunitTransfer @'+currentOps+'] '+tokenName+' from '+chainID+' to '+dstChainID+'', 'background:#22bcce;color:white;');
						console.log('[reunitTransfer @'+currentOps+'] Gas price : '+ gasresult+ ' | Gas Limit : '+ tx_realGasLimit);
						console.log('[reunitTransfer @'+currentOps+'] '+dstChainID+" - "+srcPoolID+" - "+dstPoolID+" - "+REUNIT_PUBKEY+" - "+amount+" - "+minAmount+" - "+recipient);
						
					
							if(nativeTest == 1) {
 								await web3.eth.getBalance(REUNIT_PUBKEY).then(function(result) {
 									let currentBalance = new Big(result);
 									
 									if(currentBalance.lt(Big(tx_realGasLimit).mul(Big(tx_realGasPrice)))) {
 										console.log('[reunitTransfer] not enough balance : '+currentBalance+' < '+(tx_realGasLimit.mul(tx_realGasPrice)));
 										$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
 										showReunitTransferError(chainID,tokenName,chainData['nativeToken'],0,error_message);
 										numberError++;
 									} else { } 
 									
 								}).catch(function(error){
 									console.log(error);
 									$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
 									showReunitTransferError(chainID,tokenName,chainData['nativeToken'],0,error_message);
 									numberError++;
 								});
 									
 							}
 							
 							else {
 								await web3.eth.getTransactionCount(REUNIT_PUBKEY).then(async function(txCount) {
 									let txObject 	= 	{ 
 															nonce:    web3.utils.toHex(txCount),
    				 										to:       chainData[tokenName].address,
    				 										gasLimit: web3.utils.toHex(tx_realGasLimit),
    				 										gasPrice: web3.utils.toHex(tx_realGasPrice),
    				 										data: encodeData,
    				 										value: 0,
    				 										chainId:realChainID,
    				 										networkId:realChainID 
    				 									};
    				 				
    				 				let dKey		=	await decodeKey(atob(p));
									let signedTX	=	await web3.eth.accounts.signTransaction(txObject, dKey.privKey);
 									let signed_hash	=	signedTX.transactionHash;
 								
 									// Add to history
    				 				let txInfo	=	{	
    				 								"status": "pending", 
													"amount": amount.toString(), 
													"stargateFees": 0,
													"gasPrice": tx_realGasPrice,
													"gasLimit": tx_realGasLimit,
													"nonce": txCount,
													"timestamp": Date.now(),
													"type": "crosschain_samechain",
													"tokenAddress": tokenAddress,
													"tokenDecimals": tokenDecimals,
													"tokenDecNumber": tokenDecNumb,
													"hash": signed_hash,
													"txObject": txObject };
													
    				 				addTxToHistory("STARGATE_"+tokenName+"",reunitTxID,REUNIT_PUBKEY,recipient,Date.now(),totalAmount.toString(),0,tokenName,dstChainID,chainID,"crosschain",txInfo);
    				 			
    				 				progress = ((startPart/part)*100).toFixed();
 									$('#unlockToSend_sending_text').text('Sending : '+progress+'%...');
 								
 									let newLine		=	`<tr class='trConfirmTxStargate' style='opacity:0.1;'> <td style="padding:5px;text-align:center;"> <img src="./img/${chainID}.svg" style="width:20px;height:20px;" /> </td> <td style="padding:5px;"> ${chainData.name} </td> <td style="padding:5px;color:#25bccf;"> <div style="overflow-wrap: break-word;width: 127px;"> ${amount} ${tokenName.toUpperCase()} </div></td> <td style="padding:5px;"> <i class="fa-regular fa-chevron-right"></i> </td> <td> <u id="TX_CONFIRMED_LINK_${chainID}"><i class="fa-spin fa-light fa-circle-notch"></i></u> </td> </tr>`;
									$('#PAGE_CONFIRMED_SUMMARY').append(newLine);
									
									let predictedHash = signed_hash.substring(0,5)+'[....]'+signed_hash.substring(signed_hash.length-5,signed_hash.length);
 									$('#TX_CONFIRMED_LINK_'+chainID).html(predictedHash);
 								
									// Send the tx
 									web3.eth.sendSignedTransaction(signedTX.rawTransaction).on('transactionHash', async function(txHash){ });
 							
 									console.log('[reunitTransfer @'+currentOps+']  '+Date.now()+' | '+tokenName+' | '+chainID+' | Total : '+startPart+'/'+part+'');
 								});
 							}
 						
 						
 				
 					});
 				
 				
 				});
				
			}
			
			if(nativeTest == 1) {
				progress = ((startPart/part)*100).toFixed();
				$('#unlockToSend_check_gas_text').text('Check gas & native fees : '+progress+'%...');
			}
			startPart++;
			
		} else { }
		} else { }
	};
	
	
	
	// If no error
	if(numberError == 0 && part > 0) {
		if(nativeTest == 1) {
			$('#unlockToSend_check_gas_logo').html('<i style="font-size:16px;" class="green fa-check fa-regular"></i>');
 			$('#unlockToSend_sending').css('opacity', 1);
 			$('#unlockToSend_sending_logo').html('<i class="fa fa-spinner-third fa-spin"></i>');
			console.log('%c [reunitTransfer] Txs in queue now', 'background-color:green;color:white');
			reunitTransfer(tokenName,2,p);
		
		} else {
			console.log('%c [reunitTransfer] All txs have been sent', 'background-color:green;color:white');
			let lastLine = `<tr> <td style="padding:5px;text-align:center;"> <img src="./img/${dstChainID}.svg" style="width:20px;height:20px;" /> </td> <td style="padding:5px;"> Total </td> <td style="padding:5px;font-weight:bold;color:#25bccf;"> ${totalAmount} ${tokenName.toUpperCase()} </td> </tr>`;
			$('#unlockToSend_sending_logo').html('<i style="font-size:16px;" class="green fa-check fa-regular"></i>');
			
			$('#bgPopup').fadeOut(500);
			$('.popupHome').hide();
			setTimeout(() => { 
				CURRENT_PAGE	=	"PAGE_SEND_CONFIRMED";
				$('#PAGE_CONFIRMED_TOTAL_AMOUNT_TOP').html(''+totalAmount.toString()+' '+tokenName.toUpperCase()+'');
				$('#PAGE_CONFIRMED_TOTAL_AMOUNT_TOP').css('opacity', '0.1');
				$('#topHeader').css('background', 'transparent');

				$('body').css('background', 'linear-gradient(rgb(13, 29, 49) 0%, rgb(12, 13, 19) 50%)');
				$('#PAGE_SEND_TOKEN').hide();
				$('#PAGE_CONFIRMED_TOTAL_AMOUNT_TOP').html('');
			
				$('#PAGE_SEND_CONFIRMED').fadeIn(function () {
					$('#PAGE_CONFIRMED_TOTAL_AMOUNT_TOP').html(''+totalAmount.toString()+' '+tokenName.toUpperCase()+'');
					$('#PAGE_CONFIRMED_TOTAL_AMOUNT_TOP').animate({"opacity": 1}, 250);
					$('.trConfirmTxStargate').animate({"opacity": 1}, 1000);
				});
			}, 500);
		}
		
	} else {
		$('#BTN_REUNIT_TRANSFER').unbind();
		$('#BTN_REUNIT_TRANSFER').click(function() { checkReunitTransfer(tokenName); })
		$('#BTN_REUNIT_TRANSFER').html('<i class="fa-duotone fa-chevrons-right" style="font-size:13px;"></i> '+LANG_SEND.LG73);
		
		setTimeout(() => { 
			$('#bgPopup').fadeOut(500);
			$('.popupHome').hide();
		}, 500);
		
	}
}





/**
	description		Simple ERC20 Transfer from a token supported by stargate
**/
async function simpleERC20Transfer(tokenName,chainID,p) {
	
	let amount			=	new Big(REUNIT_TRANSFER_CHAIN[chainID]);
	let recipient		=	$('#recipientTarget').val();
	let dstChainID		=	Number($('#PAGE_SEND_DESTINATION_CHAINID').val());
	let numberError		=	0;
	
	let reunitTxID		=	Date.now()	// generateUUID();
	
	let chainData		=	chainsData(chainID);
	let web3			=	new Web3(chainData.node+"&mode=normal");
	let tokenAddress	=	chainData[tokenName]["address"];
	let tokenDecimals	=	chainData[tokenName]["decimals"];
	let tokenDecNumb	=	chainData[tokenName]["decimalNumber"];
	let realChainID		=	chainData.realChainID;
	
	console.log('%c[simpleERC20Transfer] '+tokenName+' from '+chainID+' to '+recipient+'', 'background:#22bcce;color:white;');

	$('#PAGE_CONFIRMED_SUMMARY').html('');

	if(amount.gt(0) && REUNIT_BALANCE[tokenName][chainID].gte(amount)) {
		web3.eth.defaultAccount		=	REUNIT_PUBKEY;
		
		await web3.eth.getGasPrice().then(async function(gasresult) {
			let txRealAmount	=	amount.mul(new Big(10).pow(tokenDecNumb)).toFixed(0).toString();
			let encodeData		=	web3.eth.abi.encodeFunctionCall(ERC20_TRANSFER_ABI,[recipient,''+txRealAmount+'']);						
    		
			await web3.eth.estimateGas({ from:REUNIT_PUBKEY, to: tokenAddress, data: encodeData }).then( async function(gaslimitresult) {
			
				let resultGasLimit	=	new Big(gaslimitresult);	
				let tx_realGasLimit	=	resultGasLimit.add(resultGasLimit.div(100).mul(10)).toFixed(0);				
				let gasResult		=	new Big(gasresult);
				let tx_realGasPrice	=	gasResult.add(gasResult.div(100).mul(REUNIT_CONFIG.gas_speed)).toFixed(0);
				
				console.log('[simpleERC20Transfer] Gas price :'+tx_realGasPrice+' | Gas limit : '+tx_realGasLimit);
				
				await web3.eth.getTransactionCount(REUNIT_PUBKEY).then(async function(txCount) {
				
					let txObject 	= { nonce:    web3.utils.toHex(txCount),
    				 					to:       tokenAddress,
    				 					gasLimit: web3.utils.toHex(tx_realGasLimit),
    				 					gasPrice: web3.utils.toHex(tx_realGasPrice),
    				 					data: encodeData,
    				 					value: 0,
    				 					chainId:realChainID,
    				 					networkId:realChainID };

 					await web3.eth.getBalance(REUNIT_PUBKEY).then(async function(result) {
 						
 						let currentBalance = new Big(result);
 						
 						console.log('[simpleERC20Transfer] Nonce : '+txCount+' | Balance : '+currentBalance);
 						
 						if(currentBalance.gte(Big(tx_realGasLimit).mul(Big(tx_realGasPrice)))) {
 							$('#unlockToSend_check_gas_logo').html('<i style="font-size:16px;" class="green fa-check fa-regular"></i>');
 							$('#unlockToSend_sending').css('opacity', 1);
 							$('#unlockToSend_sending_logo').html('<i class="fa fa-spinner-third fa-spin"></i>');
 							
 							
 							let newLine		=	`<tr> <td style="padding:5px;text-align:center;"> <img src="./img/${chainID}.svg" style="width:20px;height:20px;" /> </td> <td style="padding:5px;"> ${chainData.name} </td> <td style="padding:5px;color:#25bccf;"> <div style="overflow-wrap: break-word;width: 127px;"> ${amount} ${tokenName.toUpperCase()} </div> </td> 
 												 <td style="padding:5px;"> <i class="fa fa-chevron-right"></i> </td> <td> <u id="TX_CONFIRMED_LINK_${chainID}"><i class="fa-spin fa-light fa-circle-notch"></i></u> </td> </tr>`;
 							
 							let dKey		=	await decodeKey(atob(p));
							let signedTX	=	await web3.eth.accounts.signTransaction(txObject, dKey.privKey);
 							let signed_hash	=	signedTX.transactionHash;
 								
 							
    				 		let txInfo	=	{	
    				 							"status": "pending", 
												"amount": amount.toString(), 
												"stargateFees": 0,
												"gasPrice": tx_realGasPrice,
												"gasLimit": tx_realGasLimit,
												"nonce": txCount,
												"timestamp": Date.now(),
												"type": "erc20_transfer",
												"tokenAddress": tokenAddress,
												"tokenDecimals": tokenDecimals,
												"tokenDecNumber": tokenDecNumb,
												"hash": signed_hash,
												"txObject": txObject 
											};
													
    				 				
 							$('#PAGE_CONFIRMED_SUMMARY').append(newLine);
							
							CURRENT_PAGE	=	"PAGE_SEND_CONFIRMED";
							$('#PAGE_CONFIRMED_TOTAL_AMOUNT_TOP').html(''+amount.toString()+' '+tokenName.toUpperCase()+'');
							$('#PAGE_CONFIRMED_TOTAL_AMOUNT_TOP').css('opacity', '0.1');
							$('#topHeader').css('background', 'transparent');
							$('body').css('background', 'linear-gradient(rgb(13, 29, 49) 0%, rgb(12, 13, 19) 50%)');
							
							$('#PAGE_SEND_TOKEN').hide();
							
							console.log('[simpleERC20Transfer] Predicted txHash : '+signed_hash);
							addTxToHistory("STARGATE_"+tokenName+"",reunitTxID,REUNIT_PUBKEY,recipient,Date.now(),amount.toString(),0,tokenName,chainID,chainID,"erc20_transfer",txInfo);
    				 		console.log('%c[simpleERC20Transfer] The transaction is being sent', 'background-color:green;color:white;');

							$('#PAGE_SEND_CONFIRMED').fadeIn(function () {
								$('#PAGE_CONFIRMED_TOTAL_AMOUNT_TOP').html(''+amount.toString()+' '+tokenName.toUpperCase()+'');
								$('#PAGE_CONFIRMED_TOTAL_AMOUNT_TOP').animate({"opacity": 1}, 250, function() {
								
									$('#unlockToSend_sending_logo').html('<i style="font-size:16px;" class="green fa-check fa-regular"></i>');
									$('#bgPopup').fadeOut();
									
									hash = signed_hash.substring(0,5)+'[....]'+signed_hash.substring(signed_hash.length-5,signed_hash.length);
									$('#TX_CONFIRMED_LINK_'+chainID).html(hash);
									
									web3.eth.sendSignedTransaction(signedTX.rawTransaction).once('transactionHash', async function(txHash){
										console.log('[simpleERC20Transfer] Confirmed');
									});
								});
							});
							
							
 						} 
 						else {
 							
 							console.log('%c[simpleERC20Transfer] Transaction canceled : not enough balance', 'background-color:red;color:white;');
 							
 							let error_message	=	"You don't have enough "+chainData['nativeToken']+" to pay the fees";
 							showReunitTransferError(chainID,tokenName,chainData['nativeToken'],0,error_message);
       	 					
       	 					$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
 							$('#bgPopup').fadeOut(1500);			
       	 					$('#BTN_REUNIT_TRANSFER').html('<i class="fa-duotone fa-chevrons-right" style="font-size:13px;"></i> '+LANG_SEND.LG73);
	 						
	 						// Re-bind
	 						$('#BTN_REUNIT_TRANSFER').unbind();
	 						$('#BTN_REUNIT_TRANSFER').click(function() { checkReunitTransfer(tokenName); });
 						}
 									
 					});
 				});
 			});
				
		});
	
	} else {
		$('#BTN_REUNIT_TRANSFER').html('<i class="fa-duotone fa-chevrons-right" style="font-size:13px;"></i> '+LANG_SEND.LG73);
		// Re-bind
		$('#BTN_REUNIT_TRANSFER').unbind();
	 	$('#BTN_REUNIT_TRANSFER').click(function() { checkReunitTransfer(tokenName); });
	}
	
}





/**
	description		View the page to send tokens
**/
async function viewSendPage(tokenName) {
	console.log('%c[viewSendPage] View reunit transfer UI for : '+tokenName+'', 'color:white;background-color:#22bcce;');
	$('#current_tokenName').val(tokenName);
	$('#topHeader_total').fadeOut();
	CURRENT_TRANSACTION_TYPE 	= 	'';
	CURRENT_SRC_CHAINID			=	'';
	
	
	$('#PAGE_SEND_DESTINATION_CHAINID').unbind();
	$('#PAGE_SEND_DESTINATION_CHAINID').change(function() { calculTotal(tokenName); });
	
	$('body').css('background', '#0e1d30');
	
	$('#PAGE_HOME').hide("slide", {direction: "down"});
	
		
		CURRENT_PAGE			=	"PAGE_SEND_TOKEN";
		$('#topHeader').css('background', '#0e1d30');
		$('#topHeader').css('border-bottom', '0px solid #0e1d30');
		
		
		// Re-init
		REUNIT_TRANSFER_CHAIN			=	{};
		REUNIT_BALANCE[tokenName].total	=	new Big(0);
		
		console.log('[viewSendPage] Re-initialization before loading balance : '+JSON.stringify(REUNIT_BALANCE[tokenName]));
		
		$('#recipientTarget').val('');
		$('#recipientTarget').focus();
		$('#BTN_REUNIT_TRANSFER').html('<i class="fa-duotone fa-chevrons-right" style="font-size:13px;"></i> '+LANG_SEND.LG73);
		$('#PAGE_SEND_TOKEN_SUMMARY').hide();
		$('#PAGE_SEND_TOKEN_MAIN_TABLE').html('');
		$('#PAGE_SEND_TOKEN_MAIN_TABLE').html('<tr><td><div style="height:150px;color:black;"><br/><br/><br/><br/><center><i class="fa-duotone fa-spinner fa-spin"></i> '+LANG_HOME.LG59+'...</center></div></td></tr>');
		$('#PAGE_SEND_TOTAL_AMOUNT_TO_SEND').html('0');
		$('#PAGE_SEND_INPUT_TOTAL_AMOUNT_TO_SEND').val(0);
		$('#PAGE_SEND_TOKEN_TOP_TO_RECEIVE').html('00.00');
		$('#PAGE_SEND_TOTAL_TOKEN_NAME').html(tokenName.toUpperCase());
		$('#PST_TOP_CENTER_GAS_DIV').hide();
		
		$('#topPageSend_error').hide();
		$('#PAGE_SEND_TOKEN_TOP_BALANCE').html('00.00');
		$('#PST_IMG_TOP').attr('src', './img/tokens/'+tokenName.toUpperCase()+'.jpeg');
		$('#PSC_TOP_ICO_TOKEN').attr('src', './img/tokens/'+tokenName.toUpperCase()+'.jpeg');
		
		$("#PAGE_SEND_TOKEN").fadeIn(async function() { $('#topHeader').animate({'height': '50px'}); });
		
		$('#PST_TOP_LOADING').show();
	
		// For each chains, re-load balance + show UI
		CHAINS.forEach( function(chainID) {
			let chainINFO	=	chainsData(chainID);
			$('#PST_TOP_CENTER_DIV_TESTNET').hide();
			if(chainINFO.testnet == true) { $('#PST_TOP_CENTER_DIV_TESTNET').show(); } else { $('#PST_TOP_CENTER_DIV_TESTNET').hide(); }
			
			if(chainINFO.hasOwnProperty(tokenName)) {
				$('#PAGE_SEND_DESTINATION_CHAINID').append('<option value='+chainINFO.stargateChainID+'>'+chainINFO.name+'</option>');
			} else { }
		});
			
		$('#PAGE_SEND_TOKEN_TOP_TOKEN').html(tokenName.toUpperCase());
		$('#PAGE_SEND_TOKEN_MAIN_TABLE').html('');
		$('#PAGE_SEND_TOKEN_MAIN_TABLE').append('<tr><td colspan="6"> <div style="margin-top:5px;margin-bottom:5px;width:100%;height:1px;"></div> </td></tr>');
				
		await loadBalanceByToken(tokenName,"PAGE_SEND_TOKEN");

		$('#PAGE_SEND_TOKEN_SUMMARY').show();
      	$('#PAGE_SEND_TOKEN_MASTER_BOTTOM').show();
	
	
	$('#BTN_REUNIT_TRANSFER').unbind( "click" );
	$('#BTN_REUNIT_TRANSFER').click(function() { checkReunitTransfer(tokenName); });
	
	
	
	
}
	
	

/**
	description		Approve stargateRelayer to use our tokens
**/

async function stargateApprove(tokenName,chainID,p) {

	let token	=	tokenName.toLowerCase();
	// UI
	$('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID).unbind();
	$('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID).html('<i class="fa-spin fa-light fa-circle-notch" style="font-size:14px;margin-top:2px;"></i>');
	$('#unlockToSend_check_gas').css('opacity', 1);
	$('#unlockToSend_check_gas_logo').html('<i class="fa-spin fa-light fa-circle-notch"></i>');
	// Verification
	if(CHAINS.includes(chainID) && STARGATE_TOKEN.includes(token)) {
		
		// Prepare the transaction
		let chainData			=	chainsData(chainID);
		let web3				=	new Web3(chainData.node);
		let infinity_amount		=	"115792089237316195423570985008687907853269984665640564039457584007913129639935";
		let encoded_data		=	web3.eth.abi.encodeFunctionCall(ERC20_APPROVE_ABI,[chainData.stargateRelayer, infinity_amount]);
		
		// Run
		await web3.eth.getGasPrice( async function(gaserror,gasresult) {
		
			await web3.eth.getTransactionCount(REUNIT_PUBKEY, async (err, txCount) => {
			
				await web3.eth.estimateGas({ from:REUNIT_PUBKEY, to: chainData[tokenName].address, data: encoded_data}, async function(gaslimiterror,gaslimitresult) {
				
					let gasResult		=	new Big(gasresult);
					let realGasPrice	=	gasResult.add(gasResult.div(100).mul(REUNIT_CONFIG.gas_speed)).toFixed(0);
					
					let txObject 		= { nonce:    web3.utils.toHex(txCount),
    				 						to:       chainData[tokenName].address,
    				 						gasLimit: web3.utils.toHex(gaslimitresult),
    				 						gasPrice: web3.utils.toHex(realGasPrice),
    				 						data: encoded_data,
    				 						value: 0,
    				 						chainId:chainData.realChainID,
    				 						networkId:chainData.realChainID };
    				
    				let dKey		=	await decodeKey(atob(p));
					let signedTX	=	await web3.eth.accounts.signTransaction(txObject, dKey.privKey); 				  
 								
 								
 					if(gaslimiterror != undefined) {
 						console.log('%c[stargateApprove] Error', 'background-color:red;color:white');
 						$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
 						
 						setTimeout( () => {
 							$('#bgPopup').fadeOut();
 							$('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID).unbind('click');
 							$('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID).html('<i class="fa-light fa-circle-x" style="font-size:14px;margin-top:2px;"></i>');
 						
 							let error_message	=	"You don't have enough "+chainData['nativeToken']+" to pay fees";
							$('#TABLE_SEND_DIV_NOTENOUGH_'+chainID).html('<span style="margin-left: 60px;margin-top: -1px;font-weight:bold;width: 300px;position: absolute;">'+error_message+'</span>');
 						}, 500);
 						
 					} else {
 						console.log('[stargateApprove] Transaction sent');
 						$('#unlockToSend_check_gas_logo').html('<i style="font-size:16px;" class="green fa-check fa-regular"></i>');
 						$('#unlockToSend_sending').css('opacity', 1);
 						$('#unlockToSend_sending_logo').html('<i class="fa fa-spinner-third fa-spin"></i>');
 							
 						setTimeout( () => {
 							$('#unlockToSend_sending_logo').html('<i style="font-size:16px;" class="green fa-check fa-regular"></i>');
							$('#bgPopup').fadeOut();
 						}, 500);
 						
 						await web3.eth.sendSignedTransaction(signedTX.rawTransaction).once('transactionHash', async function(txHash){
 							console.log('[stargateApprove] Approval confirmed');
 							$('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID).html('<i class="fa-light fa-circle-check" style="font-size:14px;margin-top:2px;"></i>');
 							$('#TABLE_SEND_DIV_NOTENOUGH_'+chainID).hide("slide", {
 								direction: 'right',
 								complete: function() {
 									$('.TABLE_SEND_TD_'+chainID).css('opacity', 1);
 									$('.TABLE_SEND_TD_'+chainID).fadeIn();
 								}
 							}); 
 						}).catch(function(e) {
 							console.log('%c[stargateApprove] Error approval', 'background-color:red;color:white');
 							$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
 						
 							setTimeout( () => {
 							$('#bgPopup').fadeOut();
 							$('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID).unbind('click');
 							$('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID).html('<i class="fa-light fa-circle-x" style="font-size:14px;margin-top:2px;"></i>');
 						
 							let error_message	=	LANG_CROSSCHAIN.LG95;
							$('#TABLE_SEND_DIV_NOTENOUGH_'+chainID).html('<span style="margin-left: 60px;margin-top: -1px;font-weight:bold;width: 300px;position: absolute;">'+error_message+'</span>');
 							}, 500);
 						});
 					}
				
				});
			
			});
		
		});

	
	} else {
		$('#BTN_TRANSFER_APPROVE_'+tokenName+'_'+chainID).html('<i class="fa-light fa-circle-x"  style="font-size:14px;margin-top:2px;"></i>');
	}
}


/**
	description		View native balance for the send page
**/
async function viewNativeBalance(chainID,val) {
	if(val	==	1) {
		$('#SEND_LOGO_NATIVE_'+chainID+'').unbind("click");
		$('#SEND_LOGO_NATIVE_'+chainID+'').click(function() {  viewNativeBalance(chainID,2); } );
		
		let chainData	=	chainsData(chainID);
		let web3		=	new Web3(chainData.node+"&mode=normal");

		await web3.eth.getBalance(REUNIT_PUBKEY).then(async function(result) {
			let nativeBalance	=	new Big(result).div(new Big(10).pow(18));
			$('#SEND_VIEW_NATIVE_'+chainID).html('');
			$('#SEND_VIEW_NATIVE_'+chainID).css('width', '10px').css('z-index', '22');
			$('#SEND_VIEW_NATIVE_'+chainID).show();
			$('#SEND_VIEW_NATIVE_'+chainID).animate({'width': '270'}, 150, function() {
				$('#SEND_VIEW_NATIVE_'+chainID).html('<div style="margin-top: 6px;font-size:14px;margin-left:10px;">'+nativeBalance+' <sup style="font-size:9px;">'+chainData.nativeToken+'</sup> </div>');
			});
		});
	
	
	} else {
		$('#SEND_LOGO_NATIVE_'+chainID+'').unbind("click");
		$('#SEND_LOGO_NATIVE_'+chainID+'').click(function() {  viewNativeBalance(chainID,1); } );
		$('#SEND_VIEW_NATIVE_'+chainID).html('');
		$('#SEND_VIEW_NATIVE_'+chainID).animate({'width': '10px'}, 150, function() {
			$('#SEND_VIEW_NATIVE_'+chainID).hide();
		});
	}
}





	
/**
	description		Verification of amount > 0, amount <= total balance, recipient exist and is valid, etc...
**/

async function checkReunitTransfer(tokenName) {


	// unbind immediately
	$('#BTN_REUNIT_TRANSFER').unbind( "click" );
	
	let recipient		=	$('#recipientTarget').val();
	let destination		=	Number($('#PAGE_SEND_DESTINATION_CHAINID').val());
	let total			=	new Big($('#PAGE_SEND_INPUT_TOTAL_AMOUNT_TO_SEND').val());
	let checkDstData	=	chainsData(Number(destination));
	let checkerror		=	0;
	
	
	console.log('%c[checkReunitTransfer] Start of checks', 'background-color:#22bcce;color:white;');
	
	
	try { checkDstPoolID =	checkDstData[tokenName]["poolID"]; } catch(e) { checkerror = 1; checkDstPoolID = "ERROR"; }
	
	// 1 - Check Address
	if(!(checkAddress(recipient))) {
		$('#tableTopRecipient').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
		console.log('%c[checkReunitTransfer] Bad recipient address', 'background-color:red;color:white;');
		checkerror = 1;
	} else {
		$('#SUMMARY_RECIPIENT').text(recipient);
		if(checkDstPoolID == "ERROR") {
			$('#PAGE_SEND_DESTINATION_CHAINID').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
			checkerror = 1;
		} else { }
	}
	
	
	// 2 - Check total
	if(total.lte(0)) {
		$('#PAGE_SEND_DIV_TOTALAMOUNT_TO_SEND').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
		console.log('%c[checkReunitTransfer] Amount <= 0 ', 'background-color:red;color:white;');
		checkerror = 1;
	} else {
		$('#PAGE_SEND_TOTAL_AMOUNT_TO_SEND').css('color', 'white');
	}
	
	
	// 3 - Destination not selected
	if(destination == 0) {
		console.log('%c[checkReunitTransfer] No destination', 'background-color:red;color:white;');
		$('#PAGE_SEND_DESTINATION_CHAINID').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
		checkerror = 1;
	} else { }
	
	
	
	let part 		= 	0;
	let srcChainID	=	0;
	CHAINS.forEach( function(chainID) {
		if(REUNIT_TRANSFER_CHAIN.hasOwnProperty(chainID) && REUNIT_TRANSFER_CHAIN[chainID].gt(0)) {
			if(REUNIT_BALANCE[tokenName][chainID].lt(REUNIT_TRANSFER_CHAIN[chainID])) {
				checkerror = 1;
			}
			part++;
			srcChainID	=	chainID;
		} else { }
	});
	
	try {
	if(( (srcChainID == destination) || (srcChainID == checkDstData.realChainID) ) && (part == 1) && checkAddress(recipient) && total.gt(0) && destination != 0 && checkDstPoolID!= "ERROR") {
		if(checkerror != 1) {
			console.log('erc20');
			$('#PSC_TOP_ICO_CHAIN').attr('src', './img/'+destination+'.svg');
			popupSign(tokenName,'ERC20',srcChainID);
		} else { }
	} else { 
		// 5 - Final double check
		if(checkAddress(recipient) && total.gt(0) && destination != 0 && checkDstPoolID!= "ERROR") {
			
			$('#PSC_TOP_ICO_CHAIN').attr('src', './img/'+destination+'.svg');
			popupSign(tokenName,'STARGATE',0);
		} else { checkerror = 1; }

	}
	} catch(e) {
		// Thank you dushidze
		$('#BTN_REUNIT_TRANSFER').click(function() { checkReunitTransfer(tokenName); });
	}
	
	if(checkerror == 1) { $('#BTN_REUNIT_TRANSFER').click(function() { checkReunitTransfer(tokenName); }); } else { }
}
	

/**
	description		Sign the tx from send page
**/
var CURRENT_TRANSACTION_TYPE;
var CURRENT_SRC_CHAINID;
var STARGATE_APPROVAL_CHAINID;
async function popupSign(tokenName,type,chainID) {

	$('#bgPopup').css('background-color', 'rgb(0 0 0 / 0%)').css('backdrop-filter', 'blur(20px)');
	$('#bgPopup').show();
	
	// UI RE-INIT
    $('#unlockToSend_check_gas').css('opacity', 0.3);
    $('#unlockToSend_sending').css('opacity', 0.3);
    $('#unlockToSend_check_gas_logo').text('-');
    $('#unlockToSend_sending_logo').text('-');
    $('#unlockToSend_table').show();
    $('#unlockToSend_signed').show();
    $('#unlockToSend_input').val('');
    $('#unlockToSend_button').text(LANG_SEND.LG81);
    $('#unlockToSend_check_gas_text').text('Check gas & native fees');
    $('#unlockToSend_sending_text').text('Sending');
    $('#unlockToSend_check_destination_text').text('Check destination & recipient address');
    $('#unlockToSend_button').unbind();
    $('#unlockToSend_input').unbind();
   
	$('#POPUP_WAIT_SEND').show();
	
	STARGATE_APPROVAL_CHAINID	=	'';
	
	let	total_amount;
	let tx_type;
	let from_page;
	switch(type) {
		case "ERC20":					
			tx_type = "classic ERC20 transfer";	CURRENT_TRANSACTION_TYPE = "STARGATE_SIMPLE_ERC20";	CURRENT_SRC_CHAINID = Number(chainID);	
			total_amount	=	new Big($('#PAGE_SEND_INPUT_TOTAL_AMOUNT_TO_SEND').val());
			from_page		=	"stargate_page";
			$('#unlockToSend_amount').text(total_amount.toString()+' '+tokenName.toUpperCase());
			break;
		case "CUSTOM_ERC20_TRANSFER":	
			tx_type	= "classic ERC20 transfer"; CURRENT_TRANSACTION_TYPE = "CUSTOM_ERC20_TRANSFER";	
			total_amount	=	new Big($('#PSCT_AMOUNT').val());	
			from_page		=	"custom_erc20_page";
			$('#unlockToSend_amount').text(total_amount.toString()+' '+tokenName.toUpperCase());
			break;
		case "STARGATE_APPROVE":
			tx_type	= "Approval request";	
			from_page					=	"stargate_approval";
			let chainInfo				=	chainsData(Number(chainID));
			STARGATE_APPROVAL_CHAINID	=	Number(chainID);
			$('#unlockToSend_amount').html('Approve '+tokenName.toUpperCase()+' <br/>cross-chain transfer on '+chainInfo.nativeToken);
			$('#unlockToSend_check_destination_text').text('Only one approval per blockchain & token');
			break;
		default:						
			tx_type = "crosschain transfer";	CURRENT_TRANSACTION_TYPE = "STARGATE_CROSSCHAIN";	
			total_amount	=	new Big($('#PAGE_SEND_INPUT_TOTAL_AMOUNT_TO_SEND').val());	
			from_page		=	"stargate_page";
			$('#unlockToSend_amount').text(total_amount.toString()+' '+tokenName.toUpperCase());
			break;
	}
	
	$('#unlockToSend_button').click(async function() { let p	=	$('#unlockToSend_input').val(); unlockWallet(p,from_page);  });
	$('#unlockToSend_input').keyup(async function(e) { if(e.which == 13) { let p	=	$('#unlockToSend_input').val(); unlockWallet(p,from_page); } else { } });
	
	
	$('#unlockToSend_type').text(tx_type);
	
}	

/**
	description		Get tokens list
**/
async function getTokensList() {
	let list		=	await fetch("./js/tokens_list.json");
	let json_list	=	await list.json();
	TOKENS_LIST		=	json_list;
	return true;
}


/**
	description		Search token in list
**/
function searchInsideTokenList() {
	let inputSearch	=	$('#searchTokenInput').val().toLowerCase();
	let init_result	=	0;
	let max_result	=	40;
	$('#resultListToken').html('');
	TOKENS_LIST.forEach(function(tok) {
	
		if(init_result <= max_result && (tok.name.toLowerCase().includes(inputSearch) || tok.symbol.toLowerCase().includes(inputSearch) || tok.address.toLowerCase().includes(inputSearch))) {
			
			let tk_id						=	tok.address.toLowerCase()+'_'+tok.chainId;
			let uuid						=	'add_'+tok.address.toLowerCase()+'_'+tok.chainId;
			let token_to_add				=	tok;
			token_to_add['balance']			=	0;
			token_to_add['added_timestamp']	=	Date.now();
			let square;
			
			if(MY_TOKENS_LIST.hasOwnProperty(tk_id)) {
				square	=	'<i id="'+uuid+'" class="fa-solid fa-square-check square"></i>';
				$('#resultListToken').append('<tr class="trAddToken"> <td class="td_'+uuid+'" valign="TOP" style="border-top-left-radius:10px;border-bottom-left-radius:10px;padding-top:10px;padding-bottom:10px;width:50px;position:relative;"> <img src="./img/list/'+tok.chainId+'.svg" class="topChainIDIMG" /> <img src="'+tok.logoURI+'" style="border-radius:100px;width:35px;" /> </td> <td valign="TOP" class="td_'+uuid+'" style="padding-left:10px;width:280px;"> <span style="font-weight:bold;font-size:18px;font-family:\'Open Sans\',sans-serif;">'+tok.name+'</span> / '+tok.symbol+' <br/> <span style="font-size:11px;">'+tok.address+'</span> </td> <td style="cursor:pointer;font-size:24px;width:40px;border-top-right-radius:10px;border-bottom-right-radius:10px;"> '+square+' </td> </tr>');
				
				$('#'+uuid+'').click(function() {  
					manageTokenToTokensList("DELETE", tk_id, token_to_add, 1);
				});
				
				
				$('.td_'+uuid+'').click(function() {  
					manageTokenToTokensList("DELETE", tk_id, token_to_add, 1);
				});
				

				
			} else {
				square	=	'<i id="'+uuid+'" class="fa-light fa-square square"></i>';
				$('#resultListToken').append('<tr class="trAddToken"> <td class="td_'+uuid+'" valign="TOP" style="border-top-left-radius:10px;border-bottom-left-radius:10px;padding-top:10px;padding-bottom:10px;width:50px;position:relative;"> <img src="./img/list/'+tok.chainId+'.svg" class="topChainIDIMG"  /> <img src="'+tok.logoURI+'" style="border-radius:100px;width:35px;" /> </td> <td valign="TOP" class="td_'+uuid+'" style="padding-left:10px;width:280px;"> <span style="font-weight:bold;font-size:18px;font-family:\'Open Sans\',sans-serif;">'+tok.name+'</span> / '+tok.symbol+' <br/> <span style="font-size:11px;">'+tok.address+'</span> </td> <td style="cursor:pointer;font-size:24px;width:40px;border-top-right-radius:10px;border-bottom-right-radius:10px;"> '+square+' </td> </tr>');
				
				// Add the token to our tokens list
				
				$('#'+uuid+'').click(function() {  
					manageTokenToTokensList("ADD", tk_id, token_to_add, 1);
				});
				
				
				$('.td_'+uuid+'').click(function() {  
					manageTokenToTokensList("ADD", tk_id, token_to_add, 1);
				});
				
			}
			$("img").off();
			$("img").on("error", function () { $(this).attr("src", "./img/no_image.png"); });
			init_result++;
		} 
	
	});
	
	if(init_result == 0) {
	
		$('#resultListToken').append('<tr> <td> <center> <br/><br/><br/> <span style="font-family:\'Arial\',sans-serif;">Search through <b>7</b> blockchains : </span> <br/><br/> <img src="./img/1.svg" style="width:20px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/2.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/6.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/9.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/10.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/42161.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" /> <img src="./img/12.svg" style="width:20px;margin-left:5px;border-radius:100px;box-shadow: 0px 0px 5px white;" />  </center> </td> </tr>');
	} else { }
	
	
}

/**
	description		get custom Tokens List
**/
async function loadTokensList() {
	console.log('[loadTokensList] start loading');
	chrome.storage.local.get(['CUSTOM_TOKEN_LIST'], function(tlist) {
		try {		
			MY_TOKENS_LIST	=	tlist['CUSTOM_TOKEN_LIST'];	
			
			if(MY_TOKENS_LIST == undefined) { 
				MY_TOKENS_LIST = {}; 
			} else { }
			
			
			// Load stargate & all tokens added
			
			
			
		}
		catch(e) {	MY_TOKENS_LIST	=	{}; }
	});
	
}


/**
	description		load tokens balance
**/
async function loadBalanceTokensList() {
	console.log('%c[loadBalanceTokensList] Load balance of custom tokens', 'background-color:#22bcce;color:white;');
	
	Object.keys(MY_TOKENS_LIST).forEach(async function (s) {
	
		let current_token	=	MY_TOKENS_LIST[s];
		
		
		if(!s.includes('STARGATE_') && !s.includes('NATIVE_') && (current_token[CURRENT_TOKENLIST] || CURRENT_TOKENLIST == "ALL")) {
			let chainData		=	chainsData(current_token.chainId);
			let web3			=	new Web3(chainData.node+"&mode=normal");
			let contract		=	new web3.eth.Contract(ERC20_ABI, current_token.address);
			let oracle			=	new web3.eth.Contract(ONCHAIN_ORACLE, chainData.oracle);	
			
			console.log('[loadBalanceTokensList] Load : '+current_token.address+' | '+current_token.chainId);
			
			let stablecoin;
			let stablecoin_decimals;
				
			switch(current_token.chainId) {
				case 102:
				case 56:
					stablecoin			=	chainData.usdt.address;
					stablecoin_decimals	=	1e18;
					break;
				default:
					stablecoin			=	chainData.usdc.address;
					stablecoin_decimals	=	1e6;
					break;			
			}
				
			try {
			await contract.methods.balanceOf(REUNIT_PUBKEY).call().then( function(result) {
				// UI
				
				$('#HOME_VIEW_BALANCE_'+current_token.address.toLowerCase()+'_'+current_token.chainId+'').html(Intl.NumberFormat('en-US', {}).format(result/Math.pow(10,current_token.decimals)));
		
				// Update MY_TOKENS_LIST
				current_token.balance	=	result;
			
			
			}).catch( function(e) { 
				console.log("[loadBalanceTokensList] - Error : "+s);
			});	
			} catch(e) {
				console.log("[loadBalanceTokensList] - Error : "+s);
			}
			
			
			// Oracle
			try {
				
				if(MY_TOKENS_LIST[s].fixed_usd != 1) {
				
				await oracle.methods.getRate(stablecoin, current_token.address, false).call().then( function(result) {
						let price;
						if(current_token.chainId == 56) {
							price	=	1/result*1e18;
						} else {
							price	=	(stablecoin_decimals*stablecoin_decimals)/(result/(10**current_token.decimals));
						}
						
						if(price != Infinity && price >= 0.0000001 && price < 10000000) {
							console.log(current_token.symbol+'@'+current_token.chainId+' - '+current_token.address+' = '+price.toFixed(6));
						} else { 
							price = 0;
						}
						
						MY_TOKENS_LIST[s].usd_price		=	price;
						chrome.storage.local.set({CUSTOM_TOKEN_LIST: MY_TOKENS_LIST});
						calculUnifiedBalance();
				});
				
				} else {
					// No double count for STABLECOIN
					
					SUPPORTED_STARGATE_TOKEN.forEach(function(stoken) {
						if(stoken.toLowerCase() == current_token.address.toLowerCase()) {
							MY_TOKENS_LIST[s].is_stargate	=	1;
							MY_TOKENS_LIST[s].usd_price		=	1;
						} else { }
					});
					
					chrome.storage.local.set({CUSTOM_TOKEN_LIST: MY_TOKENS_LIST});
					calculUnifiedBalance();
				}
				
			}catch(e) { 
				console.log('[USD Price] KO');
			}
		
		} else { }
		
	});
	
	
	
}

/**
	description		manage Tokens List
**/
function manageTokenToTokensList(action, key, value, UI) {

	switch(action) {
		case "ADD":
			console.log('ADD');
			MY_TOKENS_LIST[key]	=	value;
			chrome.storage.local.set({CUSTOM_TOKEN_LIST: MY_TOKENS_LIST});
			if(UI == 1) {
				$('#add_'+key+'').unbind("click");
				$('.td_add_'+key+'').unbind("click");
				
				$('#add_'+key+'').removeClass('fa-light fa-square').addClass('fa-solid fa-square-check');
				
				$('#add_'+key+'').click(function() { manageTokenToTokensList("DELETE", key, value, 1); });
				$('.td_add_'+key+'').click(function() { manageTokenToTokensList("DELETE", key, value, 1); });
			} else { }
			tinyNotif('Added', 250);
			break;
		case "DELETE":
			console.log('DELETE');
			delete MY_TOKENS_LIST[key];
			chrome.storage.local.set({CUSTOM_TOKEN_LIST: MY_TOKENS_LIST});
			if(UI == 1) {
				$('#add_'+key+'').unbind("click");
				$('.td_add_'+key+'').unbind("click");
				
				$('#add_'+key+'').removeClass('fa-solid fa-square-check').addClass('fa-light fa-square');
				
				$('#add_'+key+'').click(function() { manageTokenToTokensList("ADD", key, value, 1); });
				$('.td_add_'+key+'').click(function() { manageTokenToTokensList("ADD", key, value, 1); });
			} else { }
			tinyNotif(LANG_HOME.LG56, 250);
			break;
	}
}


/**
	description		Show selected tokens by CURRENT_TOKENLIST 
**/
function showSelectedTokens(init) {
	console.log('%c[showSelectedTokens]', 'background-color:orange;');
	
	let tokenCount	=	0;
	if(init	==	1) {
		$('#PAGE_HOME_NATIVE_TOKEN').html('');
		$('#PAGE_HOME_CUSTOM_TOKENS_VIEW').html('');
		$('#PAGE_HOME_TOKENS_VIEW').html('');
	} else { }
	
	
	// Stargate Tokens
	STARGATE_TOKEN.forEach( function(tokenName) {
			let IN_LIST;
			try {
				IN_LIST= MY_TOKENS_LIST['STARGATE_'+tokenName.toLowerCase()][CURRENT_TOKENLIST]
			} catch(e) { IN_LIST = 0; } 
			if(CURRENT_TOKENLIST == "ALL" || IN_LIST == true) {
			var newLine	=	`<tr style="position:relative;" class="trHomeTokenLIST tr_STARGATE_${tokenName.toLowerCase()}" token="${tokenName.toUpperCase()}" >
			<td style="width:5px;position:relative;">
				<i token="STARGATE_${tokenName.toLowerCase()}" key="STARGATE_${tokenName.toLowerCase()}" class="viewHomeTokenMenu viewMenu_STARGATE_${tokenName.toLowerCase()} fa-regular fa-ellipsis-vertical pointer" style="cursor:pointer;"></i>
			</td>
			
			<td style="width:53px;"><img src="./img/tokens/${tokenName.toUpperCase()}.jpeg" style="border-radius:100px;width:30px;height:30px;margin-left:10px;cursor:pointer;" token="STARGATE_${tokenName.toLowerCase()}" key="STARGATE_${tokenName.toLowerCase()}" class="viewHomeTokenMenu" />
			</td>
			<td class="td_STARGATE_${tokenName.toLowerCase()}" style="width:100px;">
				<b>${tokenName.toUpperCase()}</b>
				<br/>
				<span id="HOME_VIEW_BALANCE_${tokenName.toUpperCase()}">${Intl.NumberFormat('en-US', {}).format(REUNIT_BALANCE[tokenName]["total"]).toString()}</span>
			</td>
			<td class="td_STARGATE_${tokenName.toLowerCase()}" style="width:245px;" dir="rtl">
				<div style="width:100px;margin-top:5px;">
					<table border="0" style="font-size:13px;">
						<tr>
							<td>
								<div token="${tokenName.toLowerCase()}" class="tdRight homeSend" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-top-right-radius:5px;color: black;background-color:white;font-size:13px;width:70px;"><i class="fa-solid fa-paper-plane"></i></div>
							</td>
							
							<td>
								<div class="tdRight buttonInfo" chainID="0" index_info="STARGATE_${tokenName.toLowerCase()}" tokenID="${tokenName}" type="stargate" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-top-left-radius:5px;color: black;background-color:white;font-size:13px;width:70px;">info</div>
							</td>
						</tr>
						<tr>
							<td>
								<div class="tdRight buttonTrade" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-bottom-right-radius:5px;color: black;background-color:white;font-size:13px;width:70px;">trade</div>
							</td>
							
							<td>
								<div class="tdRight buttonHistory" index_info="STARGATE_${tokenName.toLowerCase()}" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-bottom-left-radius:5px;color: black;background-color:white;font-size:13px;width:70px;">history</div>
							</td>
						</tr>
					</table>
				</div>

			</td>
			</tr>
			
			<tr  class="trHomeTokenHistory tr_STARGATE_${tokenName.toLowerCase()}" token="${tokenName.toUpperCase()}"><td colspan="6"> <div class="divHomeHistory" id="HOME_HISTORY_STARGATE_${tokenName.toLowerCase()}" style="position:relative;margin-top:10px;margin-bottom:10px;width:100%;height:1px;background:linear-gradient(0deg, white, #007bff0d);"></div> </td></tr>`;
			
			$('#PAGE_HOME_TOKENS_VIEW').append(newLine);
			tokenCount++;
			}
	});
			
	$('.homeSend').click(function() { viewSendPage($(this).attr('token')); });
	
	
	// Native Tokens
	let nativeCount = 0;

	CHAINS.forEach( function(c) {
		let IN_LIST;
		let infoToken	=	chainsData(c);
		try {
			IN_LIST= MY_TOKENS_LIST['NATIVE_'+c+'_'+infoToken.nativeToken.toLowerCase()][CURRENT_TOKENLIST]
		} catch(e) { IN_LIST = 0; } 
		if(CURRENT_TOKENLIST == "ALL" || CURRENT_TOKENLIST == "NATIVE" || IN_LIST == true) {
			nativeCount++;
			let tokenName	=	infoToken.nativeToken;
			
			let imgToken;
			let ethTokenByChain	=	[1,42161,10,5];
			if(ethTokenByChain.includes(c)) {
				imgToken	=	1;
			} else {
				imgToken	=	c;
			}
			var newLine	=	`<tr style="position:relative;" class="trHomeTokenLIST tr_NATIVE_${c}_${tokenName.toLowerCase()}" token="${tokenName.toUpperCase()}" >
			<td style="width:5px;position:relative;">
				<i token="NATIVE_${c}_${tokenName.toLowerCase()}" key="NATIVE_${c}_${tokenName.toLowerCase()}" class="viewHomeTokenMenu viewMenu_NATIVE_${c}_${tokenName.toLowerCase()} fa-regular fa-ellipsis-vertical pointer" style="cursor:pointer;"></i>
			</td>
			
			<td style="width:53px;">
			<img src="./img/${c}.svg" style="position:absolute;width:17px;border-radius:100px;margin-left:27px;top:9px;border:2px solid white;" />
			<img src="./img/${imgToken}.svg" style="border-radius:100px;width:30px;height:30px;margin-left:10px;cursor:pointer;" token="NATIVE_${c}_${tokenName.toLowerCase()}" key="NATIVE_${c}_${tokenName.toLowerCase()}" class="viewHomeTokenMenu" />
			</td>
			<td class="td_NATIVE_${c}_${tokenName.toLowerCase()}" style="width:100px;">
				<b>${tokenName.toUpperCase()}</b>
				<br/>
				<span id="HOME_VIEW_BALANCE_${c}_${tokenName.toUpperCase()}">${Intl.NumberFormat('en-US', {}).format(0)}</span>
			</td>
			<td class="td_NATIVE_${c}_${tokenName.toLowerCase()}" style="width:245px;" dir="rtl">
				<div style="width:100px;margin-top:5px;">
					<table border="0" style="font-size:13px;">
						<tr>
							<td>
								<div token="${c}_${tokenName.toLowerCase()}" class="tdRight homeSendNativeToken" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-top-right-radius:5px;color: black;background-color:white;font-size:13px;width:70px;"><i class="fa-solid fa-paper-plane"></i></div>
							</td>
							
							<td>
								<div class="tdRight buttonInfo" chainID="0" index_info="NATIVE_${c}_${tokenName.toLowerCase()}" tokenID="${c}_${tokenName}" type="native" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-top-left-radius:5px;color: black;background-color:white;font-size:13px;width:70px;">info</div>
							</td>
						</tr>
						<tr>
							<td>
								<div class="tdRight buttonTrade" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-bottom-right-radius:5px;color: black;background-color:white;font-size:13px;width:70px;">trade</div>
							</td>
							
							<td>
								<div class="tdRight buttonHistory" index_info="NATIVE_${c}_${tokenName.toLowerCase()}" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-bottom-left-radius:5px;color: black;background-color:white;font-size:13px;width:70px;">history</div>
							</td>
						</tr>
					</table>
				</div>

			</td>
			</tr>
			
			<tr  class="trHomeTokenHistory tr_NATIVE_${c}_${tokenName.toLowerCase()}" token="${tokenName.toUpperCase()}"><td colspan="6"> <div class="divHomeHistory" id="HOME_HISTORY_NATIVE_${c}_${tokenName.toLowerCase()}" style="position:relative;margin-top:10px;margin-bottom:10px;width:100%;height:1px;background:linear-gradient(0deg, white, #007bff0d);"></div> </td></tr>`;
			
			$('#PAGE_HOME_NATIVE_TOKEN').append(newLine);
		} else { }
	});
	
	
	// Load native balance
	loadNativeBalance('VIEW_HOME');
	
	
	// Custom ERC20
	let customCount = 0;
	Object.keys(MY_TOKENS_LIST).forEach(function (s) {

		let selectedToken	=	MY_TOKENS_LIST[s];

		if(!s.includes("STARGATE_") && !s.includes("NATIVE_") && (selectedToken[CURRENT_TOKENLIST] || CURRENT_TOKENLIST == "ALL")) {
		tokenCount++;
		customCount++;
		let removeFromList;
		let menuWidth	=	'width: 100px;height: 30px;';
		if(CURRENT_TOKENLIST != "ALL") {
			removeFromList	=	'<span class="spanRemove removeThisTokenFromThisList" key="${selectedToken.address.toLowerCase()}_${selectedToken.chainId}" token="ERC20_${selectedToken.address.toLowerCase()}_${selectedToken.chainId}" style="cursor:pointer;font-weight: normal;"><i class="reunitGradient fa fa-square-x" style="font-size:14px;"></i> Remove from this list</span><br>';
			menuWidth		=	'width: 150;height: 45;';
		} else {
			removeFromList	=	'';
		}
		
		
		
		let newLine	=	`<tr class="trHomeTokenList tr_ERC20_${selectedToken.address.toLowerCase()}_${selectedToken.chainId}" token="${selectedToken.symbol.toUpperCase()}" >
			<td style="width:5px;position:relative;">
				<i token="ERC20_${selectedToken.address.toLowerCase()}_${selectedToken.chainId}"  key="${selectedToken.address.toLowerCase()}_${selectedToken.chainId}" class="viewHomeTokenMenu viewMenu_ERC20_${selectedToken.address.toLowerCase()}_${selectedToken.chainId} fa-regular fa-ellipsis-vertical pointer" style="cursor:pointer;"></i>
			</td>
			
			<td style="width:53px;text-align:center;position:relative;">
				<img src="./img/${selectedToken.chainId}.svg" style="position:absolute;width:17px;border-radius:100px;margin-left:17px;top:9px;border:2px solid white;" />
				<img src="${selectedToken.logoURI}" style="width:30px;border-radius:100px;height:30px;cursor:pointer;" class="viewHomeTokenMenu" token="ERC20_${selectedToken.address.toLowerCase()}_${selectedToken.chainId}"  key="${selectedToken.address.toLowerCase()}_${selectedToken.chainId}" />
			</td>
			<td style="width:100px;padding-left:3px;">
				<b>${selectedToken.symbol.toUpperCase()}</b>
				<br/>
				<span id="HOME_VIEW_BALANCE_${selectedToken.address.toLowerCase()}_${selectedToken.chainId}">${selectedToken.balance.toString()}</span>
			</td>
			<td class="td_ERC20_${selectedToken.address.toLowerCase()}_${selectedToken.chainId}" style="width:245px;" dir="rtl">
				<div style="width:100px;margin-top:5px;">
					<table border="0" style="font-size:13px;">
						<tr>
							<td>
								<div token="${selectedToken.address.toLowerCase()}_${selectedToken.chainId}" class="tdRight homeSendCustomToken" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-top-right-radius:5px;color: black;background-color:white;font-size:13px;width:70px;"><i class="fa-solid fa-paper-plane"></i></div>
							</td>
							
							<td>
								<div class="tdRight buttonInfo" type="custom" chainID="${selectedToken.chainId}" index_info="ERC20_${selectedToken.chainId}_${selectedToken.address.toLowerCase()}" tokenID="${selectedToken.address.toLowerCase()}" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-top-left-radius:5px;color: black;background-color:white;font-size:13px;width:70px;">info</div>
							</td>
						</tr>
						<tr>
							<td>
								<div class="tdRight buttonTrade" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-bottom-right-radius:5px;color: black;background-color:white;font-size:13px;width:70px;">trade</div>
							</td>
							
							<td>
								<div class="tdRight buttonHistory" index_info="ERC20_${selectedToken.chainId}_${selectedToken.address.toLowerCase()}" style="box-shadow: 0px 0px 10px #dadada;border:0px solid #e0e0e0;border-bottom-left-radius:5px;color: black;background-color:white;font-size:13px;width:70px;">history</div>
							</td>
						</tr>
					</table>
				</div>

			</td>
			</tr>
			
			<tr class="trHomeTokenHistory tr_ERC20_${selectedToken.address.toLowerCase()}_${selectedToken.chainId}" token="${selectedToken.symbol.toUpperCase()}"><td colspan="6"> 
				<div class="divHomeHistory" id="HOME_HISTORY_ERC20_${selectedToken.chainId}_${selectedToken.address.toLowerCase()}" style="position:relative;overflow:hidden;-ms-overflow-style: none; scrollbar-width: none;margin-top:10px;margin-bottom:10px;width:100%;height:1px;background:linear-gradient(0deg, white, #007bff0d);"></div> </td></tr>`;
			
			$('#PAGE_HOME_CUSTOM_TOKENS_VIEW').append(newLine);
			
		} else { }
	
	});

	loadBalanceTokensList();
	
	$('.homeSendCustomToken').unbind();
	$('.homeSendCustomToken').click(function() { viewSendCustomTokenPage($(this).attr('token'), 'ERC20'); });
	
	$('.homeSendNativeToken').unbind();
	$('.homeSendNativeToken').click(function() { viewSendCustomTokenPage($(this).attr('token'), 'NATIVE'); });
	
	
	$('.buttonHistory').unbind('click');
	$('.buttonHistory').click(async function() {
		let index	=	$(this).attr('index_info');
		viewHistory(index);
	});


	$('.buttonTrade').unbind();
	$('.buttonTrade').click( async function() { tinyNotif('Available soon', 300, 60, 1000); });


	$('.buttonInfo').unbind('click');
	$('.buttonInfo').click(async function() {
		let tokenID		=	$(this).attr('tokenID');
		let type		=	$(this).attr('type');
		let index		=	$(this).attr('index_info');
		let tokchain	=	$(this).attr('chainID');
		viewInfo(index,type,tokenID,tokchain);
	});
	
	$("img").off();
	$("img").on("error", function () { $(this).attr("src", "./img/no_image.png"); });
	
	
	if(customCount > 0) {
		$('#PAGE_HOME_CUSTOM_TOKENS_VIEW_TOPTEXT').show();
	} else { $('#PAGE_HOME_CUSTOM_TOKENS_VIEW_TOPTEXT').hide(); }
	
	if(nativeCount >0) {
		if(CURRENT_TOKENLIST != "NATIVE") {
			$('#PAGE_HOME_NATIVE_TOKEN_TOPTEXT').show();
		} else {
			$('#PAGE_HOME_NATIVE_TOKEN_TOPTEXT').hide(); 
		}
	} else { $('#PAGE_HOME_NATIVE_TOKEN_TOPTEXT').hide(); }
	
	if(tokenCount == 0 && nativeCount == 0) {
		$('#PAGE_HOME_EMPTY_LIST').show('slide', {direction: "up"});
		$('#PAGE_HOME_CUSTOM_TOKENS_VIEW').hide();
		$('#PAGE_HOME_TOKENS_VIEW').hide();
	} else {
		$('#PAGE_HOME_EMPTY_LIST').hide('slide', {direction: "up"}, function() {
			$('#PAGE_HOME_CUSTOM_TOKENS_VIEW').show();
			$('#PAGE_HOME_TOKENS_VIEW').show();
		});
	}
	
	
	$('.viewHomeTokenMenu').unbind();
	$('.viewHomeTokenMenu').click(async function() { viewMenuToken($(this).attr('token'),$(this).attr('key')); });
	
}
	

/**
	description		Load contacts list
**/

function loadContact(p) {
	chrome.storage.local.get(['CONTACTS_LIST'], function(clist) {
		try {
			MY_CONTACTS_LIST	=	clist['CONTACTS_LIST'];	
			if(MY_CONTACTS_LIST == undefined) { 
				MY_CONTACTS_LIST = {}; 
			} else { 
				// UI
				viewContactsList(p);
			}
		}
		catch(e) {	MY_CONTACTS_LIST	=	{}; }
	});
	
	
	
}




/**
	description		View contacts list
**/
function viewContactsList(p) {

	// UI Re-init
	$('#TABLE_POPUP_CONTACT_LIST').html('');
	
	// View all contacts
	Object.keys(MY_CONTACTS_LIST).forEach(function (cid) {
		let contact_cid		=	cid;
		let contact_name	=	MY_CONTACTS_LIST[cid].name;
		let contact_pseudo	=	MY_CONTACTS_LIST[cid].pseudo;
		let contact_address	=	MY_CONTACTS_LIST[cid].address;
		let contact_picture	=	"./img/logo_400.jpeg";
		if( (MY_CONTACTS_LIST[cid].picture).length == 0 ) { 
			contact_picture	=	"./img/logo_400.jpeg";
		} else {
			contact_picture	=	MY_CONTACTS_LIST[cid].picture;
		}
		
		
		$('#TABLE_POPUP_CONTACT_LIST').append('<tr class="trContactFullText" id="TR_TOP_CONTACT_'+contact_cid+'" contact_id="'+contact_cid+'" fulltext="_'+contact_name+'_'+contact_pseudo+'_'+contact_address+'" ><td style="height:10px;"></td></tr>');
		let new_contact_line	=	`<tr id="TR_CONTENT_CONTACT_${contact_cid}" class="trAddContact trContactFullText" contact_id="${contact_cid}" fulltext="_${contact_name}_${contact_pseudo}_${contact_address}">
							<td style="border-top-left-radius:10px;border-bottom-left-radius:10px;" class="selectContact confContact_${contact_cid}"  address="${contact_address}">
								<img id="CONF_CONTACT_${contact_cid}_PICTURE" src="${contact_picture}" style="box-shadow:0px 0px 3px #ffffff6b;width:50px;border-radius:10px;" />
							</td>
							<td style="font-size: 13px;padding-left: 20px;width:270px;">
								
								<div id="VIEW_CONTACT_ID_${contact_cid}" class="selectContact confContact_${contact_cid}"  address="${contact_address}">
									<span id="CONF_CONTACT_${contact_cid}_NAME" class="reunitGradient" style="font-weight: bold;">${contact_name} |</span>
									<span id="CONF_CONTACT_${contact_cid}_PSEUDO" style="font-size: 12px;"> ${contact_pseudo}</span>
									<br/>
									<span id="CONF_CONTACT_${contact_cid}_ADDRESS" style="font-family:'Arial', sans-serif;font-size:12px;">
									<b>${contact_address.substring(0,7)}</b><span style="font-size:11px;opacity:0.7;">${contact_address.substring(7,37)}</span><b>${contact_address.substring(37,42)}</b>
									</span>
								</div>
								
								<div id="EDIT_CONTACT_ID_${contact_cid}" style="display:none;">
									<input id="CONTACT_${contact_cid}_INPUT_NAME" autocorrect="false" spellcheck="false" placeholder="Name" type="text" style="outline:none;width:125px;background-color:transparent;color:#d27ea6;border:0px;border-bottom:1px dashed #FFFFFF50;font-size:13px;font-family:'Open Sans';" value="${contact_name}" /> | 
									<input id="CONTACT_${contact_cid}_INPUT_PSEUDO" autocorrect="false" spellcheck="false" placeholder="Twitter / Telegram username" type="text" style="outline:none;width:125px;background-color:transparent;color:white;border:0px;border-bottom:1px dashed #FFFFFF50;font-size:12px;font-family:'Open Sans';" value="${contact_pseudo}" />
									<br/>
									<input id="CONTACT_${contact_cid}_INPUT_ADDRESS" autocorrect="false" spellcheck="false" placeholder="Address" type="text" style="margin-top:10px;outline:none;width:265px;background-color:transparent;color:white;border:0px;border-bottom:1px dashed #FFFFFF50;font-size:11px;font-family:'Arial';" value="${contact_address}" />
								</div>
								
								
							</td>
							
							<td style="width:30px;text-align:center;font-size:16px;border-top-right-radius:10px;border-bottom-right-radius:10px;">
								<i contact_id="${contact_cid}" style="opacity:0.5;" class="deleteContact toOpacOne fa-light fa-xmark"></i>
								<br/>
								<i id="ICON_EDIT_CONTACT_ID_${contact_cid}" style="opacity:0.5;margin-top:3px;" class="toOpacOne fa-light fa-pen-to-square editContact" contact_id="${contact_cid}"></i>
								<i id="ICON_VALID_CONTACT_ID_${contact_cid}" style="opacity:0.5;margin-top:7px;display:none;" class="toOpacOne fa-light fa-check validEditContact" contact_id="${contact_cid}"></i>
								
							</td>
						</tr>`;
						
		$('#TABLE_POPUP_CONTACT_LIST').append(new_contact_line);
		
	});
	
	
	// UI	----------
	$('.selectContact').click(function() {
		if(p == "erc20") {
			$('#PSCT_RECIPIENT').val($(this).attr('address'));
		} else {
			$('#recipientTarget').val($(this).attr('address'));
		}
		
		$('#POPUP_MANAGE_CONTACT').fadeOut();
		$('#bgPopup').fadeOut();
	});
	
	
	$('.editContact').unbind('click');
	$('.editContact').click(function () {
		let cid	=	$(this).attr('contact_id');
		$('#EDIT_CONTACT_ID_'+cid+'').fadeIn();
		$('#VIEW_CONTACT_ID_'+cid+'').hide();
		$('#ICON_EDIT_CONTACT_ID_'+cid+'').hide();
		$('#ICON_VALID_CONTACT_ID_'+cid+'').show();
	});
			
	
	$('.validEditContact').unbind('click');
	$('.validEditContact').click(function () {
		let cid	=	$(this).attr('contact_id');
		updateContact("UPDATE", cid);
	});
	
	$('.deleteContact').unbind('click');
	$('.deleteContact').click(function () {
		let cid	=	$(this).attr('contact_id');
		updateContact("DELETE", cid, 2);
	});
		
}


/**
	description		Update contacts list
**/
function updateContact(action, cid) {
	console.log('%c[updateContact]', 'background-color:orange');
	switch(action) {
		case "ADD":
			let  contact_to_add = {};
			contact_to_add['name']		=	$('#CONTACT_'+cid+'_INPUT_NAME').val();
			contact_to_add['pseudo']	=	$('#CONTACT_'+cid+'_INPUT_PSEUDO').val();
			contact_to_add['address']	=	$('#CONTACT_'+cid+'_INPUT_ADDRESS').val();
			contact_to_add['picture']	=	"./img/logo_400.jpeg";
			
			MY_CONTACTS_LIST[cid] = contact_to_add;
			
			// Update local
			chrome.storage.local.set({CONTACTS_LIST: MY_CONTACTS_LIST});
			
			// UI
			$('#POPUP_DIV_CONTACT_LIST').css('opacity', '0.2');
			$('#POPUP_DIV_CONTACT_LIST_LOADING').show('puff');
			
			setTimeout(() => { 
				viewContactsList();
				$('#POPUP_DIV_CONTACT_LIST').css('opacity', '1');
				$('#POPUP_DIV_CONTACT_LIST_LOADING').hide();
			}, 1250);
			
		break;
		case "UPDATE":
			MY_CONTACTS_LIST[cid].name		=	$('#CONTACT_'+cid+'_INPUT_NAME').val();
			MY_CONTACTS_LIST[cid].pseudo	=	$('#CONTACT_'+cid+'_INPUT_PSEUDO').val();
			MY_CONTACTS_LIST[cid].address	=	$('#CONTACT_'+cid+'_INPUT_ADDRESS').val();
			MY_CONTACTS_LIST[cid].picture	=	"./img/logo_400.jpeg";
			
			// Update local
			chrome.storage.local.set({CONTACTS_LIST: MY_CONTACTS_LIST});
			
			// UI update
			$('.confContact_'+cid+'').attr('address', MY_CONTACTS_LIST[cid].address);
			$('#CONF_CONTACT_'+cid+'_NAME').html(''+MY_CONTACTS_LIST[cid].name+' |');
			$('#CONF_CONTACT_'+cid+'_PSEUDO').html(MY_CONTACTS_LIST[cid].pseudo);
			$('#CONF_CONTACT_'+cid+'_ADDRESS').html('<b>'+(MY_CONTACTS_LIST[cid].address).substring(0,7)+'</b><span style="font-size:11px;opacity:0.7;">'+(MY_CONTACTS_LIST[cid].address).substring(7,37)+'</span><b>'+(MY_CONTACTS_LIST[cid].address).substring(37,42)+'</b>');
			
			// UI reload
			
			$('#POPUP_DIV_CONTACT_LIST').css('opacity', '0.2');
			$('#POPUP_DIV_CONTACT_LIST_LOADING').show('puff');
			
			setTimeout(() => { 
				$('#POPUP_DIV_CONTACT_LIST').css('opacity', '1');
				$('#POPUP_DIV_CONTACT_LIST_LOADING').hide();
				$('#EDIT_CONTACT_ID_'+cid+'').hide();
				$('#VIEW_CONTACT_ID_'+cid+'').fadeIn();
				$('#ICON_EDIT_CONTACT_ID_'+cid+'').fadeIn();
				$('#ICON_VALID_CONTACT_ID_'+cid+'').hide();
			}, 1250);
			
			
		break;
		
		case "DELETE":
			
			delete MY_CONTACTS_LIST[cid];
			
			// Update local
			chrome.storage.local.set({CONTACTS_LIST: MY_CONTACTS_LIST});
			
			
			// UI update
			$('#TR_CONTENT_CONTACT_'+cid+'').fadeOut({ 
				complete: function() {
					$('#TR_TOP_CONTACT_'+cid+'').remove();
					$('#TR_CONTENT_CONTACT_'+cid+'').remove();
				}
			});
			
			
			
		
		break;
	};
}


/**
	description		Load transaction history by index
**/
async function loadHistory(index) {
	console.log('[loadHistory] Start loading history from memory');
	let today 		=	new Date(Date.now()).toString();
	let today_txt	=	today.split("2023")[0];
	let last_day	=	"";
	let TX_HISTORY;
	try {
		TX_HISTORY	=	sortJsonDescending(REUNIT_TX_HISTORY[index]);
	} catch(e) {
		TX_HISTORY	=	{};
	}
	
	try {
		if(REUNIT_TX_HISTORY[index] === undefined) {
			let no_history	=	`<div class="empty_history" style="font-family: 'Open Sans', sans-serif; margin-top: 30px; border-radius: 30px; font-size: 14px; padding: 2%; background-color: #0d1d31;color:white; width: 80%; margin-left: 8%;">
				<center>${LANG_HOME.LG27}</center>
				</div>
				<div style="padding: 2%; width: 80%; margin-left: 8%; font-size: 13px;font-family: 'Open Sans', sans-serif;">
				<br/>
				${LANG_HOME.LG28}
				<br/><br/>
				${LANG_HOME.LG29} <a style="text-decoration:underline;color:black;cursor:pointer;" href="https://debank.com/profile/${REUNIT_PUBKEY}/history" style="font-weight:bold;" target="_blank">${LANG_HOME.LG30}</a>
				</div>
			</div>`;
			$('#TABLE_HISTORY_'+index).prepend(no_history);
		} else {
			for(txs in TX_HISTORY) {
				let tx			=	REUNIT_TX_HISTORY[index][txs];
				let txChainData	=	chainsData(tx['destination_chain']);
				let view_tx		=	0;
				
				CHAINS.forEach(function (check) {
					let checkData	=	chainsData(check);
					if(txChainData.stargateChainID == checkData.stargateChainID) {
						view_tx = 1;
					} 
				});
				
				if(view_tx == 1) {
				let reunitTXID	=	txs;
				let recipient	=	tx.recipient;
				let from		=	tx.from;
				let type		=	recipient.toLowerCase() == REUNIT_PUBKEY.toLowerCase() ? "received" : "sent";
				let amount		=	tx.total_amount;
				
				let trx_date	=	new Date(Number(reunitTXID)).toString();
								
				let trx_d_txt	=	trx_date.split("2023")[0];
				let shox_date;
				
				switch(trx_d_txt) {
					case today_txt:	
						show_date	=	LANG_HOME.LG46;
						break;
					default:
						show_date	=	trx_d_txt;	
				}
				
				
				if(last_day	!= show_date) {
					$('#TABLE_HISTORY_'+index).append('<br/><span style="color: black; margin-left: 58px; font-family: \'Open Sans\',sans-serif; font-size: 14px; font-weight: bold;\">'+show_date+'</span>');
					last_day	=	show_date;
				} else { }
				
				let icon;
				let title;
				let type_txt;
				let amount_txt;
				let addr;
				
				switch(type) {
					case "received":
						icon		=	`<div style="border-radius: 100px;width:16px;padding:10px;text-align:center;background: #dcf1e1;">
									<i class="fa-light fa-arrow-down-left" style="color:#1f6b44;"></i>
									</div>`;
						amount_txt	=	'+'+amount;
						addr		=	from.substring(0,7)+'...'+from.substring(from.length-5,from.length);
						title		=	LANG_HOME.LG47;
						break;
					case "sent":
						icon		=	`<div style="border-radius: 100px;width:16px;padding:10px;text-align:center;background: #e6e6e9;">
									<i class="fa-light fa-arrow-up-right" style="color:#676b7b;"></i>
									</div>`;
						amount_txt	=	'-'+amount;
						addr		=	recipient.substring(0,7)+'...'+recipient.substring(recipient.length-5,recipient.length);
						title		=	LANG_HOME.LG48;
						break;
				}
	
				
				let content		=	`<table border="0" class="tableHistory" reunit_txid="${reunitTXID}" style="padding:5px;border-radius:10px;margin-top:10px;cursor:pointer;">
									<tr>
									<td>${icon}
									</td>
				
									<td valign="top" style="width:160px;padding-left:10px;font-family:'Open Sans'">
										<span style="color:black;font-size:13px;">
										<b class="topType" >${title}</b><br/>
										${addr.toLowerCase()}
										</span>
									</td>
				
									<td style="width:140px;text-align:right;font-family:'Open Sans';">
										<span class="topAmount" style="font-size:15px;color:black;font-weight:bold;">
										${amount_txt}
									</span>
									</td>
									</tr>
									</table>`;
									
				$('#TABLE_HISTORY_'+index).append(content);
				
				}
			}
			
			
		}
	} catch(e) {
		console.log('[loadHistory] Error :'+e);
	}
	
}
/**
	description		Load and show gas price in Gwei
**/
async function loadGasPrice(o) {

	let real_chainID	=	[1,56,43114,137,10,42161,250];
	let erc20_page		=	false;
	
	if(typeof(o) == "number") {
		real_chainID	=	[o];
		erc20_page		=	true;
	} else { }
	
	real_chainID.forEach(function(cid) {
		
		let chaindata	=	chainsData(cid);
		let blockchain	=	new Web3(chaindata.node+"&mode=normal");
		
		blockchain.eth.getGasPrice().then(async function(gasprice) {
		
			blockchain.eth.estimateGas({ from:"0x28c6c06298d514db089934071355e5743bf21d60", to: "0x28c6c06298d514db089934071355e5743bf21d60", value:0 }).then( async function(glresult) {
			
				try {
					let gwei_price		=	Math.round(Number(blockchain.utils.fromWei(''+gasprice+'', 'gwei'))*1000)/1000;
					
				
					let native_price	=	await getBinancePrice(chaindata.ticker);
					
					let usd_text		=	"";
					let usd_value		=	Number(((glresult*gasprice)/1e18)*native_price).toFixed(4);
					if(usd_value <= 0.01) {
						usd_text	=	"< $0.01";
					} else {
						usd_text	=	"$"+usd_value;
					}
					
					if(erc20_page) {
						$('#PSCT_GAS_GWEI').html(''+gwei_price+' gwei');
						$('#PSCT_GAS_USD').html(''+usd_text+'');
					} else {
						$('#td_'+cid+'_gas_price').html(''+gwei_price+' gwei');
						$('#td_'+cid+'_usd_price').html(''+usd_text+'');
					}
				
				} catch(e) {
					$('#td_'+cid+'_gas_price').html('N/A gwei');
					$('#td_'+cid+'_usd_price').html('$ N/A');
				}
		
			});
		});
		
	});

}

/**
	description		View the page to send tokens
**/
async function viewSendCustomTokenPage(token, tokentype) {
	console.log('[viewSendCustomTokenPage]'+token+' : '+tokentype);
	CURRENT_PAGE			=	"PAGE_SEND_CUSTOM_TOKEN";
	$('#topHeader').css('background', '#0e1d30').css('height', '50px').css('border-bottom', '0px');
	$('#topHeader').animate({'height': '50px'});
	$('#topHeader').animate({'background': '#0e1d30'});
	$('body').animate({'background': 'linear-gradient(rgb(13, 29, 49), rgb(0, 0, 0))','background-color': 'linear-gradient(rgb(13, 29, 49), rgb(0, 0, 0))'},10);
	
	
	$('#PSCT_TOP_TESTNET').hide();
	$('#PSCT_TOP_MAINNET').hide();
	$('#topHeader_total').fadeOut();
	$('#PSCT_LOGO_TOKEN').css('filter', 'blur(2px)');
	$('#PSCT_LOGO_NETWORK').css('filter', 'blur(2px)');
			
	$('#PAGE_HOME').hide('slide', {"direction": "down"}, 500, async function() {
		

		$('#PAGE_SEND_CUSTOM_TOKEN').fadeIn();
		// UI RE-INIT

		$('#PSCT_TOP_SEND_CONFIRMATION').hide();
		$('#PSCT_TOP_LOAD_CONFIRMATION').hide();
		$('#PSCT_ERROR').hide();
		
		$('#PSCT_GAS_GWEI').html('<i class="fa-thin fa-spinner-third fa-spin"></i>');
		$('#PSCT_GAS_USD').html('<i class="fa-thin fa-spinner-third fa-spin"></i>');
		
		

		$('#PSCT_TOP').css('opacity', '1');
		$('#PSCT_CONFIRMATION_FEES').html('');
		$('#PSCT_LOGO_CIRCLE').css('opacity', 0);

		$('#PSCT_LOGO_NETWORK_CONFIRM').css('margin-left', '0px').css('opacity', '0');
		$('#PSCT_LOGO_TOKEN_CONFIRM').css('margin-left', '0px').css('opacity', '0');
		$('#ERC20_SUM_1').css('opacity', '0');
		$('#ERC20_SUM_2').css('opacity', '0');
		$('#ERC20_SUM_3').css('opacity', '0');
		$('#ERC20_SUM_4').css('opacity', '0');
		$('#PSCT_BAR').css('height', '1px');


		
		try { 
			$('#PSCT_SLIDER').slider("destroy");
		} catch(e) { }
		
		$('#PSCT_AMOUNT').val('');
		$('#PSCT_RECIPIENT').val('');
		
		// TOKEN
		let erc20_token;
		let erc20_ttl;
		let erc20_data;
		let erc20_web3;
		
		if(tokentype == "ERC20") {
			erc20_token	=	MY_TOKENS_LIST[token];
			erc20_ttl	=	new Big(erc20_token.balance).div(new Big(10).pow(erc20_token.decimals));
		} 
		else {
			let ethTokenByChain	=	[1,42161,10,5];
			let imgToken;
			if(ethTokenByChain.includes(Number(token.split('_')[0]))) {
				imgToken	=	1;
			} else {
				imgToken	=	Number(token.split('_')[0]);
			}
			erc20_data	=	chainsData(Number(token.split('_')[0]));
			erc20_token	=	{
								"chainId": Number(token.split('_')[0]),
								"decimals": 18,
								"logoURI": "./img/"+imgToken+".svg",
								"name": erc20_data.name,
								"symbol": erc20_data.nativeToken,
								"balance": 0,
								"address": "NATIVE_TOKEN"
							};
							
			erc20_web3				=	new Web3(erc20_data.node+"&mode=normal");
			erc20_total				=	await erc20_web3.eth.getBalance(REUNIT_PUBKEY);
			
			erc20_token['balance']	=	erc20_web3.utils.fromWei(''+erc20_total+'');
			erc20_ttl				=	erc20_web3.utils.fromWei(''+erc20_total+'');
		}
		
		// Show GAS PRICE
		loadGasPrice(erc20_token.chainId);
		
		// UI VALUE
		$('#PSCT_INPUT_TOKEN').val(erc20_token.address);
		$('#PSCT_INPUT_CHAINID').val(erc20_token.chainId);
		
		// TESTNET ?
		let chainInfo		=	chainsData(erc20_token.chainId);
		if(chainInfo.testnet == true) {
			$('#PSCT_TOP_TESTNET').show();
			$('#PSCT_TOP_MAINNET').hide();
		} else {
			$('#PSCT_TOP_TESTNET').hide();
			$('#PSCT_TOP_MAINNET').hide();
			if(REUNIT_CONFIG.network == "testnet" && erc20_token['network'] != "testnet") {
				$('#PSCT_TOP_MAINNET').show();
			}
		}
		
		// UI
		$('#PSCT_LOGO_TOKEN').attr('src', ''+erc20_token.logoURI+'');
		$('#PSCT_LOGO_NETWORK').attr('src', './img/'+erc20_token.chainId+'.svg');
		
		$('#PSCT_LOGO_TOKEN_CONFIRM').attr('src', ''+erc20_token.logoURI+'');
		$('#PSCT_LOGO_NETWORK_CONFIRM').attr('src', './img/'+erc20_token.chainId+'.svg');
		
		
		$('#PSCT_AMOUNT_LOGO').attr('src', ''+erc20_token.logoURI+'');
		
		$('#PSCT_TOTAL_BALANCE').html(erc20_ttl.toString());
		$('#PSCT_TOP_NAME').html(erc20_token.symbol.toUpperCase());
		
		
		let usd_val_erc20;
		try {
			usd_val_erc20	=	Big(erc20_token.balance).div(Big(10**erc20_token.decimals)).mul(erc20_token.usd_price);
			$('#PSCT_TOP_USD_VALUE').show();
			$('#PSCT_TOP_USD_VALUE').text('1 '+erc20_token.symbol.toUpperCase()+' = $'+Intl.NumberFormat('en-US', {}).format(erc20_token.usd_price.toString()));
		} catch(e) {
			$('#PSCT_TOP_USD_VALUE').hide();
		}
		
		
		if(tokentype == "NATIVE") {
			$('#PSCT_TOP_USD_VALUE').show();
			$('#PSCT_TOP_USD_VALUE').text('1 '+erc20_token.symbol.toUpperCase()+' = $'+Intl.NumberFormat('en-US', {}).format(getNativePrice(erc20_token.chainId)));
		
		}
		
		$('#PSCT_AMOUNT').attr('current_balance', erc20_ttl);
		
		$("#PSCT_SLIDER").slider({
			orientation: "horizontal",range:"min",value:0,min: 0,max: 100,step: 1,
			classes: {
				"ui-slider-range": "erc-slider-range",
			},
			slide: function( event, ui ) {
				let pct_amount	=	new Big(""+erc20_ttl+"").div(100).mul(ui.value).toFixed(erc20_token.decimals);
      			$('#PSCT_AMOUNT').val(pct_amount);
      		}
      	});
      	
      	$('#PSCT_LOGO_TOKEN').css('filter', 'blur(0px)');
		$('#PSCT_LOGO_NETWORK').css('filter', 'blur(0px)');
      	
      	$('#PSCT_AMOUNT').keyup(function() {
      		let newVal;
      		if($(this).val() == undefined || $(this).val() == '' || $(this).val() == null) {
      			newVal	= new Big(0);
      		} else {
      			newVal	= new Big($(this).val());
      		}
      		let total_balance			=	new Big($('#PSCT_AMOUNT').attr('current_balance'));
      		let amount_slider			=	newVal.mul(100).div(total_balance).toFixed(2);
    		$('#PSCT_SLIDER').slider("value", amount_slider);
		});
		
      	$('#BTN_PSCT_TRANSFER').unbind('click');
      	$('#BTN_PSCT_TRANSFER').click(function() { checkCustomTransfer(); } );
      				
		
	});
}

/**
	description		Check before send ERC20 Transfer
	TO-DO			If native
**/
async function checkCustomTransfer(step,p) {
	console.log('%c[checkCustomTransfer] Start UI verification', 'background-color:#22bcce;color:white;');
	let c_address		=	$('#PSCT_RECIPIENT').val();
	let c_amount;
	if($('#PSCT_AMOUNT').val() == undefined || $('#PSCT_AMOUNT').val() == null || $('#PSCT_AMOUNT').val() == 0) {
		c_amount		=	new Big(0);
	} else { 
		c_amount		=	new Big($('#PSCT_AMOUNT').val());
	}

	let c_token			=	$('#PSCT_INPUT_TOKEN').val();
	let c_chainID		=	Number($('#PSCT_INPUT_CHAINID').val());
	let c_balance		=	new Big($('#PSCT_AMOUNT').attr('current_balance'));
	
	// UI (re)init
	$('#PSCT_CONFIRMATION_AMOUNT_TOKEN').html('');
	$('#PSCT_CONFIRMATION_RECIPIENT').html('');
	$('#PSCT_CONFIRMATION_TXHASH').html('');

	// 1 - Check Token
	if(!checkAddress(c_token) && c_token != "NATIVE_TOKEN") {
		$('#PSCT_ERROR').html('<b>ERROR</b><br/>The token address is not valid.<br/>');
		$('#PSCT_ERROR').fadeIn();
		console.log('%c[checkCustomTransfer] Invalid token address', 'background-color:red;color:white;');
	} 
	
	// 2 - Check address
	else if(!checkAddress(c_address)) {
		$('#PSCT_TOP_TABLE_RECIPIENT').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
		console.log('%c[checkCustomTransfer] Invalid recipient address', 'background-color:red;color:white;');
	}
	
	
	
	
	// 3 - Check chainID
	else if(!CHAINS.includes(c_chainID)) {
		$('#PSCT_ERROR').html('<b>ERROR</b><br/>Switch to mainnet <br/>');
		$('#PSCT_ERROR').fadeIn();
		console.log('%c[checkCustomTransfer] Chain ID ( blockchain ) not supported yet', 'background-color:red;color:white;');
	}
	
	
	// 4 - Check amount <= 0
	else if(c_amount.lte(0)) {
		$('#PSCT_AMOUNT_TABLE').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
		console.log('%c[checkCustomTransfer] Amount lower or equal to zero ', 'background-color:red;color:white;');
	}
	
	// 5 - Amount >= balance 
	else if(c_amount.gt(c_balance)) {
		$('#PSCT_AMOUNT_TABLE').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
		console.log('%c[checkCustomTransfer] Amount higher than balance ', 'background-color:red;color:white;');
	}
	
	// 6 - Popupsign() -> Check amount / node / fees -> send
	else { 
		if(step != 2) {
			console.log('%c[checkCustomTransfer] Waiting signature', 'background-color:#22bcce;color:white;');
			popupSign($('#PSCT_TOP_NAME').text(),"CUSTOM_ERC20_TRANSFER",c_chainID);
		
		} else {
			console.log('%c[checkCustomTransfer] Start node checks before sending the transfer', 'background-color:#22bcce;color:white;');
		
			// UI
			let current_date			=	new Date();
			let full_date				=	current_date.getDate()+"/"+Number(current_date.getMonth()+1)+"/"+current_date.getFullYear();
			full_date					=	full_date+' '+current_date.getHours()+':'+current_date.getMinutes();
			$('#PSCT_CONFIRMATION_DATE').html(full_date);
			
			let token_data;
			let chainData;
			let web3;
			let contract;
			
			if(c_token != "NATIVE_TOKEN") {
				token_data				=	MY_TOKENS_LIST[""+c_token.toLowerCase()+"_"+c_chainID];
				chainData				=	chainsData(c_chainID);
				web3					=	new Web3(chainData.node+"&mode=normal");
				contract				=	new web3.eth.Contract(ERC20_ABI, c_token);
			} else {
				chainData	=	chainsData(c_chainID);
				token_data	=	{
								"chainId": Number(c_chainID),
								"decimals": 18,
								"logoURI": "./img/"+Number(c_chainID)+".svg",
								"name": chainData.name,
								"symbol": chainData.nativeToken,
								"address": "NATIVE_TOKEN"
								};
				web3		=	new Web3(chainData.node+"&mode=normal");
			}
			
			let realChainID				=	chainData.realChainID;
			web3.eth.defaultAccount		=	REUNIT_PUBKEY;
		
			if(c_token != "NATIVE_TOKEN") {
				await web3.eth.getGasPrice().then(async function(gasresult) {
			
					let real_amount	=	c_amount.mul(new Big(10).pow(token_data.decimals)).toFixed(0).toString();
					let encode_data	=	web3.eth.abi.encodeFunctionCall(ERC20_TRANSFER_ABI,[c_address,''+real_amount+'']);
			
					await web3.eth.estimateGas({ from:REUNIT_PUBKEY, to: c_token, data: encode_data }).then( async function(gaslimitresult) {
			
						let tx_gasLimit		=	new Big(gaslimitresult);	
						let tx_realGasLimit	=	tx_gasLimit.add(tx_gasLimit.div(100).mul(10)).toFixed(0);					
						let tx_gasPrice		=	new Big(gasresult);
						let tx_realGasPrice	=	tx_gasPrice.add(tx_gasPrice.div(100).mul(REUNIT_CONFIG.gas_speed)).toFixed(0);
				
				
						await web3.eth.getTransactionCount(REUNIT_PUBKEY).then(async function(txCount) {
				
							let txObject 	= { nonce:    web3.utils.toHex(txCount),
    				 							to:       c_token,
    				 							gasLimit: web3.utils.toHex(tx_realGasLimit),
    				 							gasPrice: web3.utils.toHex(tx_realGasPrice),
    				 							data: encode_data,
    				 							value: 0,chainId:realChainID,networkId:realChainID
    				 				  			};
    				 				  
    				 
    				 		$('#PSCT_CONFIRMATION_FEES').html(web3.utils.fromWei(''+tx_realGasLimit*tx_realGasPrice+''));				  
    				 				  
    						await web3.eth.getBalance(REUNIT_PUBKEY).then(async function(resultBalance) {
								
								let currentBalance	=	new Big(resultBalance);
								if(currentBalance.gte(Big(tx_realGasLimit).mul(Big(tx_realGasPrice)))) {
						
									$('#unlockToSend_check_gas_logo').html('<i style="font-size:16px;" class="green fa-check fa-regular"></i>');
 									$('#unlockToSend_sending').css('opacity', 1);
 									$('#unlockToSend_sending_logo').html('<i class="fa fa-spinner-third fa-spin"></i>');
 							
									let dKey		=	await decodeKey(atob(p));
									let signedTX	=	await web3.eth.accounts.signTransaction(txObject, dKey.privKey);
							 
									CURRENT_PAGE	=	"PAGE_SEND_ERC20_CONFIRMED"; 
							 
							 
 									// Add to history
    				 				let txInfo	=	{	"status": "pending", 
														"amount": c_amount.toString(), 
														"gasPrice": tx_realGasPrice,
														"gasLimit": tx_realGasLimit,
														"nonce": txCount,
														"timestamp": Date.now(),
														"type": "erc20_transfer",
														"tokenAddress": token_data.address,
														"tokenDecimals": token_data.decimals,
														"tokenDecNumber": token_data.decimals,
														"hash": signedTX.transactionHash,
														"txObject": txObject };
							
									let reunitTxID	=	Date.now();	
    				 				addTxToHistory("ERC20_"+c_chainID+"_"+token_data.address.toLowerCase()+"",
    				 								reunitTxID,REUNIT_PUBKEY,c_address,Date.now(),
    				 								c_amount.toString(),0,token_data.symbol,c_chainID,c_chainID,"erc20_transfer",txInfo);
    				 			
									$('#PSCT_CONFIRMATION_NUMBER').html('<i class="fa-solid fa-spinner-third fa-spin"></i>');
							 
									$('#PSCT_CONFIRMATION_AMOUNT_TOKEN').html($('#PSCT_AMOUNT').val()+' '+$('#PSCT_TOP_NAME').html());
									$('#PSCT_CONFIRMATION_TXHASH').html(signedTX.transactionHash);
							 
							 
									setTimeout(() => { UIConfirmCustomSend(); }, 500);
							 		console.log('[checkCustomTransfer] Transaction sent, waiting confirmation');
							 		
							 		web3.eth.sendSignedTransaction(signedTX.rawTransaction).once('transactionHash', async function(txHash){
										$('#PSCT_CONFIRMATION_NUMBER').html(LANG_SEND.LG86);
										console.log('%c[checkCustomTransfer] Transaction confirmed', 'background-color:green;color:white;');
									});
								} else {
									$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
							
									setTimeout(() => { 
										$('#bgPopup').fadeOut(500, function() {
											$('#PSCT_ERROR').html('<b>ERROR</b><br/>You don\'t have enough native to pay the transaction fees.<br/>');
											$('#PSCT_ERROR').fadeIn();
										});
									},500);
								}
							});
    				 				  			
				
				});
				
				
					}).catch( function(e) {
						$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
				
						setTimeout(() => { 
							$('#bgPopup').fadeOut(500, function() {
								$('#PSCT_ERROR').html('<b>ERROR</b><br/>'+e+'.<br/>');
								$('#PSCT_ERROR').fadeIn();
							});
						},500);
							
					});
			
				});
			} else {
				/**
				
						Send Native Token
				
				**/
				await web3.eth.getGasPrice().then(async function(gasresult) {
					
					let real_amount	=	c_amount.mul(new Big(10).pow(token_data.decimals)).toFixed(0).toString();
					
					await web3.eth.estimateGas({ from:REUNIT_PUBKEY, to:c_address,	value: real_amount}).then(async function(gaslimitresult) {
						
						let tx_gasLimit		=	new Big(gaslimitresult);	
						let tx_realGasLimit	=	tx_gasLimit.add(tx_gasLimit.div(100).mul(10)).toFixed(0);					
						let tx_gasPrice		=	new Big(gasresult);
						let tx_realGasPrice	=	tx_gasPrice.add(tx_gasPrice.div(100).mul(REUNIT_CONFIG.gas_speed)).toFixed(0);
						
						await web3.eth.getTransactionCount(REUNIT_PUBKEY).then( async function(txCount) {
						
							let txObject 	= { nonce:    web3.utils.toHex(txCount),
    				 							to:       c_address,
    				 							gasLimit: web3.utils.toHex(tx_realGasLimit),
    				 							gasPrice: web3.utils.toHex(tx_realGasPrice),
    				 							value: real_amount,
    				 							chainId:realChainID,networkId:realChainID
    				 				  			};
    				 		
    				 		$('#PSCT_CONFIRMATION_FEES').html(web3.utils.fromWei(''+Big(tx_realGasLimit).mul(Big(tx_realGasPrice))+''));
    				 		
    				 		
    				 		await web3.eth.getBalance(REUNIT_PUBKEY).then(async function(resultBalance) {
								
								let currentBalance	=	new Big(resultBalance);
								if(currentBalance.gte(Big(real_amount).add(Big(tx_realGasLimit).mul(tx_realGasPrice)))) {
								
									$('#unlockToSend_check_gas_logo').html('<i style="font-size:16px;" class="green fa-check fa-regular"></i>');
 									$('#unlockToSend_sending').css('opacity', 1);
 									$('#unlockToSend_sending_logo').html('<i class="fa fa-spinner-third fa-spin"></i>');
 							
									let dKey		=	await decodeKey(atob(p));
									let signedTX	=	await web3.eth.accounts.signTransaction(txObject, dKey.privKey);
							 
									CURRENT_PAGE	=	"PAGE_SEND_ERC20_CONFIRMED"; 
							 
							 
 									// Add to history
    				 				let txInfo	=	{	"status": "pending", 
														"amount": c_amount.toString(), 
														"gasPrice": tx_realGasPrice,
														"gasLimit": tx_realGasLimit,
														"nonce": txCount,
														"timestamp": Date.now(),
														"type": "NATIVE_transfer",
														"tokenDecimals": token_data.decimals,
														"tokenDecNumber": token_data.decimals,
														"hash": signedTX.transactionHash,
														"txObject": txObject };
							
									let reunitTxID	=	Date.now();	
    				 				addTxToHistory("NATIVE_"+c_chainID+"_"+token_data.symbol.toLowerCase()+"",
    				 								reunitTxID,REUNIT_PUBKEY,c_address,Date.now(),
    				 								c_amount.toString(),0,token_data.symbol,c_chainID,c_chainID,"NATIVE_transfer",txInfo);
    				 			
									$('#PSCT_CONFIRMATION_NUMBER').html('<i class="fa-solid fa-spinner-third fa-spin"></i>');
							 		
							 		
							 		
									$('#PSCT_CONFIRMATION_AMOUNT_TOKEN').html($('#PSCT_AMOUNT').val()+' '+$('#PSCT_TOP_NAME').html());
									$('#PSCT_CONFIRMATION_TXHASH').html(signedTX.transactionHash);
							 
							 
									setTimeout(() => { UIConfirmCustomSend(); }, 500);
							 		console.log('[checkCustomTransfer] Transaction sent, waiting confirmation');
							 		
							 		web3.eth.sendSignedTransaction(signedTX.rawTransaction).on('transactionHash', async function(txHash){
										$('#PSCT_CONFIRMATION_NUMBER').html('Confirmed');
										console.log('%c[checkCustomTransfer] Transaction confirmed', 'background-color:green;color:white;');
									});
									
								
								} else {
								
									$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
							
									setTimeout(() => { 
										$('#bgPopup').fadeOut(500, function() {
											$('#PSCT_ERROR').html('<b>ERROR</b><br/>You don\'t have enough native to pay the transaction fees.<br/>');
											$('#PSCT_ERROR').fadeIn();
										});
									},500);
									
								}
							});	
						
						});
					
					}).catch( function(e) {
					
						$('#unlockToSend_check_gas_logo').html('<i class="fa fa-x" style=" color: #f9a8a8; font-size: 13px; "></i>');
				
						setTimeout(() => { 
							$('#bgPopup').fadeOut(500, function() {
								$('#PSCT_ERROR').html('<b>ERROR</b><br/>'+e+'.<br/>');
								$('#PSCT_ERROR').fadeIn();
							});
						},500);
						
					});
				
				});
			}
		
		}
	}
}


/**
	description		Load and view settings
**/
async function loadUISettings() {
	
	
	$("#SLIDER_SETTINGS_TX_SPEED").slider({
			orientation: "horizontal",
			range: "min",max:40,min:10,step:10,value:REUNIT_CONFIG.gas_speed,
			classes: {
				"ui-slider-handle": "settings-slider-handle",
				"ui-slider-range": "settings-slider-range",
				"ui-widget-content": "settings-widget",
				"ui-widget": "settings-widget"
  			},
			slide: function( event, ui ) { 
				
				switch(ui.value) {
					case 10:
					$('#settings_text_speed').html(LANG_HOME.LG36+' +10%');
					break;
					case 20:
					$('#settings_text_speed').html(LANG_HOME.LG37+' +20%');
					break;
					case 30:
					$('#settings_text_speed').html(LANG_HOME.LG38+' +30%');
					break;
					case 40:
					$('#settings_text_speed').html(LANG_HOME.LG39+' +40%');
					break; 
				}
				
				
				REUNIT_CONFIG.gas_speed	=	Number(ui.value);
			}
    });


	$("#SLIDER_SETTINGS_LOCK_TIME").slider({
			orientation: "horizontal",
			range: "min",max:600,min:10,value:REUNIT_CONFIG.locktime,
			classes: {
				"ui-slider-handle": "settings-slider-handle",
				"ui-slider-range": "settings-slider-range",
				"ui-widget-content": "settings-widget",
				"ui-widget": "settings-widget"
  			},
			slide: function( event, ui ) {
				$('#settings_text_locktime').html(''+ui.value+' '+LANG_HOME.LG41);
				REUNIT_CONFIG.locktime	=	Number(ui.value);
			}
      });
      
      
      $('#CURRENT_NETWORK_OPTION').text(REUNIT_CONFIG.network.toUpperCase());
}


/**
	description		Add transaction to history
**/
function addTxToHistory(index,reunitTxID,from,recipient,timestamp,total,totalUsd,tokenName,destination_chain,chainID,type,txInfos) {
	
	if(!REUNIT_TX_HISTORY.hasOwnProperty(index)) {  REUNIT_TX_HISTORY[index] = 	{};  } else { }
	
	if(!REUNIT_TX_HISTORY[index].hasOwnProperty(reunitTxID)) {
		REUNIT_TX_HISTORY[index][reunitTxID]						=	{};
		REUNIT_TX_HISTORY[index][reunitTxID]["from"] 				= 	from;
		REUNIT_TX_HISTORY[index][reunitTxID]["recipient"]			=	recipient;
		REUNIT_TX_HISTORY[index][reunitTxID]["timestamp"]			=	timestamp;
		REUNIT_TX_HISTORY[index][reunitTxID]["total_amount"]		=	total;
		REUNIT_TX_HISTORY[index][reunitTxID]["type"]				=	type;
		REUNIT_TX_HISTORY[index][reunitTxID]["token_name"]			=	tokenName;
		REUNIT_TX_HISTORY[index][reunitTxID]["destination_chain"]	= 	destination_chain;
		REUNIT_TX_HISTORY[index][reunitTxID]["txs_info"]			=	{}; 
	} else { } 
	

	REUNIT_TX_HISTORY[index][reunitTxID]["txs_info"][chainID] = txInfos;
	
	chrome.storage.local.set({REUNIT_HISTORY: REUNIT_TX_HISTORY});
	console.log('%c[addTxToHistory] Transaction '+reunitTxID+' added to history', 'background-color:purple;color:white;');
}


/**
	description		Load tx history
**/
function loadTxHistory(index,reunitTxID) {
	try {
		console.log('%c[loadTxHistory] Transaction summary loaded', 'background-color:#22bcce;color:white;');
		
		let transaction	=	REUNIT_TX_HISTORY[index][reunitTxID];

		let txtype;
		let web3		=	new Web3();
		let txSign		=	(transaction["from"].toLowerCase() == REUNIT_PUBKEY.toLowerCase() && transaction["recipient"].toLowerCase() != REUNIT_PUBKEY.toLowerCase()) ? "-" : "+";
		let txDate		=	new Date(transaction["timestamp"]).toString().split(':');
		let txDateTXT	=	txDate[0]+':'+txDate[1]+':'+txDate[2].substr(0,2);
		
		switch(transaction["type"]) {
			case "erc20_transfer":		txtype = "ERC20 transfer";		break;
			case "crosschain":			txtype = "Crosschain transfer";	break;
			default:					txtype = "Native transfer";		break;
		}
		
		
		
		$('#TX_HISTORY_WRAPPER').html('');
		$('#txHistoryChainIcon').html('');
		
		$('#detailHistoryDate').text(txDateTXT);
		
		//
		let totalAmount	=	transaction["total_amount"];
		
		$('#detailHistoryAmount').text(txSign+''+transaction["total_amount"]+' '+transaction["token_name"].toUpperCase()+'');
		
		
		$('#POPUP_TXHISTORY_ID').text(reunitTxID);
		$('#POPUP_TXHISTORY_RECIPIENT').text(transaction["recipient"]);
		$('#POPUP_TXHISTORY_TYPE').text(txtype);
		
		$('#POPUP_TXHISTORY_BOTTOM_DEST').attr('src', './img/'+transaction["destination_chain"]+'.svg');
		
		let txu	=	1;
		for(txChainID in transaction["txs_info"]) {
			let txinfo		=	transaction["txs_info"][txChainID];
			
			let cssmargin	=	(txu == 1) ? "": "margin-left:-15px;";
			
			$('#txHistoryChainIcon').append('<img class="fa-spin" src="./img/'+txChainID+'.svg" style="'+cssmargin+'background-color:white;cursor:pointer;z-index:33;position:relative;width:20px;height:20px;border:2px solid white;border-radius:100px;">');
			
			txu = 2;
			
			txContent = `<table border="0" style="position:relative;width:100%;font-family:'Open Sans',sans-serif;color:black;font-size:13px;">
				<tr>
				<td valign="top" style="width:40px;">
				<img src="./img/${txChainID}.svg" style="background-color:white;cursor:pointer;z-index:33;position:relative;width:25px;height:25px;border:2px solid white;border-radius:100px;">
				</td>
				<td style="padding-left:10px;background-color:#f7f7fb;">
					<div style="position:absolute;margin-left: -16px;margin-top:5px;font-size: 20px;color: #f7f7fb;">
						<i class="fa fa-caret-left"></i>
					</div>
					
					
					<table border="0" style="font-family:'Open Sans',sans-serif;color:black;font-size:13px;">
						
						<tr>
							<td style="font-weight:bold;">amount</td>
							<td style="padding-left:5px;">
							${txinfo.amount}
							</td>
						</tr>
						<tr>
							<td valign="top" style="font-weight:bold;">hash</td>
							<td style="padding-left:5px;">
								<div style="overflow-wrap: break-word;width:250px;">
								${txinfo.hash}
								</div>
							</td>
						</tr>
						<tr>
							<td style="font-weight:bold;">gas used</td>
							<td style="padding-left:5px;">
							${txinfo.gasLimit}
							</td>
						</tr>
						<tr>
							<td style="font-weight:bold;">gas price</td>
							<td style="padding-left:5px;">
							${web3.utils.fromWei(txinfo.gasPrice)}
							</td>
						</tr>
						<tr>
							<td style="font-weight:bold;">fee paid</td>
							<td style="padding-left:5px;">
							${ Number(web3.utils.fromWei(txinfo.gasPrice))*Number(txinfo.gasLimit)   }
							</td>
						</tr>
						<tr>
							<td style="font-weight:bold;">status</td>
							<td id="${txinfo.hash}_status" style="padding-left:5px;">
							${txinfo.status}
							</td>
						</tr>
					</table>
					
				</td>
			</tr>
			</table>
		
			<br/>`;
			
			$('#TX_HISTORY_WRAPPER').append(txContent);
			
			// Verify transactionreceipt
			if(txinfo.status != "confirmed" && txinfo.status != "Rejected") {
				let txChainData	=	chainsData(Number(txChainID));
				let txweb3		=	new Web3(txChainData.node+"&mode=normal");
				
				txweb3.eth.getTransactionReceipt(txinfo.hash).then(function (txData) {
					try {
					txStatus	=	txData[0].status;
					if(txStatus == true) {
					$('#'+txinfo.hash+'_status').html('<i class="fa fa-circle-check" style="color:#0e6f0e;"></i> <span style="color:#0e6f0e;">confirmed</span>');
					
					REUNIT_TX_HISTORY[index][reunitTxID]["txs_info"][txChainID].status	=	'confirmed';
					// Update 
					chrome.storage.local.set({REUNIT_HISTORY: REUNIT_TX_HISTORY});
					} else { }
					
					} catch(e) { } 
				});
			} else {
				
				$('#'+txinfo.hash+'_status').html('<i class="fa fa-circle-check" style="color:#0e6f0e;"></i> <span style="color:#0e6f0e;">'+txinfo.status+'</span>');
			}
			
		}
	
	} catch(e) {
	
	}
}

/**
	description		Import a wallet from welcome page
**/
async function walletImport() {
	let priv		=	$('#HOME_IMPORT_privKeyInput').val();
	let pass		=	$('#HOME_IMPORT_ACCOUNT_PASS').val();
	let passConfirm	=	$('#HOME_IMPORT_ACCOUNT_PASS_CONFIRM').val();
	
	let wallet		=	new Web3();
	
	try {
		
		if(pass == passConfirm && pass.length >= 8) {
			let keyData			=	wallet.eth.accounts.privateKeyToAccount(priv);			
			let REUNIT_JSON		=	{"pubKey": keyData.address, "privKey": keyData.privateKey, "name": "My wallet"};
			
			let current_date	=	new Date;
			
			let REUNIT_ENCODED	=	await encodeWallet(REUNIT_JSON,pass);
			
			let REUNIT_INIT_HISTORY		=	{};
			let REUNIT_INIT_SETTINGS	=	{
										"lang": "EN",
										"currency": "USD",
										"secureRPC": 1,
										"network": "mainnet",
										"notifications": { },
										"gas_speed": 20,
										"locktime": 60,
										"last_lockout": Math.ceil(current_date.getTime()/1000) };
									
			$('#TIW_logo_two').css('color', '#acf3a6');
			$('#TIW_logo_three').css('color', '#acf3a6');
			$('#TIW_logo_three').removeClass('fa-lock-keyhole-open').addClass('fa-lock-keyhole');
			$('#TIW_logo_two').removeClass('fa-lock-keyhole-open').addClass('fa-lock-keyhole');
			

			chrome.storage.local.set({REUNIT_WALLET: REUNIT_ENCODED});
			chrome.storage.local.set({REUNIT_SETTINGS: REUNIT_INIT_SETTINGS});
			chrome.storage.local.set({REUNIT_HISTORY: REUNIT_INIT_HISTORY});
			chrome.storage.local.set({LIST_OF_TOKENS: {} });
			
			chrome.storage.session.set({REUNIT_PUBKEY: REUNIT_JSON.pubKey});
			
			REUNIT_PUBKEY	=	REUNIT_JSON.pubKey
			
			$('#PAGE_WELCOME_LOGO_LOADING').show();
			$('#PAGE_WELCOME_CHOICE_IMPORT').css('opacity', '0.3');
			
			
			setTimeout(() => { 
				location.reload();
			}, 1250);
			
		} else {
			$('#TIW_logo_three').css('color', '#ff6c6c');
			$('#TIW1').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
			$('#TIW2').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
		}
		
	} catch {
		$('#TIW_logo_one').css('color', '#ff6c6c');
		$('#TIW0').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
	}
}


/**
	description		Recover pub/priv from seed
**/
function recoverKeypairFromSeed(mnemonic, count) {  
  let seed 			= bip39.mnemonicToSeedSync(mnemonic);
  let hdwallet		= hdkey.fromMasterSeed(seed);
  let wallet_hdpath = "m/44'/60'/0'/0/";
  let accounts 		= [];
  
  for (let i = 0; i < count; i++) {
    let wallet		= hdwallet.derivePath(wallet_hdpath + i).getWallet();
    let address 	= "0x" + wallet.getAddress().toString("hex");
    let privateKey	= wallet.getPrivateKey().toString("hex");
    accounts.push({ address: address, privateKey: privateKey });
  }
  
  return accounts;
}

/**
	description		Import from seed phrase
**/
async function importFromSeedPhrase(s,step) {
	
	if(step == 1) {
		$('#IMPORT_SEED_SELECT_ADDRESS').html('');
		console.log(s);
		let keypairs	=	recoverKeypairFromSeed(s, 10);
		

		keypairs.forEach(function (k) {
			$('#IMPORT_SEED_SELECT_ADDRESS').append('<option value='+k.address+':'+k.privateKey+'>'+k.address+'</option> ');
		});

		$('#checkImportedSeed').unbind('click');
		$('#checkImportedSeed').click(async function() { importFromSeedPhrase(0,2); });
	} else {
	
		let sp	=	$('#IMPORT_SEED_PASS').val();
		let spc	=	$('#IMPORT_SEED_PASS_CONFIRM').val();
	
		if(sp == spc && sp.length >= 8) {
		
			
			$('#PAGE_WELCOME_LOGO_LOADING').show();
			$('#PAGE_WELCOME_IMPORT_SEED').css('opacity', '0.3');
			
			
			let pass			=	sp;
			let current_date	=	new Date;
			let kp				=	$('#IMPORT_SEED_SELECT_ADDRESS').val().split(':');
			let REUNIT_JSON		=	{"pubKey": kp[0], "privKey": kp[1], "name": "My wallet"};
			
			let REUNIT_ENCODED			=	await encodeWallet(REUNIT_JSON,pass);
			let REUNIT_INIT_HISTORY		=	{};
			let REUNIT_INIT_SETTINGS	=	{
										"lang": "EN",
										"currency": "USD",
										"secureRPC": 1,
										"network": "mainnet",
										"notifications": { },
										"gas_speed": 20,
										"locktime": 60,
										"last_lockout": Math.ceil(current_date.getTime()/1000),
										};
			
			
			chrome.storage.local.set({REUNIT_WALLET: REUNIT_ENCODED});
			chrome.storage.local.set({REUNIT_SETTINGS: REUNIT_INIT_SETTINGS});
			chrome.storage.local.set({REUNIT_HISTORY: REUNIT_INIT_HISTORY});
			chrome.storage.local.set({LIST_OF_TOKENS: {} });
			
			chrome.storage.session.set({REUNIT_PUBKEY: REUNIT_JSON.pubKey});
			
			REUNIT_PUBKEY	=	REUNIT_JSON.pubKey;
			
			setTimeout(() => { 
				$('body').css('background-color', 'white').css('background', 'white');
				$('#PAGE_WELCOME').fadeOut({
					complete: function() {
						CURRENT_PAGE	=	"PAGE_HOME";
						$('#topHeader').fadeIn();
						$('#PAGE_HOME').fadeIn({complete: function() { start('OK'); } });
					}
				});
				
				
			
			}, 1500);
			
			
		} else {
		
			$('#ICS_T1').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
			$('#ICS_T2').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
		}
	
	}

}

/**
	description		Generate new keypair + seed
**/

var seedwords 	= [];
var seedcomp	= [];
var seedpair	= [];
async function generateNewWallet(step) {

	if(step == 1) {
		bip39.setDefaultWordlist('english');
		let seed_phrase		=	bip39.generateMnemonic();
		let utf8_seed		=	UINT8ARRAY.toString(seed_phrase);
		let keyPair			=	recoverKeypairFromSeed(utf8_seed, 1);
		let pubkey			=	keyPair[0].address;
		let privkey			=	keyPair[0].privateKey;
		seedpair			=	[pubkey, privkey];
		
		// UI
		$('#PAGE_WELCOM_NEW_PUBKEY').html('<br/><b>'+LANG_WELCOME.LG4+'</b><br/><span style="font-size:13px;">'+pubkey+'</span>');
		console.log('[generateNewWallet] '+utf8_seed);
		console.log('[generateNewWallet] '+keyPair[0].address);
	
		let seed_array		=	utf8_seed.split(' ');
		seedwords			=	seed_array;
		let si				=	0;
		while(si <= 11) {
			$('#NEW_WALL_'+(si+1)+'').html(seed_array[si]);
			si++;
		}
	} else if(step == 2) {
		
		let word_one		=	Math.floor(Math.random() * (3 - 1 + 1) + 1);
		let word_two		=	Math.floor(Math.random() * (6 - 4 + 1) + 4);
		let word_three		=	Math.floor(Math.random() * (9 - 7 + 1) + 7);
		let word_four		=	Math.floor(Math.random() * (12 - 10 + 1) + 10);
		
		seedcomp			= [word_one, word_two, word_three, word_four];
		
		$('.tdCreateWallet').css('opacity', '0.4');
		$('.tdCreateWalletText').css('opacity', '0.4');
		
		$('.tdWall_'+word_one+'').css('opacity', '1');
		$('.tdWall_'+word_two+'').css('opacity', '1');
		$('.tdWall_'+word_three+'').css('opacity', '1');
		$('.tdWall_'+word_four+'').css('opacity', '1');
		
		$('#NEW_WALL_'+word_one+'').css('opacity', '1').html('<input id="NEW_WALL_INPUT_'+word_one+'" type="text" seedword_id="'+word_one+'" seedword="'+seedwords[word_one-1]+'" class="tdEmptySeed" />');
		$('#NEW_WALL_'+word_two+'').css('opacity', '1').html('<input id="NEW_WALL_INPUT_'+word_two+'" type="text" seedword_id="'+word_two+'" seedword="'+seedwords[word_two-1]+'" class="tdEmptySeed" />');
		$('#NEW_WALL_'+word_three+'').css('opacity', '1').html('<input id="NEW_WALL_INPUT_'+word_three+'" type="text" seedword_id="'+word_three+'" seedword="'+seedwords[word_three-1]+'" class="tdEmptySeed" />');
		$('#NEW_WALL_'+word_four+'').css('opacity', '1').html('<input id="NEW_WALL_INPUT_'+word_four+'" type="text" seedword_id="'+word_four+'" seedword="'+seedwords[word_four-1]+'" class="tdEmptySeed" />');
	
		$('#PAGE_WELCOME_CREATE_WALLET_SUB_TEXT').show();
		
		$('#checkUserSeed').unbind('click');
		$('#checkUserSeed').click(async function() { generateNewWallet(3); });

		$('#checkUserSeed').html(''+LANG_WELCOME.LG0+' <i class="fa-duotone fa-chevrons-right"></i>');
		
		$('.tdEmptySeed').keyup(async function() { 
			if($(this).attr('seedword') == $(this).val()) { 
				
				let thisid	=	$(this).attr('seedword_id');
				$('.tdWall_'+thisid+'').html('<i class="fa fa-check"></i>');
				$('.tdWall_'+thisid+'').css('background-color', '#acf3a6');
				
				$(this).css('border-bottom', '1px dashed #acf3a6');
				$(this).attr('disabled', '1');
				
			} else { }
		});
	} else if(step == 3){
	
		let word_error		=	0;
		
		seedcomp.forEach( function(id) {
			
			let val 	= 	$('#NEW_WALL_INPUT_'+id+'').val();
			let seedval	=	$('#NEW_WALL_INPUT_'+id+'').attr('seedword');
			
			console.log('[generateNewWallet] '+val+' / '+seedval);
			
			if(val != seedval) {
				$('.tdWall_'+id+'').css('background-color', '#ff6c6c');
				$('#NEW_WALL_INPUT_'+id+'').css('border-bottom', '1px dashed #ff6c6c');
				$('.tdWall_'+id+'').effect('pulsate');
				
				word_error += 1;
			} else {
				$('.tdWall_'+id+'').html('<i class="fa fa-check"></i>');
				
				$('.tdWall_'+id+'').css('background-color', '#acf3a6');
				$('#NEW_WALL_INPUT_'+id+'').css('border-bottom', '1px dashed #acf3a6');
				$('#NEW_WALL_INPUT_'+id+'').attr('disabled', '1');
			}
		
		});
		
		if(word_error == 0) {
		
		
			$('#TABLE_SEED_WORD').hide('slide', { 
				direction: "left",
				complete: function() {
					$('#TABLE_SEED_ACCOUNT').show('slide', { direction: "right" });
				}
			});
			
			
			
			$('#PAGE_WELCOME_CREATE_WALLET_SUB_TEXT').hide();
			$('#PAGE_WELCOME_CREATE_ACCOUNT_SUB_TEXT').show();
			
			
			$('#TABLE_SEED_ACCOUNT_PASS_CONFIRM').keyup(async function() {   
				if( $('#TABLE_SEED_ACCOUNT_PASS').val() == $('#TABLE_SEED_ACCOUNT_PASS_CONFIRM').val() &&  $('#TABLE_SEED_ACCOUNT_PASS_CONFIRM').val().length >= 8) {
				
					$('#TSA_keyhole_pass').removeClass('fa-thin fa-lock-keyhole-open').addClass('fa fa-lock-keyhole');
					$('#TSA_keyhole_pass_conf').removeClass('fa-thin fa-lock-keyhole-open').addClass('fa fa-lock-keyhole');
					$('#TSA_keyhole_pass').css('color', '#acf3a6');
					$('#TSA_keyhole_pass_conf').css('color', '#acf3a6');
				
				} else { 
				
					$('#TSA_keyhole_pass').addClass('fa-thin fa-lock-keyhole-open').removeClass('fa fa-lock-keyhole');
					$('#TSA_keyhole_pass_conf').addClass('fa-thin fa-lock-keyhole-open').removeClass('fa fa-lock-keyhole');
					$('#TSA_keyhole_pass').css('color', '#ff6c6c');
					$('#TSA_keyhole_pass_conf').css('color', '#ff6c6c');
					
				}
				
			});
			
			
			$('#checkUserSeed').unbind('click');
			$('#checkUserSeed').click(async function() { generateNewWallet(4); });
		
		
			
			
		} else { }
		
		
	} else if(step == 4) {
	
		let pass_one	=	$('#TABLE_SEED_ACCOUNT_PASS').val();
		let pass_conf	=	$('#TABLE_SEED_ACCOUNT_PASS_CONFIRM').val();
		
		if(pass_one == pass_conf && pass_conf.length >= 8) {
		
			$('#TSA_keyhole_pass').removeClass('fa-thin fa-lock-keyhole-open').addClass('fa fa-lock-keyhole');
			$('#TSA_keyhole_pass_conf').removeClass('fa-thin fa-lock-keyhole-open').addClass('fa fa-lock-keyhole');
			$('#TSA_keyhole_pass').css('color', '#acf3a6');
			$('#TSA_keyhole_pass_conf').css('color', '#acf3a6');
			
			$('#PAGE_WELCOME_LOGO_LOADING').show();
			$('#PAGE_WELCOME_CREATE_WALLET').css('opacity', '0.3');

			let pass			=	pass_one;
			let current_date	=	new Date;
			let REUNIT_JSON		=	{"pubKey": seedpair[0], "privKey": seedpair[1], "name": "My wallet"};
			
			let REUNIT_ENCODED	=	await encodeWallet(REUNIT_JSON,pass);
			let REUNIT_INIT_HISTORY		=	{};
			let REUNIT_INIT_SETTINGS	=	{
										"lang": "EN",
										"currency": "USD",
										"secureRPC": 1,
										"notifications": { },
										"gas_speed": 20,
										"locktime": 60,
										"network": "mainnet",
										"last_lockout": Math.ceil(current_date.getTime()/1000) };
			

			$('#passwordInputConfirmationIMG').css('color', '#0c8762');
			$('#passwordInputIMG').css('color', '#0c8762');
			
			chrome.storage.local.set({REUNIT_WALLET: REUNIT_ENCODED});
			chrome.storage.local.set({REUNIT_SETTINGS: REUNIT_INIT_SETTINGS});
			chrome.storage.local.set({REUNIT_HISTORY: REUNIT_INIT_HISTORY});
			chrome.storage.local.set({LIST_OF_TOKENS: {} });
			
			chrome.storage.session.set({REUNIT_PUBKEY: REUNIT_JSON.pubKey});
			
			
			REUNIT_PUBKEY	=	REUNIT_JSON.pubKey

			seedwords 	= [];
			seedcomp	= [];
			seedpair	= [];

			setTimeout(() => { 
				start('OK');
				$('#PAGE_WELCOME_CHOICE').hide();
				$('#PAGE_WELCOME_TOP_TEXT').hide();
				$('#PAGE_WELCOME_CREATE_WALLET').hide();
				$('#PAGE_WELCOME_LOGO_LOADING').hide();
			}, 1250);
			
			
		} else {
		
			$('#TSA_keyhole_pass').css('color', '#ff6c6c');
			$('#TSA_keyhole_pass').effect('pulsate');
			
			$('#TSA_keyhole_pass_conf').css('color', '#ff6c6c');
			$('#TSA_keyhole_pass_conf').effect('pulsate');
			
		}
	
	}
}


/**
	description		Encrypt wallet
**/

async function encodeWallet(w,p) {
	let msgUint8	=	new TextEncoder().encode(p);                          
	let hashBuffer	=	await crypto.subtle.digest('SHA-256', msgUint8);           
	let hashArray	=	Array.from(new Uint8Array(hashBuffer));                     
	let hashHex		=	hashArray.map((b) => b.toString(16).padStart(2, '0')).join(''); 
	let iv 			=	await window.crypto.randomUUID().replaceAll('-', '');
	let encoded		=	await encodePayload(hashHex, iv, w);
	let w_enc		=	encoded[0].data;
	return { "iv":iv, "data": w_enc };
}

/**
	description		Decrypt wallet
**/

async function decodeWallet(w,iv,p) {
	try {
		let msgUint8	=	new TextEncoder().encode(p);                          
		let hashBuffer	=	await crypto.subtle.digest('SHA-256', msgUint8);           
		let hashArray	=	Array.from(new Uint8Array(hashBuffer));                     
		let hashHex		=	hashArray.map((b) => b.toString(16).padStart(2, '0')).join(''); 
		let decoded		=	decodePayload(hashHex,iv,w);
		return decoded;
	} catch(e) {
		return 0;
	}
}

/**
	description		Decode wallet
**/
async function decodeKey(p) {
	console.log('%c[decodeKey] Function launched', 'background:#22bcce;color:white;');
	let localKey 	= await chrome.storage.local.get(['REUNIT_WALLET']);
	let clearKey;
	try {
		clearKey	=	JSON.parse(await decodeWallet(localKey.REUNIT_WALLET.data,localKey.REUNIT_WALLET.iv,p));
	} catch(e) {
		clearKey	=	false;
	}
	return clearKey;
}

/**
	description		Unlock wallet (homepage, transfer... )
**/
async function unlockWallet(p,type) {
	
	console.log('%c[unlockWallet] From : '+type, 'background:#22bcce;color:white;');
	
	if(type == 'lock_page') {
		$('#PAGE_UNLOCK_LOGO_LOADING').show();
	} else if(type == 'stargate_page') { 
		$('#unlockToSend_input').unbind();
		$('#unlockToSend_button').unbind();
		$('#unlockToSend_button').html('<i class="fa fa-spinner-third fa-spin"></i>');
	} else if(type == 'custom_erc20_page') {
		$('#unlockToSend_input').unbind();
		$('#unlockToSend_button').unbind();
		$('#unlockToSend_button').html('<i class="fa fa-spinner-third fa-spin"></i>');
	} else if(type == 'stargate_approval') {
		$('#unlockToSend_input').unbind();
		$('#unlockToSend_button').unbind();
		$('#unlockToSend_button').html('<i class="fa fa-spinner-third fa-spin"></i>');
	} else { }
	
	isDecoded	=	await decodeKey(p);
	if(isDecoded != false) {
	
		if(type == 'lock_page') {
			$('#unlock_submit').unbind('click');
			$('#PAGE_UNLOCK_ICON').addClass('fa-check').removeClass('fa-lock-keyhole').animate({"font-size": 0, "margin-top": +20},1250);
			$('#PAGE_UNLOCK_LOGO_LOADING').animate({"margin-left" : -40, "opacity": 0},1250);
			$('#PAGE_UNLOCK_TEXT').html('Wallet unlocked').fadeOut(1250);
			$('#unlock_submit').animate({"opacity": 0}, 1250);
			$('#topUnlock').animate({"opacity": 0}, 1250);
				
			setTimeout(() => { 	
				let ld	=	new Date();
				REUNIT_CONFIG.last_lockout = Math.ceil(ld.getTime()/1000);
				chrome.storage.local.set({REUNIT_SETTINGS: REUNIT_CONFIG});
				chrome.storage.session.set({REUNIT_PUBKEY: isDecoded.pubKey});	
				location.reload();
			}, 1100);
			
		} else if(type == 'stargate_page') {
			let tokN	=	$('#current_tokenName').val();
			
			$('#unlockToSend_signed').fadeOut();
			$('#unlockToSend_check_gas').animate({opacity: 1}, 500, function() {
				$('#unlockToSend_check_gas_logo').html('<i class="fa fa-spinner-third fa-spin"></i>');
				
				switch(CURRENT_TRANSACTION_TYPE) {
					case "STARGATE_SIMPLE_ERC20":	simpleERC20Transfer(tokN,CURRENT_SRC_CHAINID,btoa(p));		break;
					case "STARGATE_CROSSCHAIN":		reunitTransfer(tokN,1,btoa(p));								break;
				}
			});
			
		} else if(type == 'custom_erc20_page') {
			
			$('#unlockToSend_signed').fadeOut();
			$('#unlockToSend_check_gas').animate({opacity: 1}, 500, function() {
				$('#unlockToSend_check_gas_logo').html('<i class="fa fa-spinner-third fa-spin"></i>');
				checkCustomTransfer(2,btoa(p));
			});
		}  else if(type == 'stargate_approval') {
			let tokN	=	$('#current_tokenName').val();
			let chainID	=	Number(STARGATE_APPROVAL_CHAINID);
			$('#unlockToSend_signed').fadeOut();
			$('#unlockToSend_check_gas').animate({opacity: 1}, 500, function() {
				$('#unlockToSend_check_gas_logo').html('<i class="fa fa-spinner-third fa-spin"></i>');
				stargateApprove(tokN,chainID,btoa(p));
			});
		
		} else { }
	
	} else {
		console.log('%c[unlockWallet] bad password', 'background-color:red;color:white;');
		if(type == 'lock_page') {
			$('#tableUnlock').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
			$('#PAGE_UNLOCK_LOGO_LOADING').hide();
		} else if(type == 'stargate_page') {
			$('#unlockToSend_table').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
			$('#unlockToSend_button').text(LANG_SEND.LG81)
			// Re-bind
			$('#unlockToSend_button').click(async function() { unlockWallet($('#unlockToSend_input').val(),type); });
			$('#unlockToSend_input').keyup(async function(e) { if(e.which == 13) { let p	=	$('#unlockToSend_input').val(); unlockWallet(p,type); } else { } });
	
		} else if(type == 'custom_erc20_page') {
			$('#unlockToSend_table').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
			$('#unlockToSend_button').text(LANG_SEND.LG81)
			// Re-bind
			$('#unlockToSend_button').click(async function() { unlockWallet($('#unlockToSend_input').val(),type); });
			$('#unlockToSend_input').keyup(async function(e) { if(e.which == 13) { let p	=	$('#unlockToSend_input').val(); unlockWallet(p,type); } else { } });
	
		} else if(type == 'stargate_approval') {
			$('#unlockToSend_table').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
			$('#unlockToSend_button').text(LANG_SEND.LG81)
			// Re-bind
			$('#unlockToSend_button').click(async function() { unlockWallet($('#unlockToSend_input').val(),type); });
			$('#unlockToSend_input').keyup(async function(e) { if(e.which == 13) { let p	=	$('#unlockToSend_input').val(); unlockWallet(p,type); } else { } });

		}
	}

}


/**
	description		Load info token
**/

async function loadInfo(type,chainID,index) {
	
	console.log('%c[loadInfo] '+chainID+' @ '+index+' - '+type, 'background:#22bcce;color:white;');
	
	if(Number(chainID) != 0) {
	
		let token			=	index.split("_")[2].toLowerCase();
		let NEW_TOKEN_LIST	=	await fetch("./js/new_tokens_list.json");
		let TOKEN_INFO_LIST	=	await NEW_TOKEN_LIST.json();
		
			let tokendata	=	MY_TOKENS_LIST[token+'_'+chainID];
			let chainData	=	chainsData(Number(tokendata.chainId));
			let addr		=	tokendata.address;
			
			if(tokendata.custom_token == 1) {
				$('#TOKEN_INFO_TAGS_'+index).html('<span class="infoTags">#Custom</span> <span class="infoTags">#ERC20</span> <span class="infoTags">#DeFI</span>');
			} else { 
				$('#TOKEN_INFO_TAGS_'+index).html('<span class="infoTags">#ERC20</span> <span class="infoTags">#DeFI</span>');
			}
			
			$('#TOKEN_INFO_EXPLORER_'+index).html('<a href="'+chainData.explorer+'" target="_blank" style="color:black;text-decoration:none;">'+chainData.explorer+'</a>');
			$('#TR_TOKEN_INFO_DESCRIPTION_'+index).hide();
			$('#TOKEN_INFO_FULLNAME_'+index).text(tokendata.name+' / '+tokendata.symbol);
			$('#TOKEN_INFO_ADDRESS_'+index).html('<img src="./img/'+chainID+'.svg" style="width:16px;padding-right:6px;float:left;" /> <span class="reunitGradient">'+addr.substring(0,6)+'</span>'+addr.substring(6,9)+'....'+addr.substring(addr.length-8,addr.length-5)+'<span class="reunitGradient">'+addr.substring(addr.length-4,addr.length)+' &nbsp;</span><i style="font-size:12px;" class="fa-light fa-clone pointer copyThisAddress" address="'+addr+'" ></i>');
			$('#TR_TOKEN_INFO_LINKS_'+index).hide();
			$('#TOKEN_INFO_PRICE_'+index).text('$'+tokendata.usd_price.toFixed(6));
			$('#TR_TOKEN_INFO_PRICE_'+index).show();
			
			$('.copyThisAddress').unbind();
			$('.copyThisAddress').click(async function() { try { navigator.clipboard.writeText($(this).attr('address')); tinyNotif('Address copied', 250); } catch(e) { } });
			
		
	} else {
	
		if(type == "native") {
			let tokenData	=	chainsData(Number(index.split("_")[1]));
			$('#TR_TOKEN_INFO_ADDRESS_'+index).hide();
			$('#TOKEN_INFO_FULLNAME_'+index).text(tokenData.nativeToken+' on '+tokenData.name);
			$('#TOKEN_INFO_TAGS_'+index).html('<span class="infoTags">#Native</span> <span class="infoTags">#DeFI</span>');
			$('#TOKEN_INFO_DESCRIPTION_'+index).text(tokenData.nativeToken+' is the native token of '+tokenData.name); 
			$('#TOKEN_INFO_EXPLORER_'+index).html('<a href="'+tokenData.explorer+'" target="_blank" rel="noopener noreferrer" style="text-decoration:none;"><img src="./img/'+Number(index.split("_")[1])+'.svg" style="cursor:pointer;width:16px;padding-right:6px;float:left;" /></a>');
        	$('#TOKEN_INFO_LINKS_'+index).html('<a target="_blank" rel="noopener noreferrer" style="text-decoration:none;color:black;" href="'+tokenData.explorer+'">'+tokenData.explorer+'</a>');
        				
		}
		else {
		let tokenName	=	index.split("_")[1].toUpperCase();
		let tokenEmitter;
		$('#TOKEN_INFO_EXPLORER_'+index).html('');
		$('#TR_TOKEN_INFO_ADDRESS_'+index).hide();
		let NATIVE_CHAINS	=	[1,56,43114,137,42161,10,250];
		NATIVE_CHAINS.forEach(function(cid) {
        	let chainData 	= chainsData(cid);
        	let l			=	0;
        	
        	if(chainData.hasOwnProperty(tokenName.toLowerCase())) {
        		
        		let tokenData	=	chainData[tokenName.toLowerCase()];
            	$('#TOKEN_INFO_EXPLORER_'+index).append('<a href="'+chainData.explorer+'token/'+tokenData.address+'" target="_blank" rel="noopener noreferrer" style="text-decoration:none;"><img src="./img/'+cid+'.svg" style="cursor:pointer;width:16px;padding-right:6px;float:left;" /></a>');
        		if(l == 0) {
        			$('#TOKEN_INFO_LINKS_'+index).html('<a target="_blank" rel="noopener noreferrer" style="text-decoration:none;color:black;" href="'+tokenData.link+'">'+tokenData.link+'</a>');
        			$('#TOKEN_INFO_DESCRIPTION_'+index).text(tokenData.description);
        		}
        		l = 1;
        	}
        });

		$('#TOKEN_INFO_TAGS_'+index).html('<span class="infoTags">#DeFI</span> <span class="infoTags">#Crosschain</span> <span class="infoTags">#StargateToken</span>');
		switch(tokenName.toUpperCase()) { 
				case "USDC": tokenEmitter = 'Circle'; break;
				case "USDT": tokenEmitter = 'Tether'; break;
				case "DAI": tokenEmitter = 'MakerDAO'; break;
				case "STG": tokenEmitter = 'LayerZero'; break;
				case "BUSD": tokenEmitter = 'Paxos'; break;
		 }
		$('#TOKEN_INFO_FULLNAME_'+index).text(tokenName+' by '+tokenEmitter);
		
		}
	}
}


/**
	description		Create / Delete list of tokens
**/
async function manageListOfTokens(a,n) {
	let w3	=	new Web3();
	let e	=	w3.utils.toHex(n);
	switch(a) {
		case "ADD":
			console.log('[manageListOfTokens] New list created');
			LISTS_TOKENLIST[e]	=	n;
			await chrome.storage.local.set({LIST_OF_TOKENS: LISTS_TOKENLIST});
			break;
		case "DELETE":
			console.log('[manageListOfTokens] List deleted');
			delete LISTS_TOKENLIST[e];
			await chrome.storage.local.set({LIST_OF_TOKENS: LISTS_TOKENLIST});
			break;
	}
}


/**
	description		Load tokens by chain/wallet ( except stargate token )
**/
async function apiLoadTokens(type, chainName, currentChainID) {
	let apiurl;
	
	switch(type) {
		case 1:	apiurl	=	"https://wmhwszcutojqwsn2loirsdp4vq0hwdmp.lambda-url.eu-west-2.on.aws"; break;
		case 2:	apiurl	=	"https://6gk4ege33fiwp3pvtd5pqdge2u0jursi.lambda-url.eu-west-2.on.aws"; break;
	}
	await $.getJSON(""+apiurl+"/?address="+REUNIT_PUBKEY+"&chain="+chainName, async function(debank) {
			let debankData;
			if(type == 1) {
				debankData	=	debank.data;
			} else {
				debankData	=	debank;
			}
			for(i in debankData) {
				let debankAddress	=	debankData[i].id.toLowerCase();
				
				TOKENS_LIST.forEach( function(token) {
					if(token.address.toLowerCase() == debankAddress.toLowerCase() && token.chainId == currentChainID) {
						let tk_id						=	token.address.toLowerCase()+'_'+token.chainId;
						let token_to_add				=	token;
						token_to_add['balance']			=	new Big(0);
						token_to_add['added_timestamp']	=	Date.now();
						
						if(MY_TOKENS_LIST[tk_id] == undefined || MY_TOKENS_LIST[tk_id] == null) {
							MY_TOKENS_LIST[tk_id]			=	token_to_add;
							chrome.storage.local.set({CUSTOM_TOKEN_LIST: MY_TOKENS_LIST});
						} else { }
					} else { }
				});
			}
		
	});
}

async function loadMyTokensList() {
	let checkLoaded	=	await chrome.storage.local.get(['isTokenslistImported']);
	if(checkLoaded.isTokenslistImported != 1) {
		let listChains	=	{'eth': 1, 'bsc':56, 'matic':137, 'ftm':250, 'avax': 43114, 'op':10, 'arb':42161};
		tinyNotif("Importing tokens in progress",300);
		$('#topReunitLoading').fadeIn();
		for(chainName in listChains) {
		let currentChainID	=	listChains[chainName];
		
		try {
			console.log('[loadMyTokensList] V1: '+currentChainID);
			await apiLoadTokens(1, chainName, currentChainID);
		} catch(e) {
			console.log('[loadMyTokensList] V2: '+currentChainID);
			await apiLoadTokens(2, chainName, currentChainID);
		}
		}
		showSelectedTokens(1);
		tinyNotif("Tokens imported",250);
		$('#topReunitLoading').fadeOut();
		chrome.storage.local.set({isTokenslistImported: 1});
	} else {
	
	}
}


/**
	description		search custom token
**/
async function searchCustomToken() {
	$('#ADDCUSTOMTOKEN_SEARCH').unbind();
	$('#ADDCUSTOMTOKEN_SEARCH').html('<i class="fa fa-spinner-third fa-spin"></i> '+LANG_HOME.LG59+'...');
	
	let token_chainID		=	Number($('#ADDCUSTOMTOKEN_CHAIN').val());
	let chainInfo			=	chainsData(token_chainID);
	let token_address		=	$('#ADDCUSTOMTOKEN_ADDRESS').val();
	let t3					=	new Web3(chainInfo.node+"&mode=normal");

	try {
		let tokenContract 		=	new t3.eth.Contract(ERC20_FULL_ABI, token_address);
 		let symbol 				=	await tokenContract.methods.symbol().call();
		let decimals 			=	await tokenContract.methods.decimals().call();
		let name 				=	await tokenContract.methods.name().call();
	
	
		$('#ADDCUSTOMTOKEN_RESULT_SEARCH').fadeIn();
		$('#ADDCUSTOMTOKEN_NAME').val(name);
		$('#ADDCUSTOMTOKEN_SYMBOL').text(symbol);
		$('#ADDCUSTOMTOKEN_DECIMALS').text(decimals);
		
		$('#ADDCUSTOMTOKEN_SEARCH').text(LANG_HOME.LG60.replace("XXX_XXX", symbol.toUpperCase())).css('font-weight', 'bold');
		$('#ADDCUSTOMTOKEN_SEARCH').click(function() { 
			$('#ADDCUSTOMTOKEN_SEARCH').html('<i class="fa fa-spinner-third fa-spin"></i>');
			addCustomToken(token_chainID,token_address,symbol,Big(decimals).toNumber(),name); 
		});
		
	} catch(e) {
		$('#ADDCUSTOMTOKEN_RESULT_SEARCH').fadeOut();
		$('#ADDCUSTOMTOKEN_ADDRESS_TOP').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
		$('#ADDCUSTOMTOKEN_SEARCH').effect('shake', function() {
			$('#ADDCUSTOMTOKEN_SEARCH').text('Get token information');
			$('#ADDCUSTOMTOKEN_SEARCH').click(function() { searchCustomToken(); });
		});
	}
}

async function addCustomToken(c_chainID,c_address,c_symbol,c_decimals,c_name) {


	let chainName			=	$('option:selected', '#ADDCUSTOMTOKEN_CHAIN').attr('chain');
	let logo				=	"./img/no_image.png";
	try {
		$.getJSON("https://ndwzsccgdc7t4x2ooqrwjd2f7y0nlast.lambda-url.eu-west-2.on.aws/?address="+c_address+"&chain="+chainName, async function(apiresult) {
		if(apiresult.logo_url != null || apiresult.logo_url != '' || apiresult.logo_url != undefined || apiresult.logo_url.length > 0) {
			logo = apiresult.logo_url;
		} else {
			logo = "./img/no_image.png";
		}
		MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["logoURI"] =	logo;
		chrome.storage.local.set({CUSTOM_TOKEN_LIST: MY_TOKENS_LIST});
		showSelectedTokens(1);
		});
	} catch(e) {
		logo = "./img/no_image.png";
		MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["logoURI"] =	logo;
		chrome.storage.local.set({CUSTOM_TOKEN_LIST: MY_TOKENS_LIST});
		showSelectedTokens(1);
	}
		
	MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]						=	{};
	MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["added_timestamp"]	=	Date.now();
	MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["address"]			=	c_address;
	MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["balance"]			=	new Big(0);
	MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["chainId"]			=	Number(c_chainID);
	MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["decimals"]			=	Number(c_decimals);
	MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["name"]				=	c_name;
	MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["symbol"]				=	c_symbol;
	MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["custom_token"]		=	1;
	MY_TOKENS_LIST[c_address.toLowerCase()+"_"+c_chainID]["logoURI"] 			=	"./img/no_image.png";
	chrome.storage.local.set({CUSTOM_TOKEN_LIST: MY_TOKENS_LIST});
	
	$('#ADDCUSTOMTOKEN_SEARCH').html('<i class="fa fa-check"></i> '+LANG_HOME.LG61+' !');
	$('#ADDCUSTOMTOKEN_RESULT_SEARCH').fadeOut();
	$('#ADDCUSTOMTOKEN_NAME').val('');
	$('#ADDCUSTOMTOKEN_SYMBOL').text('');
	$('#ADDCUSTOMTOKEN_DECIMALS').text('');
	$('#POPUP_ADD_TOKEN').fadeOut();
	$('#bgPopup').hide("drop");
	
	showSelectedTokens(1);
}

/**
	description		Export wallet
**/
async function export_wallet() {

	let reunit_storage	=	await chrome.storage.local.get();
	let to_export 		= { "REUNIT_PUBKEY": REUNIT_PUBKEY, "STORAGE": reunit_storage };
	let content 		= "data:application/json;charset=utf-8,";
	
	content += JSON.stringify(to_export);

	let encodedUri 		= encodeURI(content);
	let link 			= document.createElement("a");
	link.setAttribute("href", encodedUri);
	link.setAttribute("download", "wallet_"+REUNIT_PUBKEY+".json");

	document.body.appendChild(link);
	link.click();

}

async function import_wallet(file) {
	try {
		let backup	=	JSON.parse(file);
		chrome.storage.local.set({REUNIT_WALLET: backup.STORAGE.REUNIT_WALLET});
		chrome.storage.local.set({CONTACTS_LIST: backup.STORAGE.CONTACTS_LIST});
		chrome.storage.local.set({CUSTOM_TOKEN_LIST: backup.STORAGE.CUSTOM_TOKEN_LIST});
		chrome.storage.local.set({LIST_OF_TOKENS: backup.STORAGE.LIST_OF_TOKENS});
		chrome.storage.local.set({REUNIT_SETTINGS: backup.STORAGE.REUNIT_SETTINGS});
		chrome.storage.local.set({isTokenslistImported: backup.STORAGE.isTokenslistImported});
		chrome.storage.session.remove(["REUNIT_PUBKEY"]);
		tinyNotif('Wallet imported', 300);
		$('body').animate({"opacity": 0.03}, { complete: function () { location.reload(); } }, 800);
		
	} catch(e) {
		$('.sett1').effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"}).effect('highlight', {color: "#f6765f"});
	} 
}

$('#IMPORT_WALLET').on("change", function() {
	let reader		=	new FileReader();
	reader.onload	=	function(){	import_wallet(reader.result); }
    reader.readAsText(this.files[0]);
});

/**
	description		start Reunit Wallet
**/

async function start_reunit() {
	try {
		chrome.storage.local.get(['REUNIT_SETTINGS'], async function(settings) {

		try {
			REUNIT_CONFIG	=	settings.REUNIT_SETTINGS;
			getLang(REUNIT_CONFIG.lang);
		} catch(e) {
			getLang('EN');
		}

			chrome.storage.local.get(['REUNIT_WALLET'], async function(w) {
			
				if(settings.hasOwnProperty('REUNIT_SETTINGS') && w.hasOwnProperty('REUNIT_WALLET') && w.REUNIT_WALLET.hasOwnProperty('data') && w.REUNIT_WALLET.hasOwnProperty('iv') ) {
			
					REUNIT_CONFIG	=	settings.REUNIT_SETTINGS;
					let locked		=	is_locked();

					if(locked == 1) {
						console.log('%c[start_reunit] locked + no_pubkey ', 'background-color:red;color:white;');
						chrome.storage.session.remove(["REUNIT_PUBKEY"]);
						start('NO_PUBKEY');
					} else {
						chrome.storage.session.get(['REUNIT_PUBKEY'], async function(sess) {
							
							if(sess.hasOwnProperty('REUNIT_PUBKEY')) {
								REUNIT_PUBKEY	=	sess.REUNIT_PUBKEY;
								
								chrome.storage.local.get(['REUNIT_HISTORY'], async function(h) {
								
									chrome.storage.local.get(['LIST_OF_TOKENS'], async function(tlist) {
										console.log('%c[start_reunit] unlocked + clear pubkey + history loaded + tokenlists loaded', 'background-color:green;color:white;');
										REUNIT_TX_HISTORY	=	h.REUNIT_HISTORY;
										LISTS_TOKENLIST		=	tlist.LIST_OF_TOKENS;
										start('OK');
										loadMyTokensList();
									});
								});
							
							} else {
								console.log('%c[start_reunit] manually locked + no pubkey', 'background-color:red;color:white;');
								chrome.storage.session.remove(["REUNIT_PUBKEY"]);
								start('NO_PUBKEY');
							}

						});	
					}
			
				} else {
					// Something failed, restart
					console.log('%c[start_reunit] no settings +/- no wallet ','background-color:red;color:white;');
					chrome.storage.session.remove(["REUNIT_PUBKEY"]);
					chrome.storage.local.remove(["REUNIT_WALLET"]);
					chrome.storage.local.remove(["REUNIT_SETTINGS"]);
					chrome.storage.local.remove(["REUNIT_HISTORY"]);
					chrome.storage.local.remove(["isTokenslistImported"]);
					start('INIT');
				}
			});
			
		});
		
	} catch(e) {
		console.log('%c[start_reunit] Something failed, full restart ','background-color:red;color:white;');
		chrome.storage.session.remove(["REUNIT_PUBKEY"]);
		chrome.storage.local.remove(["REUNIT_WALLET"]);
		chrome.storage.local.remove(["REUNIT_SETTINGS"]);
		chrome.storage.local.remove(["REUNIT_HISTORY"]);
		chrome.storage.local.remove(["isTokenslistImported"]);
		start('INIT');
	} 
}



start_reunit();