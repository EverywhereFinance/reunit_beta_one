
function getLang(lang) {
	console.log('[getLang] Lang requested : '+lang);
	
	
	
	
	switch(lang) {
	
	default:
	case "EN":
	LANG_WELCOME		=			{'LG1': 'Create a new wallet',
									'LG2': 'Import a private key',
									'LG3': 'Import a seed phrase',
									'LG4': 'Wallet address',
									'LG5': 'Please fill the empty fields with the correct word',
									'LG0': 'Finish',
									'LG6': 'Choose a strong password to secure your account',
									'LG7': 'Please fill the form to import your address',
									'LG8': 'Type or paste your private key here...',
									'LG9': 'Type a password...',
									'LG10': 'Confirm your password...',
									'LG11': 'Please enter the 12 words of your seed phrase',
									'LG12': 'I have a custom seed phrase',
									'LG13': 'Select an address and choose a password',
									'LG14': 'Import',
									'LG15': 'Never share your <span class="reunitGradient">private keys</span>',
									'LG16': 'Import your wallet',
									'LG17': 'Please write carefully your <span class="reunitGradient">seed phrase</span>'
									};
									
	LANG_HOME			=			{
									'LG18': 'Your selected tokens',
									'LG19': 'Select a list of tokens',
									'LG20': 'All',
									'LG21': 'Create a new list',
									'LG22': 'Enter a name for your list...',
									'LG23': 'This list doesn\'t contain any tokens',
									'LG24': 'To add tokens to this list, return to the homepage, and click on <i class="reunitGradient fa-solid fa-ellipsis-vertical" style="font-size: 17px;"></i> located to the left of the token you want.',
									'LG25': 'Back to home',
									'LG26': 'Transaction history',
									'LG27': 'Your transaction history is empty',
									'LG28': 'This doesn\'t necessarily mean that you have never made a transaction, just that they were not made with Reunit Wallet.',
									'LG29': 'To view your transaction history :',
									'LG30': 'click here',
									'LG31': 'Links',
									'LG32': 'Settings',
									'LG33': 'Configure your wallet',
									'LG34': 'Currency',
									'LG35': 'Transaction speed',
									'LG36': 'normal',
									'LG37': 'fast',
									'LG38': 'very fast',
									'LG39': 'turbo',
									'LG40': 'Delay before locking',
									'LG41': 'minutes',
									'LG42': 'Back',
									'LG43': 'Copied',
									'LG44': 'Current wallet',
									'LG45': 'Network changed',
									'LG46': 'TODAY',
									'LG47': 'Received',
									'LG48': 'Sent',
									'LG49': 'Transaction receipt',
									'LG50': 'Search tokens by name or address',
									'LG51': 'Add tokens to your list',
									'LG52': 'Search through <b>7</b> blockchains',
									'LG54': 'Add a custom token',
									'LG55': 'Added',
									'LG56': 'Deleted',
									'LG57': 'Enter the token address...',
									'LG58': 'Get token information',
									'LG59': 'Loading',
									'LG60': 'Click here to add XXX_XXX to your list',
									'LG61': 'Token added !',
									'LG62': 'Remove this token',
									'LG63': 'Remove from this list',
									'LG64': 'Add to a list',
									'LG65': 'Close',
									'LG66': 'Add this token to a list',
									'LG67': 'Select a list',
									'LG68': 'Add to this list',
									'LG69': 'Unlock your wallet',
									'LG70': 'Enter your password to unlock your wallet...',
									'LG71': 'Reset my wallet',
									};
									
									
	LANG_SEND			=			{		 
									'LG72': 'Amount',
									 'LG73': 'send',
									 'LG74': 'home',
									 'LG75': 'Type or search the recipient address here...',
									 'LG76': 'Manage your contacts',
									 'LG77': 'Search by name, address, email...',
									 'LG78':'Name',
									 'LG79':'Address',
									 'LG80': 'Enter your password...',
									 'LG81': 'Sign the transaction',
									 'LG82': 'Back to send page',
									 'LG83': 'TRANSACTION SUMMARY',
									 'LG84': 'Sending date ',
									 'LG85': 'Fees',
									 'LG86': 'Confirmed',
									 'LG87': 'pending',
									};
				
				
	LANG_CROSSCHAIN		=			{		 
									 'LG88': 'TOTAL',
									 'LG89': 'Destination',
									 'LG92': 'The transaction has been <span style="color:#22bcce;">sent</span>',
									 'LG93': 'Approve',
									 'LG94': 'You don\'t have enough XXX_XXX to pay fees',
									 'LG95': 'Please try again in few minutes',
									};	
									 
	break;
	
	
	
	case "KR":
	LANG_WELCOME		=			{
										'LG1': '새 지갑 만들기',
										'LG2': '개인 키 가져오기',
										'LG3': 'seed phrase 가져오기',
										'LG4': '지갑 주소',
										'LG5': '빈칸을 올바른 단어로 채워 주세요',
										'LG0': '완료',
										'LG6': '계정 보안을 위해 강력한 비밀번호를 선택하세요',
										'LG7': '주소를 가져오려면 양식을 작성하세요',
										'LG8': '여기에 개인 키를 입력하거나 붙여넣으세요...',
										'LG9': '비밀번호를 입력하세요...',
										'LG10': '비밀번호를 확인하세요...',
										'LG11': 'seed phrase 12단어를 입력하세요',
										'LG12': '사용자 지정 seed phrase가 있습니다',
										'LG13': '주소를 선택하고 비밀번호를 선택하세요',
										'LG14': '가져오기',
										'LG15': '<span class="reunitGradient">개인 키</span>를 공유하지 마세요',
										'LG16': '지갑 가져오기',
										'LG17': '<span class="reunitGradient">seed phrase</span>를 신중하게 작성하세요',
									};
									
	LANG_HOME			=			{
										'LG18': '선택한 tokens',
										'LG19': 'tokens 목록 선택',
										'LG20': '모두',
										'LG21': '새 목록 생성',
										'LG22': '목록 이름을 입력하세요...',
										'LG23': '이 목록에는 tokens이 없습니다',
										'LG24': '이 목록에 tokens을 추가하려면 홈페이지로 돌아가서 원하는 토큰 왼쪽에 있는 <i class="reunitGradient fa-solid fa-ellipsis-vertical" style="font-size: 17px;"></i>을(를) 클릭하세요.',
										'LG25': '홈으로 돌아가기',
										'LG26': '거래 내역',
										'LG27': '거래 내역이 비어 있습니다',
										'LG28': '거래를 한 번도 하지 않았다는 의미는 아니며, Reunit Wallet에서 거래하지 않았다는 의미입니다.',
										'LG29': '거래 내역을 보려면:',
										'LG30': '여기를 클릭하세요',
										'LG31': '링크',
										'LG32': '설정',
										'LG33': '지갑을 구성하세요',
										'LG34': '통화',
										'LG35': '거래 속도',
										'LG36': '보통',
										'LG37': '빠름',
										'LG38': '매우 빠름',
										'LG39': '터보',
										'LG40': '잠금 전 지연',
										'LG41': '분',
										'LG42': '뒤로',
										'LG43': '복사됨',
										'LG44': '현재 지갑',
										'LG45': '네트워크가 변경됨',
										'LG46': '오늘',
										'LG47': '수령함',
										'LG48': '전송됨',
										'LG49': '거래 영수증',
										'LG50': '이름 또는 주소로 tokens 검색',
										'LG51': '목록에 tokens 추가',
										'LG52': '<b>7</b>개의 블록체인에서 검색',
										'LG54': '사용자 지정 token 추가',
										'LG55': '추가됨',
										'LG56': '삭제됨',
										'LG57': 'token 주소 입력...',
										'LG58': 'token 정보 가져오기',
										'LG59': '로드 중',
										'LG60': 'XXX_XXX을(를) 목록에 추가하려면 여기를 클릭하세요',
										'LG61': 'Token이 추가되었습니다!',
										'LG62': '이 token 제거',
										'LG63': '이 목록에서 제거',
										'LG64': '목록에 추가',
										'LG65': '닫기',
										'LG66': 'token을 목록에 추가',
										'LG67': '목록 선택',
										'LG68': '이 목록에 추가',
										'LG69': '지갑 잠금 해제',
										'LG70': '지갑 잠금을 해제하려면 비밀번호를 입력하세요...',
										'LG71': '내 지갑 초기화',
									};
									
									
	LANG_SEND			=			{		 
										'LG72': '금액',
										'LG73': '전송',
										'LG74': '홈',
										'LG75': '수신자 주소를 여기에 입력하거나 검색하세요...',
										'LG76': '연락처 관리',
										'LG77': '이름, 주소, 이메일로 검색하세요...',
										'LG78':'이름',
										'LG79':'주소',
										'LG80': '비밀번호를 입력하세요...',
										'LG81': '거래에 서명',
										'LG82': '전송 페이지로 돌아가기',
										'LG83': '거래 요약',
										'LG84': '전송 날짜 ',
										'LG85': '수수료',
										'LG86': '확인됨',
										'LG87': '보류 중',
									};
				
				
	LANG_CROSSCHAIN		=			{		 
										'LG88': '총계',
										'LG89': '목적지',
										'LG92': '거래가 <span style="color:#22bcce;">전송</span>되었습니다',
										'LG93': '승인',
										'LG94': '수수료를 지불할 XXX_XXX이(가) 충분하지 않습니다',
										'LG95': '몇 분 후에 다시 시도하세요',
									};	
									 
	break;
	
	
	case "RU":
	LANG_WELCOME		=			{
										'LG1': 'Создать новый кошелек',
										'LG2': 'Импортировать закрытый ключ',
										'LG3': 'Импортировать сид-фраду',
										'LG4': 'Адрес кошелька',
										'LG5': 'Пожалуйста, укажите в пустых полях правильные слова',
										'LG0': 'Закончить',
										'LG6': 'Выберите надежный пароль, чтобы защитить свой аккаунт',
										'LG7': 'Пожалуйста, заполните форму, чтобы импортировать свой адрес',
										'LG8': 'Напишите или вставьте свой закрытый ключ сюда...',
										'LG9': 'Напишите пароль...',
										'LG10': 'Напишите пароль еще раз...',
										'LG11': 'Пожалуйста, укажите 12 слов сид-фразы',
										'LG12': 'У меня пользовательская сид-фраза',
										'LG13': 'Выберите адрес и укажите пароль',
										'LG14': 'Импортировать',
										'LG15': 'Никогда не делитесь своими <span class="reunitGradient">закрытыми ключами</span>',
										'LG16': 'Импортировать кошелек',
										'LG17': 'Пожалуйста, внимательно укажите свою <span class="reunitGradient">сид-фразу</span>',
									};
									
	LANG_HOME			=			{
										'LG18': 'Ваши выбранные токены',
										'LG19': 'Выберите список токенов',
										'LG20': 'Все',
										'LG21': 'Создать новый список',
										'LG22': 'Укажите имя для своего списка...',
										'LG23': 'Этот список не содержит токенов',
										'LG24': 'Чтобы добавить токены в этот список, вернитесь на главную страницу и нажмите <i class="reunitGradient fa-solid fa-ellipsis-vertical" style="font-size: 17px;"></i> слева от нужного вам токена.',
										'LG25': 'Назад на главную',
										'LG26': 'История транзакций',
										'LG27': 'Ваша история транзакций пуста',
										'LG28': 'Это не обязательно значит, что вы не совершали транзакции, просто они не были совершены через Reunit Wallet.',
										'LG29': 'Для просмотра истории транзакций:',
										'LG30': 'нажмите сюда',
										'LG31': 'Ссылки',
										'LG32': 'Настройки',
										'LG33': 'Настроить кошелек',
										'LG34': 'Валюта',
										'LG35': 'Скорость транзакций',
										'LG36': 'нормальная',
										'LG37': 'быстрая',
										'LG38': 'очень быстрая',
										'LG39': 'турбо',
										'LG40': 'Задержка перед блокировкой',
										'LG41': 'мин.',
										'LG42': 'Назад',
										'LG43': 'Скопировано',
										'LG44': 'Текущий кошелек',
										'LG45': 'Сеть изменена',
										'LG46': 'СЕГОДНЯ',
										'LG47': 'Получено',
										'LG48': 'Отправлено',
										'LG49': 'Квитанция транзакции',
										'LG50': 'Поиск токенов по названию или адресу',
										'LG51': 'Добавить токены в список',
										'LG52': 'Поиск по <b>7</b> блокчейнам',
										'LG54': 'Добавить пользовательский токен',
										'LG55': 'Добавлено',
										'LG56': 'Удалено',
										'LG57': 'Укажите адрес токена...',
										'LG58': 'Получить информацию о токене',
										'LG59': 'Загрузка',
										'LG60': 'Нажмите сюда, чтобы добавить XXX_XXX в свой список',
										'LG61': 'Токен добавлен!',
										'LG62': 'Удалить этот токен',
										'LG63': 'Удалить из этого списка',
										'LG64': 'Добавить в список',
										'LG65': 'Закрыть',
										'LG66': 'Добавить этот токен в список',
										'LG67': 'Выберите список',
										'LG68': 'Добавить в этот список',
										'LG69': 'Разблокируйте свой кошелек',
										'LG70': 'Укажите свой пароль, чтобы разблокировать кошелек...',
										'LG71': 'Сбросить мой кошелек',
									};
									
									
	LANG_SEND			=			{		 
										'LG72': 'Сумма',
										'LG73': 'отправить',
										'LG74': 'главная',
										'LG75': 'Укажите или найдите адрес получателя здесь...',
										'LG76': 'Управление контактами',
										'LG77': 'Поиск по имени, адресу, эл. почте...',
										'LG78': 'Имя',
										'LG79': 'Адрес',
										'LG80': 'Укажите свой пароль...',
										'LG81': 'Подписать транзакцию',
										'LG82': 'Назад на страницу отправки',
										'LG83': 'ОБЗОР ТРАНЗАКЦИИ',
										'LG84': 'Дата отправки ',
										'LG85': 'Комиссия',
										'LG86': 'Подтверждено',
										'LG87': 'ожидается',
									};
				
				
	LANG_CROSSCHAIN		=			{		 
										'LG88': 'ИТОГО',
										'LG89': 'Адрес назначения',
										'LG92': 'Транзакция была <span style="color:#22bcce;">отправлена</span>',
										'LG93': 'Одобрить',
										'LG94': 'У вас недостаточно XXX_XXX для оплаты комиссии',
										'LG95': 'Пожалуйста, повторите попытку через несколько минут.',
									};	
									 
	break;
	
	
	case "CN":
	LANG_WELCOME		=			{
										'LG1': '创建新钱包',
										'LG2': '导入私钥',
										'LG3': '导入助记词',
										'LG4': '钱包地址',
										'LG5': '请用正确的词填写空白字段',
										'LG0': '完成',
										'LG6': '选择一个强密码来保护您的账户',
										'LG7': '请填写表格以导入您的地址',
										'LG8': '在此处输入或粘贴您的私钥……',
										'LG9': '输入密码……',
										'LG10': '确认您的密码……',
										'LG11': '请输入您的 12 个助记词',
										'LG12': '我有一个自定义助记词',
										'LG13': '选择地址并选择密码',
										'LG14': '导入',
										'LG15': '永远不要让他人获取您的<span class="reunitGradient">私钥</span>',
										'LG16': '导入您的钱包',
										'LG17': '请仔细填写您的<span class="reunitGradient">助记词</span>',
									};
									
	LANG_HOME			=			{
										'LG18': '您选择的 token',
										'LG19': '选择 token 列表',
										'LG20': '全部',
										'LG21': '创建新列表',
										'LG22': '为您的列表输入一个名称……',
										'LG23': '这个列表不包含任何 token',
										'LG24': '要将 token 添加到此列表，请返回主页，然后点击您想要的 token 左侧的 <i class="reunitGradient fa-solid fa-ellipsis-vertical" style="font-size: 17px;"></i>。',
										'LG25': '返回主页',
										'LG26': '交易历史',
										'LG27': '您的交易记录为空',
										'LG28': '这并不一定意味着您从未进行过交易，只是这些交易不是使用 Reunit 钱包进行的。',
										'LG29': '查看您的交易记录: ',
										'LG30': '点击此处',
										'LG31': '链接',
										'LG32': '设置',
										'LG33': '配置您的钱包',
										'LG34': '币种',
										'LG35': '交易速度',
										'LG36': '正常',
										'LG37': '快',
										'LG38': '非常快',
										'LG39':'turbo',
										'LG40': '锁定前延迟',
										'LG41': '分钟',
										'LG42': '返回',
										'LG43': '已复制',
										'LG44': '当前钱包',
										'LG45': '网络已改变',
										'LG46': '今天',
										'LG47': '已收到',
										'LG48': '已发送',
										'LG49': '交易回执',
										'LG50': '按名称或地址搜索 token',
										'LG51': '将 token 添加到您的列表',
										'LG52': '在<b>7</b> 个区块链中搜索',
										'LG54': '添加自定义 token',
										'LG55': '已添加',
										'LG56': '已删除',
										'LG57': '输入 token 地址……',
										'LG58': '获取 token 信息',
										'LG59': '正在加载',
										'LG60': '单击此处将 XXX_XXX 添加到您的列表',
										'LG61': 'token 已添加！',
										'LG62': '删除此 token',
										'LG63': '从此列表中删除',
										'LG64': '添加到列表',
										'LG65': '关闭',
										'LG66': '将此 token 添加到列表',
										'LG67': '选择列表',
										'LG68': '添加到这个列表',
										'LG69': '解锁您的钱包',
										'LG70': '输入密码以解锁钱包……',
										'LG71': '重置我的钱包',
									};
									
									
	LANG_SEND			=			{		 
										'LG72': '数量',
										'LG73': '发送',
										'LG74': '主页',
										'LG75': '在此处输入或搜索接收人的地址……',
										'LG76': '管理您的联系人',
										'LG77': '按名称、地址、电子邮件进行搜索……',
										'LG78':'名称',
										'LG79':'地址',
										'LG80': '请输入您的密码……',
										'LG81': '签署交易',
										'LG82': '返回发送页面',
										'LG83': '交易摘要',
										'LG84': '发送日期',
										'LG85': '费用',
										'LG86': '已确认',
										'LG87': '待定',
									};
				
				
	LANG_CROSSCHAIN		=			{		 
										'LG88': '总计',
										'LG89': '目的地',
										'LG92': '交易已<span style="color:#22bcce;">发送</span>',
										'LG93': '同意',
										'LG94': '您没有足够的XXX_XXX来支付费用',
										'LG95': '请过几分钟再试',
									};	
									 
	break;
	
	
	
	case "IT":
	LANG_WELCOME		=			{
										'LG1': 'Crea un nuovo portafoglio',
										'LG2': 'Importa una chiave privata',
										'LG3': 'Importa una seed phrase',
										'LG4': 'Indirizzo portafoglio',
										'LG5': 'Compila i campi vuoti con la parola corretta',
										'LG0': 'Fine',
										'LG6': 'Scegli una password complessa per proteggere il tuo account',
										'LG7': 'Compila il modulo per importare il tuo indirizzo',
										'LG8': 'Digita o incolla qui la tua chiave privata...',
										'LG9': 'Digita una password...',
										'LG10': 'Conferma la tua password...',
										'LG11': 'Inserisci le 12 parole della tua seed phrase',
										'LG12': 'Ho una seed phrase personalizzata',
										'LG13': 'Seleziona un indirizzo e scegli una password',
										'LG14': 'Importa',
										'LG15': 'Non condividere mai le tue <span class="reunitGradient">chiavi private</span>',
										'LG16': 'Importa il tuo portafoglio',
										'LG17': 'Scrivi attentamente la tua <span class="reunitGradient">seed phrase</span>',
									};
									
	LANG_HOME			=			{
										'LG18': 'Token selezionati',
										'LG19': 'Seleziona un elenco di token',
										'LG20': 'Tutti',
										'LG21': 'Crea un nuovo elenco',
										'LG22': 'Inserisci un nome per il tuo elenco...',
										'LG23': 'Questo elenco non contiene alcun token',
										'LG24': 'Per aggiungere token a questo elenco, torna alla home page e fai clic su <i class="reunitGradient fa-solid fa-ellipsis-vertical" style="font-size: 17px;"></i> a sinistra del token desiderato.',
										'LG25': 'Ritorno alla home',
										'LG26': 'Cronologia transazioni',
										'LG27': 'La cronologia delle tue transazioni è vuota',
										'LG28': 'Questo non significa necessariamente che non hai mai effettuato una transazione, solo che non sono state effettuate con Reunit Wallet.',
										'LG29': 'Per visualizzare la cronologia delle tue transazioni:',
										'LG30': 'clicca qui',
										'LG31': 'Link',
										'LG32': 'Impostazioni',
										'LG33': 'Configura il tuo portafoglio',
										'LG34': 'Valuta',
										'LG35': 'Velocità di transazione',
										'LG36': 'normale',
										'LG37': 'veloce',
										'LG38': 'molto veloce',
										'LG39': 'turbo',
										'LG40': 'Ritardo prima del blocco',
										'LG41': 'minuti',
										'LG42': 'Indietro',
										'LG43': 'Copiato',
										'LG44': 'Portafoglio corrente',
										'LG45': 'Rete modificata',
										'LG46': 'OGGI',
										'LG47': 'Ricevuto',
										'LG48': 'Inviato',
										'LG49': 'Ricevuta della transazione',
										'LG50': 'Cerca token per nome o indirizzo',
										'LG51': 'Aggiungi token al tuo elenco',
										'LG52': 'Cerca in <b>7</b> blockchain',
										'LG54': 'Aggiungi un token personalizzato',
										'LG55': 'Aggiunto',
										'LG56': 'Eliminato',
										'LG57': 'Inserisci l\'indirizzo del token...',
										'LG58': 'Ottieni informazioni sul token',
										'LG59': 'Caricamento in corso',
										'LG60': 'Fai clic qui per aggiungere XXX_XXX al tuo elenco',
										'LG61': 'Token aggiunto!',
										'LG62': 'Rimuovi questo token',
										'LG63': 'Rimuovi da questo elenco',
										'LG64': 'Aggiungi a un elenco',
										'LG65': 'Chiudi',
										'LG66': 'Aggiungi questo token a un elenco',
										'LG67': 'Seleziona un elenco',
										'LG68': 'Aggiungi a questo elenco',
										'LG69': 'Sblocca il tuo portafoglio',
										'LG70': 'Inserisci la tua password per sbloccare il portafoglio...',
										'LG71': 'Ripristina il mio portafoglio',
									};
									
									
	LANG_SEND			=			{		 
										'LG72': 'Importo',
										'LG73': 'invia',
										'LG74': 'home',
										'LG75': 'Digita o cerca qui l\'indirizzo del destinatario...',
										'LG76': 'Gestisci i tuoi contatti',
										'LG77': 'Cerca per nome, indirizzo, email...',
										'LG78':'Nome',
										'LG79':'Indirizzo',
										'LG80': 'Inserisci la tua password...',
										'LG81': 'Firma la transazione',
										'LG82': 'Torna a inviare pagina',
										'LG83': 'SOMMARIO TRANSAZIONE',
										'LG84': 'Data di invio ',
										'LG85': 'Commissioni',
										'LG86': 'Confermato',
										'LG87': 'in attesa',
									};
				
				
	LANG_CROSSCHAIN		=			{		 
										'LG88': 'TOTALE',
										'LG89': 'Destinazione',
										'LG92': 'La transazione è stata <span style="color:#22bcce;">inviata</span>',
										'LG93': 'Approva',
										'LG94': 'Non hai abbastanza XXX_XXX per pagare le tasse',
										'LG95': 'Riprova tra qualche minuto',
									};	
									 
	break;
	

	case "ES":
	LANG_WELCOME		=			{
										'LG1': 'Crear una nueva billetera',
										'LG2': 'Importar una clave privada',
										'LG3': 'Importar una seed phrase',
										'LG4': 'Dirección de billetera',
										'LG5': 'Por favor, rellene los campos vacíos con la palabra correcta',
										'LG0': 'Finalizar',
										'LG6': 'Elija una contraseña segura para proteger su cuenta',
										'LG7': 'Por favor complete el formulario para importar su dirección',
										'LG8': 'Escriba o pegue su clave privada aquí...',
										'LG9': 'Escriba una contraseña...',
										'LG10': 'Confirme su contraseña...',
										'LG11': 'Ingrese las 12 palabras de su seed phrase',
										'LG12': 'Tengo una seed phrase personalizada',
										'LG13': 'Seleccione una dirección y elija una contraseña',
										'LG14': 'Importar',
										'LG15': 'Nunca comparta sus <span class="reunitGradient">claves privadas</span>',
										'LG16': 'Importe su billetera',
										'LG17': 'Escriba cuidadosamente su <span class="reunitGradient">seed phrase</span>',
									};
									
	LANG_HOME			=			{
										'LG18': 'Sus tokens seleccionados',
										'LG19': 'Seleccione una lista de tokens',
										'LG20': 'Todos',
										'LG21': 'Crear una nueva lista',
										'LG22': 'Ingrese un nombre para su lista...',
										'LG23': 'Esta lista no contiene tokens',
										'LG24': 'Para agregar tokens a esta lista, regrese a la página de inicio y haga clic en <i class="reunitGradient fa-solid fa-ellipsis-vertical" style="font-size: 17px;"></i> ubicado a la izquierda del token que desea.',
										'LG25': 'Regreso a casa',
										'LG26': 'Historial de transacciones',
										'LG27': 'Su historial de transacciones está vacío',
										'LG28': 'Esto no significa necesariamente que nunca haya realizado una transacción, solo que no se realizó con Reunit Wallet.',
										'LG29': 'Para ver su historial de transacciones:',
										'LG30': 'haga clic aquí',
										'LG31': 'Enlaces',
										'LG32': 'Configuración',
										'LG33': 'Configure su billetera',
										'LG34': 'Moneda',
										'LG35': 'Velocidad de transacción',
										'LG36': 'normal',
										'LG37': 'rápido',
										'LG38': 'muy rápido',
										'LG39': 'turbo',
										'LG40': 'Retardo antes de bloquear',
										'LG41': 'minutos',
										'LG42': 'Atrás',
										'LG43': 'Copiado',
										'LG44': 'Billetera actual',
										'LG45': 'Red modificada',
										'LG46': 'HOY',
										'LG47': 'Recibido',
										'LG48': 'Enviado',
										'LG49': 'Recibo de transacción',
										'LG50': 'Buscar tokens por nombre o dirección',
										'LG51': 'Agregar tokens a su lista',
										'LG52': 'Buscar en <b>7</b> cadenas de bloques',
										'LG54': 'Agregar un token personalizado',
										'LG55': 'Agregado',
										'LG56': 'Eliminado',
										'LG57': 'Ingrese la dirección del token...',
										'LG58': 'Obtener información del token',
										'LG59': 'Cargando',
										'LG60': 'Haga clic aquí para agregar XXX_XXX a su lista',
										'LG61': '¡Token añadido!',
										'LG62': 'Eliminar este token',
										'LG63': 'Eliminar de esta lista',
										'LG64': 'Agregar a una lista',
										'LG65': 'Cerrar',
										'LG66': 'Agregar este token a una lista',
										'LG67': 'Seleccionar una lista',
										'LG68': 'Agregar a esta lista',
										'LG69': 'Desbloquee su billetera',
										'LG70': 'Ingrese su contraseña para desbloquear su billetera...',
										'LG71': 'Restablecer mi billetera',
									};
									
									
	LANG_SEND			=			{		 
										'LG72': 'Cantidad',
										'LG73': 'enviar',
										'LG74': 'casa',
										'LG75': 'Escriba o busque aquí la dirección del destinatario...',
										'LG76': 'Gestione sus contactos',
										'LG77': 'Buscar por nombre, dirección, correo electrónico...',
										'LG78':'Nombre',
										'LG79':'Dirección',
										'LG80': 'Ingrese su contraseña...',
										'LG81': 'Firma la transacción',
										'LG82': 'Volver a la página de envío',
										'LG83': 'RESUMEN DE TRANSACCIÓN',
										'LG84': 'Fecha de envío',
										'LG85': 'Tarifas',
										'LG86': 'Confirmado',
										'LG87': 'pendiente',
									};
				
				
	LANG_CROSSCHAIN		=			{		 
										'LG88': 'TOTAL',
										'LG89': 'Destino',
										'LG92': 'La transacción ha sido <span style="color:#22bcce;">enviada</span>',
										'LG93': 'Aprobar',
										'LG94': 'No tiene suficientes XXX_XXX para pagar las tarifas',
										'LG95': 'Inténtelo de nuevo en unos minutos',
									};	
									 
	break;
	
	}	
	
	
	for(i in LANG_WELCOME) {
		if($('.'+i+'').is(':input')) {
			$('.'+i+'').attr('placeholder', LANG_WELCOME[i]);
		} else {
			$('.'+i+'').html(LANG_WELCOME[i]);
		}
	}
	for(i in LANG_HOME) {
		if($('.'+i+'').is(':input')) {
			$('.'+i+'').attr('placeholder', LANG_HOME[i]);
		} else {
			$('.'+i+'').html(LANG_HOME[i]);
		}
	}
	for(i in LANG_SEND) {
		if($('.'+i+'').is(':input')) {
			$('.'+i+'').attr('placeholder', LANG_SEND[i]);
		} else {
			$('.'+i+'').html(LANG_SEND[i]);
		}
	}
	for(i in LANG_CROSSCHAIN) {
		if($('.'+i+'').is(':input')) {
			$('.'+i+'').attr('placeholder', LANG_CROSSCHAIN[i]);
		} else {
			$('.'+i+'').html(LANG_CROSSCHAIN[i]);
		}
	}
			 
}